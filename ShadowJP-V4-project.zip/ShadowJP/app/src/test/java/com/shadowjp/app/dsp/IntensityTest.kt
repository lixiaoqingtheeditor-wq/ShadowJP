package com.shadowjp.app.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IntensityTest {

    private val sr = 16000

    @Test
    fun `silence is flagged and clamped, never invented`() {
        val silent = FloatArray(sr / 2)
        val c = IntensityExtractor(sampleRate = sr).extract(silent)
        assertTrue(c.frames.isNotEmpty())
        assertTrue(c.frames.all { it.silent })
        assertTrue(c.frames.all { it.dbfs == IntensityContour.MIN_DBFS })
        // All-silent contour: normalized values are NaN everywhere.
        assertTrue(c.normalizedDb.all { it.isNaN() })
    }

    @Test
    fun `louder signal gives higher dbfs`() {
        val quiet = FloatArray(sr / 2) { i -> (0.01f * kotlin.math.sin(2 * Math.PI * 200 * i / sr)).toFloat() }
        val loud = FloatArray(sr / 2) { i -> (0.3f * kotlin.math.sin(2 * Math.PI * 200 * i / sr)).toFloat() }
        val q = IntensityExtractor(sampleRate = sr).extract(quiet)
        val l = IntensityExtractor(sampleRate = sr).extract(loud)
        val qDb = q.frames.filter { !it.silent }.map { it.dbfs }.average()
        val lDb = l.frames.filter { !it.silent }.map { it.dbfs }.average()
        // ~29.5 dB difference for a 30x amplitude ratio.
        assertTrue(lDb - qDb > 25.0)
    }

    @Test
    fun `mean normalization cancels constant mic gain`() {
        val base = FloatArray(sr / 2) { i ->
            val env = if (i < sr / 4) 0.2f else 0.05f // loud-then-quiet shape
            (env * kotlin.math.sin(2 * Math.PI * 200 * i / sr)).toFloat()
        }
        val gained = FloatArray(base.size) { i -> (base[i] * 4f).coerceIn(-1f, 1f) }
        val ex = IntensityExtractor(sampleRate = sr)
        val a = ex.extract(base).normalizedDb
        val b = ex.extract(gained).normalizedDb
        // Normalized contours should be very close despite the 12 dB gain difference.
        var diffs = 0
        var count = 0
        for (i in a.indices) {
            if (!a[i].isNaN() && !b[i].isNaN()) {
                diffs += if (kotlin.math.abs(a[i] - b[i]) < 0.5f) 1 else 0
                count++
            }
        }
        assertTrue("normalized contours diverged", count > 0 && diffs == count)
    }
}
