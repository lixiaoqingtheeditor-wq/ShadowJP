package com.shadowjp.app.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class SilenceTrimmerTest {

    private val sr = 16000

    /** Speech-like tone burst. */
    private fun tone(ms: Int, amp: Float = 0.3f): FloatArray {
        val n = ms * sr / 1000
        return FloatArray(n) { (amp * sin(2.0 * Math.PI * 150.0 * it / sr)).toFloat() }
    }

    private fun silence(ms: Int) = FloatArray(ms * sr / 1000)

    @Test
    fun `leading and trailing silence removed, internal pause preserved`() {
        // 800ms silence | 500ms tone | 400ms internal pause | 500ms tone | 900ms silence
        val internalPauseMs = 400
        val pcm = silence(800) + tone(500) + silence(internalPauseMs) + tone(500) + silence(900)
        val result = SilenceTrimmer.trim(pcm, sr, minSilenceMs = 250, paddingMs = 100)
        assertNotNull(result)
        result!!
        // Edges trimmed (minus padding).
        assertTrue("leading removed", result.removedLeadingMs in 550..800)
        assertTrue("trailing removed", result.removedTrailingMs in 750..900)
        // Internal pause must survive: trimmed output must still contain it.
        val keptMs = result.samples.size * 1000L / sr
        val speechPlusPause = 500 + internalPauseMs + 500 + 200L // +2x padding
        assertTrue(
            "internal pause preserved (kept=$keptMs)",
            keptMs >= speechPlusPause - 50
        )
    }

    @Test
    fun `no silence returns null`() {
        val pcm = tone(2000)
        assertNull(SilenceTrimmer.trim(pcm, sr))
    }

    @Test
    fun `short edge silence below minimum is kept`() {
        // 100ms edges < 250ms minimum -> nothing trimmed
        val pcm = silence(100) + tone(1000) + silence(100)
        assertNull(SilenceTrimmer.trim(pcm, sr, minSilenceMs = 250, paddingMs = 50))
    }

    @Test
    fun `quiet speech above threshold is preserved`() {
        // amp 0.02 -> about -34 dBFS, above the -45 dB default threshold
        val pcm = silence(500) + tone(800, amp = 0.02f) + silence(500)
        val result = SilenceTrimmer.trim(pcm, sr, paddingMs = 100)
        assertNotNull(result)
        val keptSpeech = result!!.samples.size - 2 * (100 * sr / 1000)
        assertEquals((800 * sr / 1000).toDouble(), keptSpeech.toDouble(), sr / 10.0)
    }

    @Test
    fun `empty input handled`() {
        assertNull(SilenceTrimmer.trim(FloatArray(0), sr))
    }

    @Test
    fun `fully silent input returns null`() {
        assertNull(SilenceTrimmer.trim(silence(3000), sr))
    }
}
