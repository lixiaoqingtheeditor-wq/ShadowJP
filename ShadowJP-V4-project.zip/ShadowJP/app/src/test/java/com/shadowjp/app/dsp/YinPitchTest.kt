package com.shadowjp.app.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

/** Deterministic synthetic-signal tests for the pitch pipeline. */
class YinPitchTest {

    private val sr = 16000

    /** Harmonic voiced-like signal at [f0] with several harmonics. */
    private fun voicedSignal(f0: Float, seconds: Float, amp: Float = 0.3f): FloatArray {
        val n = (sr * seconds).toInt()
        return FloatArray(n) { i ->
            val t = i.toFloat() / sr
            (amp * sin(2 * Math.PI * f0 * t) +
                amp * 0.5f * sin(2 * Math.PI * 2 * f0 * t) +
                amp * 0.25f * sin(2 * Math.PI * 3 * f0 * t)).toFloat()
        }
    }

    private fun silence(seconds: Float) = FloatArray((sr * seconds).toInt())

    @Test
    fun `voiced frame is detected with f0 near the true frequency`() {
        val ex = YinPitchExtractor(sampleRate = sr)
        val signal = voicedSignal(150f, 0.5f)
        val frame = ex.analyzeFrame(signal, 0)
        assertTrue("150 Hz harmonic signal should be voiced", frame.voiced)
        assertEquals(150f, frame.f0Hz, 4f)
        assertTrue(frame.confidence > 0.8f)
    }

    @Test
    fun `low and high voices are both estimated`() {
        val ex = YinPitchExtractor(sampleRate = sr)
        for (f0 in listOf(90f, 120f, 220f, 300f)) {
            val frame = ex.analyzeFrame(voicedSignal(f0, 0.5f), 0)
            assertTrue("$f0 Hz should be voiced", frame.voiced)
            assertEquals(f0, frame.f0Hz, f0 * 0.03f)
        }
    }

    @Test
    fun `silence is unvoiced and never gets a pitch`() {
        val ex = YinPitchExtractor(sampleRate = sr)
        val frame = ex.analyzeFrame(silence(0.5f), 0)
        assertFalse(frame.voiced)
        assertEquals(0f, frame.confidence, 1e-6f)
    }

    @Test
    fun `white noise is unvoiced`() {
        val rng = java.util.Random(42)
        val noise = FloatArray(sr / 2) { (rng.nextFloat() * 2f - 1f) * 0.3f }
        val ex = YinPitchExtractor(sampleRate = sr)
        // Allow a rare lucky frame, but most frames must be unvoiced.
        val contour = ex.extract(noise)
        val voicedRatio = contour.frames.count { it.voiced }.toFloat() / contour.frames.size
        assertTrue("noise voiced ratio $voicedRatio should be low", voicedRatio < 0.2f)
    }

    @Test
    fun `confidence threshold cleaning rejects marginal frames`() {
        // Weak periodicity mixed with an inharmonic component -> low confidence.
        val weak = FloatArray(sr / 2) { i ->
            val t = i.toFloat() / sr
            (0.02f * sin(2 * Math.PI * 150 * t) +
                0.25f * sin(2 * Math.PI * 431.7 * t)).toFloat()
        }
        val ex = YinPitchExtractor(sampleRate = sr)
        val raw = ex.extract(weak)
        val cleaned = raw.cleaned(confidenceThreshold = 0.95f)
        assertTrue(
            "cleaning must not increase the voiced count",
            cleaned.voicedFrames.size <= raw.voicedFrames.size
        )
    }

    @Test
    fun `median voiced f0 is robust to octave errors`() {
        val frames = listOf(
            PitchFrame(0f, 120f, true, 0.9f),
            PitchFrame(0.01f, 122f, true, 0.9f),
            PitchFrame(0.02f, 118f, true, 0.9f),
            PitchFrame(0.03f, 240f, true, 0.9f), // octave error outlier
            PitchFrame(0.04f, 121f, true, 0.9f),
            PitchFrame(0.05f, 0f, false, 0f)
        )
        val c = PitchContour(frames)
        assertEquals(121f, c.medianVoicedF0, 2f)
    }

    @Test
    fun `semitone normalization makes different voice ranges comparable`() {
        // Same contour shape, one octave apart: normalized contours must match.
        // Three voiced frames (odd count) so the median is the middle frame:
        // offsets [0, +2, +12] st vs base -> normalized [-2, 0, +10] st.
        fun contour(base: Float) = PitchContour(
            listOf(0f, 2f, 12f).map { st ->
                PitchFrame(0f, PitchContour.semitonesToHz(st, base), true, 0.9f)
            } + PitchFrame(0f, 0f, false, 0f)
        )
        val low = contour(100f)
        val high = contour(200f)
        for (i in low.semitoneContour.indices) {
            val a = low.semitoneContour[i]
            val b = high.semitoneContour[i]
            if (!a.isNaN()) assertEquals(a, b, 0.01f) else assertTrue(b.isNaN())
        }
        assertEquals(-2f, low.semitoneContour[0], 0.01f)
        assertEquals(0f, low.semitoneContour[1], 0.01f)
        assertEquals(10f, low.semitoneContour[2], 0.01f)
    }

    @Test
    fun `unvoiced frames become NaN in semitone contour`() {
        val c = PitchContour(
            listOf(
                PitchFrame(0f, 150f, true, 0.9f),
                PitchFrame(0.01f, 0f, false, 0f)
            )
        )
        assertTrue(c.semitoneContour[1].isNaN())
        assertFalse(c.semitoneContour[0].isNaN())
    }

    @Test
    fun `empty contour yields NaN median`() {
        assertTrue(PitchContour(emptyList()).medianVoicedF0.isNaN())
    }
}
