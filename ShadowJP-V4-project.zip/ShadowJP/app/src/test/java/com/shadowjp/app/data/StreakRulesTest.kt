package com.shadowjp.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/**
 * Dual-goal streak semantics (v3): a day qualifies only when BOTH the
 * practice-time goal and the takes goal are met.
 */
class StreakRulesTest {

    private fun cal(y: Int, m: Int, d: Int): Calendar =
        Calendar.getInstance().apply {
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

    private fun day(y: Int, m: Int, d: Int, seconds: Int, takes: Int) =
        StreakRules.key(cal(y, m, d)) to StreakRules.DayActivity(seconds, takes)

    private val goalMin = 15 // 900 s
    private val takeGoal = 5

    @Test
    fun `day qualifies only when both goals met`() {
        val both = StreakRules.DayActivity(900, 5)
        val timeOnly = StreakRules.DayActivity(900, 4)
        val takesOnly = StreakRules.DayActivity(899, 5)
        val neither = StreakRules.DayActivity(899, 4)
        assertTrue(StreakRules.dayQualifies(both, goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(timeOnly, goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(takesOnly, goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(neither, goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(null, goalMin, takeGoal))
    }

    @Test
    fun `exceeding one goal does not compensate the other`() {
        val lotsOfTimeNoTakes = StreakRules.DayActivity(10_000, 2)
        val lotsOfTakesNoTime = StreakRules.DayActivity(60, 50)
        assertFalse(StreakRules.dayQualifies(lotsOfTimeNoTakes, goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(lotsOfTakesNoTime, goalMin, takeGoal))
    }

    @Test
    fun `consecutive qualifying days ending today`() {
        val days = mapOf(
            day(2026, 10, 6, 900, 5),
            day(2026, 10, 7, 1200, 6),
            day(2026, 10, 8, 900, 5)
        )
        assertEquals(3, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `today not yet qualified keeps streak alive from yesterday`() {
        val days = mapOf(
            day(2026, 10, 6, 900, 5),
            day(2026, 10, 7, 900, 5)
            // 10-08: nothing yet
        )
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `missed day breaks the streak`() {
        val days = mapOf(
            day(2026, 10, 5, 900, 5),
            // 10-06 missing
            day(2026, 10, 7, 900, 5)
        )
        assertEquals(1, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 7)))
    }

    @Test
    fun `yesterday failed one goal breaks streak even if time goal met`() {
        val days = mapOf(
            day(2026, 10, 6, 900, 5),
            day(2026, 10, 7, 900, 1) // time met, takes missed
        )
        // Today (10-08) not qualified yet -> count back from 10-07, which fails.
        assertEquals(0, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `goal change applies current goal to all days (documented fallback)`() {
        val days = mapOf(
            day(2026, 10, 7, 900, 5),
            day(2026, 10, 8, 900, 5)
        )
        // Same days: qualifies under a 15-min/5-take goal, but not under a
        // stricter 30-min goal - historical goal values are not stored.
        assertEquals(2, StreakRules.currentStreak(days, 15, 5, cal(2026, 10, 8)))
        assertEquals(0, StreakRules.currentStreak(days, 30, 5, cal(2026, 10, 8)))
    }

    @Test
    fun `midnight boundary uses local calendar days`() {
        // 23:59 activity belongs to its own day, not the next one; a streak
        // across the month boundary must step correctly.
        val days = mapOf(
            day(2026, 9, 30, 900, 5),
            day(2026, 10, 1, 900, 5)
        )
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 1)))
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 2)))
    }

    @Test
    fun `app open or started-but-unsaved recording does not qualify`() {
        // No rows at all = no qualifying day.
        assertEquals(0, StreakRules.currentStreak(emptyMap(), goalMin, takeGoal, cal(2026, 10, 8)))
    }
}
