package com.shadowjp.app.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

/**
 * Scoring monotonicity and range tests on synthetic contours, plus an
 * end-to-end engine test on synthetic speech-like PCM.
 */
class ScorerTest {

    private val sr = 16000

    private fun alignAndScore(
        nativeSt: FloatArray,
        userSt: FloatArray,
        nativeDb: FloatArray? = null,
        userDb: FloatArray? = null,
        nativeDur: Float = nativeSt.size * 0.01f,
        userDur: Float = userSt.size * 0.01f
    ): Scorer.Scores {
        val nDb = nativeDb ?: FloatArray(nativeSt.size) { 0f }
        val uDb = userDb ?: FloatArray(userSt.size) { 0f }
        val dtw = Dtw.align(nativeSt, userSt)
        return Scorer.score(nativeSt, userSt, nDb, uDb, dtw, nativeDur, userDur)
    }

    /** Falling pitch-accent-like contour with a clear drop at [dropPos]. */
    private fun accentContour(n: Int, dropPos: Float, dropSize: Float = 6f): FloatArray =
        FloatArray(n) { i ->
            val x = i.toFloat() / (n - 1)
            if (x < dropPos) 3f else 3f - dropSize
        }

    @Test
    fun `all scores are in 0-100 range`() {
        val n = accentContour(50, 0.5f)
        val u = FloatArray(60) { i -> n[(i * 49 / 59)] + 0.4f }
        val s = alignAndScore(n, u)
        for (v in listOf(s.overall, s.pitch, s.timing, s.intensity)) {
            assertTrue("score $v out of range", v in 0f..100f)
        }
    }

    @Test
    fun `identical contour scores near-perfect`() {
        val n = accentContour(60, 0.45f)
        val s = alignAndScore(n, n.copyOf(), nativeDur = 1f, userDur = 1f)
        assertTrue("pitch ${s.pitch}", s.pitch > 90f)
        assertTrue("timing ${s.timing}", s.timing > 90f)
        assertTrue("overall ${s.overall}", s.overall > 90f)
    }

    @Test
    fun `better contour scores higher than worse contour (monotonicity)`() {
        val n = accentContour(60, 0.5f)
        val close = FloatArray(60) { i -> n[i] + if (i % 2 == 0) 0.5f else -0.5f }
        val far = FloatArray(60) { i -> n[i] + if (i % 2 == 0) 5f else -5f }
        val goodScore = alignAndScore(n, close)
        val badScore = alignAndScore(n, far)
        assertTrue(goodScore.pitch > badScore.pitch)
        assertTrue(goodScore.overall > badScore.overall)
    }

    @Test
    fun `displaced pitch drop lowers the pitch score`() {
        val n = accentContour(80, 0.5f)
        val alignedDrop = accentContour(80, 0.5f)
        val displacedDrop = accentContour(80, 0.2f)
        val good = alignAndScore(n, alignedDrop)
        val bad = alignAndScore(n, displacedDrop)
        assertTrue(
            "drop displacement should hurt: ${good.pitch} vs ${bad.pitch}",
            good.pitch > bad.pitch
        )
    }

    @Test
    fun `flat contour vs accent contour scores poorly on direction`() {
        val n = accentContour(60, 0.5f)
        val flat = FloatArray(60) { 0f }
        val s = alignAndScore(n, flat)
        assertTrue("direction agreement ${s.directionAgreement}", s.directionAgreement < 0.6f)
    }

    @Test
    fun `direction is compared across unvoiced gaps`() {
        // Accent drops in Japanese typically sit right at a mora boundary,
        // where an unvoiced gap often appears. The direction metric must
        // still see the drop across that gap: identical contours -> full
        // agreement and a near-perfect pitch score.
        val n = FloatArray(60) { i ->
            if (i < 28) 3f else if (i < 33) Float.NaN else -3f
        }
        val s = alignAndScore(n, n.copyOf(), nativeDur = 1f, userDur = 1f)
        assertEquals(1f, s.directionAgreement, 0.001f)
        assertTrue("pitch ${s.pitch}", s.pitch > 90f)
    }

    @Test
    fun `overall is exactly the documented weighted sum`() {
        val n = accentContour(50, 0.4f)
        val u = accentContour(55, 0.45f)
        val s = alignAndScore(n, u)
        val expected = 0.5f * s.pitch + 0.3f * s.timing + 0.2f * s.intensity
        assertEquals(expected, s.overall, 0.15f) // rounding tolerance
    }

    @Test
    fun `very different durations lower the timing score`() {
        val n = accentContour(100, 0.5f)
        val u = accentContour(30, 0.5f) // 3x shorter
        val s = alignAndScore(n, u, nativeDur = 3f, userDur = 1f)
        assertTrue("timing ${s.timing}", s.timing < 75f)
    }

    @Test
    fun `verdict keys on the weakest subscore`() {
        val s = Scorer.Scores(
            overall = 60f, pitch = 40f, timing = 80f, intensity = 90f,
            meanSemitoneError = 3f, directionAgreement = 0.5f,
            dropDisplacement = 0.1f, durationRatio = 0.9f,
            meanWarpDeviation = 0.05f, meanIntensityErrorDb = 2f
        )
        assertTrue(Scorer.verdict(s).startsWith("Pitch"))
    }

    // ---------- end-to-end engine ----------

    /** Synthetic "speech": harmonic voiced region with an F0 drop, then silence. */
    private fun speech(
        f0High: Float, f0Low: Float, dropAt: Float, seconds: Float,
        sr: Int = 16000, amp: Float = 0.25f
    ): FloatArray {
        val n = (sr * seconds).toInt()
        val dropSample = (n * dropAt).toInt()
        return FloatArray(n) { i ->
            if (i >= n - sr / 10 || i < sr / 40) 0f // silence margins
            else {
                val f0 = if (i < dropSample) f0High else f0Low
                // integrate phase so the F0 change is continuous
                val phase = if (i < dropSample) {
                    2 * PI * f0 * i / sr
                } else {
                    2 * PI * (f0High * dropSample / sr + f0 * (i - dropSample) / sr)
                }
                (amp * sin(phase) + amp * 0.4f * sin(2 * phase) + amp * 0.2f * sin(3 * phase)).toFloat()
            }
        }
    }

    @Test
    fun `engine analyzes matching takes with high score`() {
        val native = speech(220f, 160f, 0.55f, 1.0f)
        val user = speech(130f, 95f, 0.55f, 1.0f) // lower voice, same shape
        val r = AnalysisEngine.analyze(native, user, sampleRate = sr)
        assertTrue("expected success, got $r", r is AnalysisEngine.Result.Success)
        val a = (r as AnalysisEngine.Result.Success).analysis
        assertTrue("overall ${a.scores.overall}", a.scores.overall > 70f)
        assertTrue("pitch ${a.scores.pitch}", a.scores.pitch > 70f)
    }

    @Test
    fun `engine rejects silent recording without fabricating a score`() {
        val native = speech(220f, 160f, 0.55f, 1.0f)
        val silent = FloatArray(sr)
        val r = AnalysisEngine.analyze(native, silent, sampleRate = sr)
        assertTrue(r is AnalysisEngine.Result.Failure)
    }

    @Test
    fun `engine rejects too-short recording`() {
        val native = speech(220f, 160f, 0.55f, 1.0f)
        val tiny = speech(130f, 95f, 0.5f, 0.1f)
        val r = AnalysisEngine.analyze(native, tiny, sampleRate = sr)
        assertTrue(r is AnalysisEngine.Result.Failure)
        assertEquals(
            AnalysisEngine.Reason.RECORDING_TOO_SHORT,
            (r as AnalysisEngine.Result.Failure).reason
        )
    }

    @Test
    fun `absolute pitch difference alone does not hurt the score`() {
        val native = speech(220f, 160f, 0.55f, 1.0f)
        val sameVoice = speech(220f, 160f, 0.55f, 1.0f)
        val deepVoice = speech(110f, 80f, 0.55f, 1.0f) // one octave down
        val a = (AnalysisEngine.analyze(native, sameVoice, sampleRate = sr)
                as AnalysisEngine.Result.Success).analysis
        val b = (AnalysisEngine.analyze(native, deepVoice, sampleRate = sr)
                as AnalysisEngine.Result.Success).analysis
        assertTrue(
            "octave-down voice should score similarly: ${a.scores.pitch} vs ${b.scores.pitch}",
            kotlin.math.abs(a.scores.pitch - b.scores.pitch) < 12f
        )
    }
}
