package com.shadowjp.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * Timestamp math for range decoding: decoder output buffers are trimmed to
 * the exact requested [start, end) window using their presentation time.
 */
class RangeCutterTest {

    private val sr = 16000 // 16 samples per ms

    @Test
    fun `buffer fully inside window is kept whole`() {
        val r = RangeCutter.frameRange(
            bufferPtsUs = 1_000_000, frameCount = 1600, sampleRate = sr,
            startUs = 500_000, endUs = 3_000_000
        )
        assertEquals(0..1599, r)
    }

    @Test
    fun `seek overshoot - content preceding the exact start is discarded`() {
        // Decoder landed 40 ms before A (sync point), buffer covers
        // [960ms, 1060ms); window starts at 1000 ms -> first 640 frames dropped.
        val r = RangeCutter.frameRange(
            bufferPtsUs = 960_000, frameCount = 1600, sampleRate = sr,
            startUs = 1_000_000, endUs = 2_000_000
        )
        assertEquals(640..1599, r)
    }

    @Test
    fun `buffer straddling the end is cut at the boundary`() {
        // Buffer [100ms, 200ms), window ends at 150 ms -> keep frames 0..799.
        val r = RangeCutter.frameRange(
            bufferPtsUs = 100_000, frameCount = 1600, sampleRate = sr,
            startUs = 0, endUs = 150_000
        )
        assertEquals(0..799, r)
    }

    @Test
    fun `buffer fully before or after window is dropped`() {
        assertNull(
            RangeCutter.frameRange(0, 1600, sr, startUs = 500_000, endUs = 1_000_000)
        )
        assertNull(
            RangeCutter.frameRange(2_000_000, 1600, sr, startUs = 500_000, endUs = 1_000_000)
        )
    }

    @Test
    fun `priming frames before the window contribute nothing`() {
        // Whole buffer precedes the window by a hair.
        assertNull(
            RangeCutter.frameRange(
                bufferPtsUs = 900_000, frameCount = 1599, sampleRate = sr,
                startUs = 1_000_000, endUs = 2_000_000
            )
        )
    }

    @Test
    fun `exact frame-boundary alignment keeps full precision`() {
        // Window exactly matches the buffer: nothing trimmed.
        val r = RangeCutter.frameRange(
            bufferPtsUs = 1_000_000, frameCount = 1600, sampleRate = sr,
            startUs = 1_000_000, endUs = 1_100_000
        )
        assertEquals(0..1599, r)
    }

    @Test
    fun `isPastEnd stops decoding at the end boundary`() {
        assert(RangeCutter.isPastEnd(2_000_000, 2_000_000))
        assert(RangeCutter.isPastEnd(2_000_001, 2_000_000))
        assert(!RangeCutter.isPastEnd(1_999_999, 2_000_000))
    }

    @Test
    fun `degenerate inputs are rejected`() {
        assertNull(RangeCutter.frameRange(0, 0, sr, 0, 1_000))
        assertNull(RangeCutter.frameRange(0, 100, sr, 2_000, 1_000))
    }
}
