package com.shadowjp.app.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.sin

/**
 * Waveform peak bucketing: O(buckets) memory regardless of input length,
 * honest zero regions for not-yet-generated buckets, accurate min/max.
 */
class PeakAccumulatorTest {

    @Test
    fun `peaks match the signal in each bucket`() {
        val total = 16_000
        val acc = PeakAccumulator(buckets = 100, totalSamples = total.toLong())
        val samples = FloatArray(total) { sin(it * 0.01f) }
        acc.add(samples)
        val snap = acc.snapshot()
        assertEquals(200, snap.size)
        // Bucket 0 covers samples 0..159 -> contains the rising edge of the sine.
        val min0 = snap[0]
        val max0 = snap[1]
        var trueMin = Float.MAX_VALUE
        var trueMax = -Float.MAX_VALUE
        for (i in 0 until 160) {
            if (samples[i] < trueMin) trueMin = samples[i]
            if (samples[i] > trueMax) trueMax = samples[i]
        }
        assertEquals(trueMin, min0, 1e-6f)
        assertEquals(trueMax, max0, 1e-6f)
        assertEquals(1f, acc.progress, 1e-6f)
    }

    @Test
    fun `partial input yields partial progress and zero tail`() {
        val total = 10_000
        val acc = PeakAccumulator(buckets = 10, totalSamples = total.toLong())
        acc.add(FloatArray(5_000) { 0.5f })
        val snap = acc.snapshot()
        assertEquals(0.5f, acc.progress, 1e-6f)
        // Buckets 0..4 filled, 5..9 still zero.
        assertEquals(0.5f, snap[1], 1e-6f)
        assertEquals(0f, snap[10], 1e-6f)
        assertEquals(0f, snap[19], 1e-6f)
    }

    @Test
    fun `chunked input equals one-shot input`() {
        val total = 8_000
        val samples = FloatArray(total) { sin(it * 0.05f) }
        val oneShot = PeakAccumulator(50, total.toLong())
        oneShot.add(samples)
        val chunked = PeakAccumulator(50, total.toLong())
        var i = 0
        while (i < total) {
            val n = minOf(777, total - i)
            chunked.add(samples.copyOfRange(i, i + n), n)
            i += n
        }
        assertTrue(oneShot.snapshot().contentEquals(chunked.snapshot()))
    }

    @Test
    fun `memory shape does not depend on audio length`() {
        // 10 buckets over 10 samples vs 10 million samples: same array sizes.
        val small = PeakAccumulator(10, 10)
        val large = PeakAccumulator(10, 10_000_000)
        assertEquals(small.snapshot().size, large.snapshot().size)
    }

    @Test
    fun `silence accumulates as zero-valued but touched buckets`() {
        val acc = PeakAccumulator(4, 400)
        acc.add(FloatArray(400)) // all zeros
        val snap = acc.snapshot()
        assertEquals(1f, acc.progress, 1e-6f)
        for (v in snap) assertEquals(0f, abs(v), 1e-6f)
    }
}
