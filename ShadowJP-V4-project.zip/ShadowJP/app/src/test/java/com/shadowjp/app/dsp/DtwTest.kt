package com.shadowjp.app.dsp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DtwTest {

    @Test
    fun `identical sequences give zero cost and diagonal path`() {
        val s = floatArrayOf(0f, 1f, 2f, 3f, 4f)
        val r = Dtw.align(s, s.copyOf())
        assertEquals(0f, r.totalCost, 1e-4f)
        assertEquals(5, r.path.size)
        r.path.forEachIndexed { k, (i, j) ->
            assertEquals(k, i)
            assertEquals(k, j)
        }
    }

    @Test
    fun `unequal lengths align without pathological cost`() {
        // Same ramp, user stretched 1.5x.
        val native = FloatArray(20) { it * 0.5f }
        val user = FloatArray(30) { (it / 1.5f) * 0.5f }
        val r = Dtw.align(native, user)
        assertTrue("mean cost ${r.meanCost} should be small", r.meanCost < 0.5f)
        // Path must start at (0,0) and end at (n-1,m-1).
        assertEquals(0 to 0, r.path.first())
        assertEquals(19 to 29, r.path.last())
    }

    @Test
    fun `unvoiced frames align freely with unvoiced frames`() {
        val a = floatArrayOf(0f, Float.NaN, Float.NaN, 2f)
        val b = floatArrayOf(0f, Float.NaN, 2f)
        val r = Dtw.align(a, b)
        assertTrue(r.totalCost < 3f)
    }

    @Test
    fun `voicing mismatch is penalized`() {
        assertEquals(Dtw.VOICED_MISMATCH_COST, Dtw.localCost(1f, Float.NaN), 1e-4f)
        assertEquals(Dtw.VOICED_MISMATCH_COST, Dtw.localCost(Float.NaN, 1f), 1e-4f)
        assertEquals(0f, Dtw.localCost(Float.NaN, Float.NaN), 1e-4f)
        assertEquals(2f, Dtw.localCost(3f, 5f), 1e-4f)
        // cap
        assertEquals(Dtw.MAX_SEMITONE_COST, Dtw.localCost(-20f, 20f), 1e-4f)
    }

    @Test
    fun `wildly different contours produce higher cost than similar ones`() {
        val a = FloatArray(30) { kotlin.math.sin(it / 5f) * 3 }
        val similar = FloatArray(30) { kotlin.math.sin(it / 5f) * 3 + 0.2f }
        val different = FloatArray(30) { 8f } // flat high line
        val good = Dtw.align(a, similar)
        val bad = Dtw.align(a, different)
        assertTrue(bad.meanCost > good.meanCost * 3)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `empty input is rejected`() {
        Dtw.align(FloatArray(0), floatArrayOf(1f))
    }
}
