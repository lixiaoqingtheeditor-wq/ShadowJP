package com.shadowjp.app.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SelectionMathTest {
    @Test fun `time mapping stays within source window at different zoom levels`() {
        val full = SelectionMath.Viewport(0, 120_000)
        val zoom = SelectionMath.Viewport(45_000, 57_000)
        assertEquals(0L, SelectionMath.fractionToTime(0f, full))
        assertEquals(120_000L, SelectionMath.fractionToTime(1f, full))
        assertEquals(51_000L, SelectionMath.fractionToTime(0.5f, zoom))
        assertEquals(0.5f, SelectionMath.timeToFraction(51_000L, zoom), 1e-6f)
        assertEquals(0f, SelectionMath.timeToFraction(0L, zoom), 1e-6f)
    }

    @Test fun `zoom preserves center and bounds at file edges`() {
        val initial = SelectionMath.Viewport(20_000, 32_000)
        val zoomed = SelectionMath.zoom(initial, 100_000, 0.5f)
        assertEquals(6_000L, zoomed.spanMs)
        assertEquals(26_000L, (zoomed.startMs + zoomed.endMs) / 2L)
        val left = SelectionMath.zoom(SelectionMath.Viewport(0, 8_000), 100_000, 0.25f)
        assertEquals(0L, left.startMs)
        assertTrue(left.endMs <= 100_000L)
    }

    @Test fun `zoom out never expands detailed decoding across a long source`() {
        val initial = SelectionMath.Viewport(10_000, 22_000)
        val zoomedOut = SelectionMath.zoom(initial, 3_600_000, 100f)
        assertEquals(SelectionMath.MAX_DETAIL_VIEWPORT_MS, zoomedOut.spanMs)
        assertTrue(zoomedOut.endMs <= 3_600_000L)
    }

    @Test fun `pan keeps fixed window and clamps to source bounds`() {
        val initial = SelectionMath.Viewport(1_000, 9_000)
        val later = SelectionMath.pan(initial, 60_000, 0.5f)
        assertEquals(5_000L, later.startMs)
        assertEquals(8_000L, later.spanMs)
        val end = SelectionMath.pan(SelectionMath.Viewport(52_000, 60_000), 60_000, 1f)
        assertEquals(52_000L, end.startMs)
        assertEquals(60_000L, end.endMs)
    }

    @Test fun `initial viewport includes selected phrase and fits short recordings`() {
        val v = SelectionMath.initialViewport(100_000, 40_000, 44_000)
        assertTrue(v.startMs <= 40_000)
        assertTrue(v.endMs >= 44_000)
        assertEquals(12_000L, v.spanMs)
        assertEquals(0L, SelectionMath.initialViewport(5_000, 0, 5_000).startMs)
        assertEquals(5_000L, SelectionMath.initialViewport(5_000, 0, 5_000).endMs)
    }

    @Test fun `set boundary at playhead moves whole range and preserves duration`() {
        val start = SelectionMath.rangeStartingAt(60_000, 120_000, 5_000)
        assertEquals(60_000L, start.aMs)
        assertEquals(65_000L, start.bMs)
        val end = SelectionMath.rangeEndingAt(3_000, 120_000, 5_000)
        assertEquals(0L, end.aMs)
        assertEquals(3_000L, end.bMs)
        val nearEnd = SelectionMath.rangeStartingAt(119_500, 120_000, 5_000)
        assertEquals(115_000L, nearEnd.aMs)
        assertEquals(120_000L, nearEnd.bMs)
    }

    @Test fun `range limits preserve 300ms minimum and 60s maximum`() {
        assertEquals(4_700L, SelectionMath.setStart(9_000, 5_000, 10_000))
        assertEquals(40_000L, SelectionMath.setStart(0, 100_000, 120_000))
        assertEquals(5_300L, SelectionMath.setEnd(5_100, 5_000, 100_000))
        assertEquals(65_000L, SelectionMath.setEnd(90_000, 5_000, 100_000))
        assertTrue(SelectionMath.isValidRange(1_000, 1_300, 10_000))
        assertTrue(!SelectionMath.isValidRange(1_000, 1_299, 10_000))
        assertTrue(!SelectionMath.isValidRange(1_000, 62_000, 100_000))
    }
}
