package com.shadowjp.app.ui.components

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimeRangeFieldsTest {
    @Test fun `parse accepts mm ss milliseconds`() {
        assertEquals(83_450L, parseTimeMs("01:23.450"))
        assertEquals(5_000L, parseTimeMs("5"))
        assertEquals(1_250L, parseTimeMs("1.25"))
    }

    @Test fun `parse rejects partial and out of range clock text`() {
        assertNull(parseTimeMs(""))
        assertNull(parseTimeMs("00:"))
        assertNull(parseTimeMs("01:60.000"))
        assertNull(parseTimeMs("-1"))
        assertNull(parseTimeMs("abc"))
        assertNull(parseTimeMs("NaN"))
        assertNull(parseTimeMs("Infinity"))
    }

    @Test fun `format and parse round trip millisecond precision`() {
        val times = listOf(0L, 1L, 1_234L, 61_005L, 3_600_999L)
        times.forEach { assertEquals(it, parseTimeMs(formatTimeMs(it))) }
    }
}
