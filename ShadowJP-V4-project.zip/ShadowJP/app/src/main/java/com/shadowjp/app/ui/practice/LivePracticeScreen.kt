package com.shadowjp.app.ui.practice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shadowjp.app.ui.components.formatTimeMs
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.Black
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite

/** Quiet recording state: no live waveform, pitch, intensity, or prominent timer. */
@Composable
fun LivePracticeScreen(
    state: PracticeViewModel.UiState,
    onStop: () -> Unit,
    onCancel: () -> Unit
) {
    val isRecording = state.phase == PracticeViewModel.Phase.RECORDING

    Column(
        modifier = Modifier.fillMaxSize().background(Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (isRecording) {
            Box(Modifier.size(12.dp).background(Bad, CircleShape))
            Spacer(Modifier.height(20.dp))
        }
        Text(
            if (isRecording) "Recording your attempt" else when {
                state.statusHint?.contains("Get ready", ignoreCase = true) == true -> "Get ready to record"
                state.statusHint?.contains("permission", ignoreCase = true) == true -> "Microphone permission"
                else -> "Listen to the native phrase"
            },
            color = SoftWhite,
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(Modifier.height(8.dp))
        Text(state.title, color = MutedGray, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(4.dp))
        Text("Phrase length ${formatTimeMs(state.bMs - state.aMs)}", color = MutedGray,
            style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(18.dp))
        Text(
            if (isRecording) "Repeat the phrase naturally. The recording stops automatically if it runs too long."
            else state.statusHint ?: "The native phrase plays first, then recording starts automatically.",
            color = SoftWhite, style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(32.dp))
        if (isRecording) {
            Button(
                onClick = onStop,
                colors = ButtonDefaults.buttonColors(containerColor = Bad)
            ) {
                Icon(Icons.Default.Stop, null)
                Spacer(Modifier.width(8.dp))
                Text("Stop and analyze")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onCancel) { Text("Cancel take") }
        } else {
            OutlinedButton(onClick = onCancel) { Text("Cancel listening sequence") }
        }
    }
}
