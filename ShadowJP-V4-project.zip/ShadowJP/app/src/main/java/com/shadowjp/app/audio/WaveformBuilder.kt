package com.shadowjp.app.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Progressive waveform peak generation.
 *
 * Produces a fixed number of min/max peak buckets for display WITHOUT ever
 * retaining the decoded audio: samples stream through a [PeakAccumulator]
 * (O(buckets) memory) and partial snapshots are published as decoding
 * progresses, so the UI can fill in the waveform left-to-right while the
 * file is still being scanned.
 *
 * Fast path: 16-bit PCM WAV files are scanned directly from disk in bounded
 * chunks (no codec, no full-file buffer), which is near-instant even for
 * long recordings.
 *
 * Everything here runs on a background dispatcher supplied by the caller;
 * [isActive] is polled regularly for cooperative cancellation.
 */
object WaveformBuilder {

    /** Publish a partial snapshot at most every N processed samples. */
    private const val PUBLISH_INTERVAL_SAMPLES = 44_100 * 2 // ~2 s of audio

    /**
     * Build [buckets] min/max peak pairs for [file].
     *
     * @param durationMsHint container duration from the import-time metadata
     *   probe, used to size buckets before the decoder reports its own rate.
     * @param onPartial called with (snapshot, progress 0..1) as data arrives.
     * @return the final complete snapshot, or null on failure/cancellation.
     */
    fun build(
        context: Context,
        file: File,
        durationMsHint: Long,
        buckets: Int,
        isActive: () -> Boolean,
        onPartial: (peaks: FloatArray, progress: Float) -> Unit
    ): FloatArray? {
        if (!file.exists() || buckets <= 0) return null
        return try {
            if (WavScanner.canScan(file)) {
                buildFromWav(file, buckets, isActive, onPartial)
            } else {
                buildFromCodec(context, file, durationMsHint, buckets, isActive, onPartial)
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------
    // Fast path: PCM WAV straight from disk
    // ---------------------------------------------------------------

    private fun buildFromWav(
        file: File,
        buckets: Int,
        isActive: () -> Boolean,
        onPartial: (FloatArray, Float) -> Unit
    ): FloatArray? {
        val header = WavScanner.readHeader(file) ?: return null
        val totalFrames = header.dataBytes / (2 * header.channels)
        val acc = PeakAccumulator(buckets, totalFrames.toLong())
        val chunkFrames = 65_536
        val raw = ByteArray(chunkFrames * 2 * header.channels)
        val floats = FloatArray(chunkFrames)
        var sincePublish = 0

        RandomAccessFile(file, "r").use { raf ->
            raf.seek(header.dataOffset.toLong())
            var remaining = header.dataBytes
            while (remaining > 0) {
                if (!isActive()) return null
                val toRead = minOf(raw.size, remaining)
                raf.readFully(raw, 0, toRead)
                val shorts = ByteBuffer.wrap(raw, 0, toRead)
                    .order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                val frames = toRead / (2 * header.channels)
                for (i in 0 until frames) {
                    var a = 0f
                    for (c in 0 until header.channels) a += shorts.get() / 32768f
                    floats[i] = a / header.channels
                }
                acc.add(floats, frames)
                sincePublish += frames
                if (sincePublish >= PUBLISH_INTERVAL_SAMPLES) {
                    onPartial(acc.snapshot(), acc.progress)
                    sincePublish = 0
                }
                remaining -= toRead
            }
        }
        val out = acc.snapshot()
        onPartial(out, 1f)
        return out
    }

    // ---------------------------------------------------------------
    // General path: MediaExtractor + MediaCodec, streaming through peaks
    // ---------------------------------------------------------------

    private fun buildFromCodec(
        context: Context,
        file: File,
        durationMsHint: Long,
        buckets: Int,
        isActive: () -> Boolean,
        onPartial: (FloatArray, Float) -> Unit
    ): FloatArray? {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, Uri.fromFile(file), null)
        } catch (e: Exception) {
            extractor.release()
            return null
        }

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex < 0 || format == null) {
            extractor.release()
            return null
        }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            extractor.release()
            return null
        }

        val outSampleRate0 = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val estimatedTotal = (durationMsHint.coerceAtLeast(1) * outSampleRate0 / 1000L)
        val acc = PeakAccumulator(buckets, estimatedTotal)
        var outSampleRate = outSampleRate0
        var outChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sincePublish = 0
        var cancelled = false

        try {
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val timeoutUs = 10_000L

            while (!outputDone) {
                if (!isActive()) {
                    cancelled = true
                    break
                }
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(timeoutUs)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(
                                inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, timeoutUs)
                when {
                    outIdx >= 0 -> {
                        val buf = codec.getOutputBuffer(outIdx)
                        if (buf != null && info.size > 0) {
                            val f = codec.outputFormat
                            outSampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            outChannels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            val dup = buf.duplicate()
                            dup.position(info.offset)
                            dup.limit(info.offset + info.size)
                            val shorts = dup.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val frames = shorts.remaining() / outChannels
                            val floats = FloatArray(frames)
                            for (i in 0 until frames) {
                                var a = 0f
                                for (c in 0 until outChannels) a += shorts.get() / 32768f
                                floats[i] = a / outChannels
                            }
                            acc.add(floats)
                            sincePublish += frames
                            if (sincePublish >= PUBLISH_INTERVAL_SAMPLES) {
                                onPartial(acc.snapshot(), acc.progress)
                                sincePublish = 0
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            outputDone = true
                        }
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        outSampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outChannels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
        }

        if (cancelled) return null
        val out = acc.snapshot()
        onPartial(out, 1f)
        return out
    }

    /** Minimal WAV header probe for the fast path (16-bit PCM only). */
    internal object WavScanner {
        data class Header(val channels: Int, val dataOffset: Int, val dataBytes: Int)

        fun canScan(file: File): Boolean = readHeader(file) != null

        fun readHeader(file: File): Header? {
            return try {
                RandomAccessFile(file, "r").use { raf ->
                    if (raf.length() < 44) return null
                    val probe = ByteArray(44)
                    raf.readFully(probe)
                    val buf = ByteBuffer.wrap(probe).order(ByteOrder.LITTLE_ENDIAN)
                    if (buf.getInt(0) != 0x46464952) return null // "RIFF"
                    if (buf.getInt(8) != 0x45564157) return null // "WAVE"
                    val audioFormat = buf.getShort(22).toInt()
                    val channels = buf.getShort(24).toInt()
                    val bits = buf.getShort(34).toInt()
                    if (audioFormat != 1 || bits != 16 || channels <= 0) return null
                    // Walk chunks to find "data".
                    raf.seek(12)
                    val chunkHeader = ByteArray(8)
                    while (raf.filePointer + 8 <= raf.length()) {
                        raf.readFully(chunkHeader)
                        val id = String(chunkHeader, 0, 4, Charsets.US_ASCII)
                        val size = ByteBuffer.wrap(chunkHeader, 4, 4)
                            .order(ByteOrder.LITTLE_ENDIAN).int
                        if (id == "data") {
                            val dataBytes = minOf(size, (raf.length() - raf.filePointer).toInt())
                            return Header(channels, raf.filePointer.toInt(), dataBytes)
                        }
                        raf.skipBytes(size)
                    }
                    null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}
