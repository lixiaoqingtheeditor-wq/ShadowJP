package com.shadowjp.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.MutedGray

/**
 * Secondary precise editor. Draft text is local and never mutates A/B while
 * typing; only Apply validates and commits both fields atomically.
 */
@Composable
fun TimeRangeFields(
    aMs: Long,
    bMs: Long,
    durationMs: Long,
    onRange: (Long, Long) -> String?,
    modifier: Modifier = Modifier
) {
    var startText by remember { mutableStateOf(formatTimeMs(aMs)) }
    var endText by remember { mutableStateOf(formatTimeMs(bMs)) }
    var error by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf(false) }

    LaunchedEffect(aMs, bMs, editing) {
        if (!editing) {
            startText = formatTimeMs(aMs)
            endText = formatTimeMs(bMs)
            error = null
        }
    }

    fun cancelDraft() {
        startText = formatTimeMs(aMs)
        endText = formatTimeMs(bMs)
        error = null
        editing = false
    }

    fun commitDraft() {
        val a = parseTimeMs(startText)
        val b = parseTimeMs(endText)
        when {
            a == null || b == null -> error = "Enter valid times as mm:ss.mmm (for example 00:12.450)."
            a > durationMs || b > durationMs -> error = "Times must be within the recording duration."
            else -> {
                val result = onRange(a, b)
                error = result
                if (result == null) {
                    startText = formatTimeMs(a)
                    endText = formatTimeMs(b)
                    editing = false
                }
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = startText,
                onValueChange = { startText = it; editing = true; error = null },
                label = { Text("Start A") },
                singleLine = true,
                isError = error != null,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = endText,
                onValueChange = { endText = it; editing = true; error = null },
                label = { Text("End B") },
                singleLine = true,
                isError = error != null,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            error ?: "mm:ss.mmm · selection ${formatTimeMs((bMs - aMs).coerceAtLeast(0))} / recording ${formatTimeMs(durationMs)}",
            color = if (error != null) Bad else MutedGray,
            style = MaterialTheme.typography.labelSmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = ::commitDraft) { Text("Apply times") }
            TextButton(onClick = ::cancelDraft) { Text("Cancel edits") }
        }
    }
}
