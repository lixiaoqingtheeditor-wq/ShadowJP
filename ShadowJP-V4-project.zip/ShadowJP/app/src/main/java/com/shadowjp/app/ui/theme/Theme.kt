package com.shadowjp.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val CyanDim = Color(0xFF155E6B)
val Black = Color(0xFF000000)
val SurfaceDark = Color(0xFF0D0D0F)
val SurfaceCard = Color(0xFF121216)
val SoftWhite = Color(0xFFF2F2F5)
val MutedGray = Color(0xFF8A8A93)
val NativeGhost = Color(0xFF6E6E78)
val Border = Color(0xFF232329)
val Good = Color(0xFF34D399)
val Warn = Color(0xFFFBBF24)
val Bad = Color(0xFFF87171)

private val ShadowColors = darkColorScheme(
    primary = Cyan,
    onPrimary = Black,
    primaryContainer = CyanDim,
    onPrimaryContainer = SoftWhite,
    secondary = MutedGray,
    onSecondary = Black,
    background = Black,
    onBackground = SoftWhite,
    surface = SurfaceDark,
    onSurface = SoftWhite,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = MutedGray,
    outline = Border,
    error = Bad,
    onError = Black
)

@Composable
fun ShadowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ShadowColors,
        content = content
    )
}
