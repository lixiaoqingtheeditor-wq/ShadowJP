package com.shadowjp.app.ui.segments

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.db.SegmentWithSource
import com.shadowjp.app.data.db.TakeEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SegmentsViewModel(private val app: ShadowApp) : ViewModel() {

    val segments: StateFlow<List<SegmentWithSource>> = app.audioLibrary.segments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val historySegmentId = MutableStateFlow(0L)

    @OptIn(ExperimentalCoroutinesApi::class)
    val history: StateFlow<List<TakeEntity>> = historySegmentId
        .flatMapLatest { id -> app.audioLibrary.takesForSegment(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadHistory(segmentId: Long) {
        historySegmentId.value = segmentId
    }

    fun deleteSegment(id: Long) {
        viewModelScope.launch { app.audioLibrary.deleteSegment(id) }
    }
}
