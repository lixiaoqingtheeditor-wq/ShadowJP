package com.shadowjp.app

import android.app.Application
import com.shadowjp.app.audio.WaveformCache
import com.shadowjp.app.data.AudioLibraryRepository
import com.shadowjp.app.data.PracticeRepository
import com.shadowjp.app.data.db.AppDatabase
import com.shadowjp.app.prefs.SettingsRepository
import java.io.File

/**
 * Lightweight service locator - deliberately no DI framework; the app is
 * small enough that a hand-wired container keeps the architecture obvious.
 */
class ShadowApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var audioLibrary: AudioLibraryRepository
        private set
    lateinit var practice: PracticeRepository
        private set
    lateinit var settings: SettingsRepository
        private set
    lateinit var waveformCache: WaveformCache
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.get(this)
        waveformCache = WaveformCache(this)
        audioLibrary = AudioLibraryRepository(this, database.dao(), waveformCache)
        practice = PracticeRepository(database.dao())
        settings = SettingsRepository(this)

        // Silence-trimmed source copies are session-local by design; sweep
        // any leftovers from a previous process so they cannot accumulate.
        Thread {
            File(filesDir, "imports").listFiles()?.forEach { f ->
                if (f.name.startsWith("trimmed_")) f.delete()
            }
        }.start()
    }
}
