package com.shadowjp.app.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.prefs.PitchRange
import com.shadowjp.app.prefs.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsViewModel(private val app: ShadowApp) : ViewModel() {

    val settings: StateFlow<Settings> = app.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Settings())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun setGoal(minutes: Int) = viewModelScope.launch {
        app.settings.setDailyGoalMinutes(minutes)
    }

    fun setTakeGoal(takes: Int) = viewModelScope.launch {
        app.settings.setDailyTakeGoal(takes)
    }

    fun setPitchRange(range: PitchRange) = viewModelScope.launch {
        app.settings.setPitchRange(range)
    }

    fun setReplayCount(count: Int) = viewModelScope.launch {
        app.settings.setDefaultReplayCount(count)
    }

    fun setSilenceThreshold(db: Float) = viewModelScope.launch {
        app.settings.setSilenceThresholdDb(db)
    }

    fun clearMessage() { _message.value = null }

    /** Full destructive wipe: DB rows + imported audio + recordings + caches. */
    fun clearAllData() = viewModelScope.launch(Dispatchers.IO) {
        val dao = app.database.dao()
        dao.clearTakes()
        dao.clearSegments()
        dao.clearAudioSources()
        dao.clearPracticeDays()
        File(app.filesDir, "imports").deleteRecursively()
        File(app.filesDir, "recordings").deleteRecursively()
        app.waveformCache.clear()
        com.shadowjp.app.audio.PhraseCache.clear()
        _message.value = "All data deleted."
    }

    /** Build the CSV and write it to the user-picked URI. */
    fun exportCsv(context: Context, uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val takes = app.practice.exportCsvRows()
            if (takes.isEmpty()) {
                _message.value = "No takes to export yet."
                return@launch
            }
            val csv = buildString {
                appendLine(
                    "take_id,segment_id,timestamp,overall_score,pitch_score," +
                        "timing_score,intensity_score,native_duration_ms,user_duration_ms"
                )
                for (t in takes) {
                    appendLine(
                        listOf(
                            t.id, t.segmentId, t.createdAt,
                            t.overallScore, t.pitchScore, t.timingScore,
                            t.intensityScore, t.nativeDurationMs, t.userDurationMs
                        ).joinToString(",")
                    )
                }
            }
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(csv.toByteArray(Charsets.UTF_8))
            } ?: run {
                _message.value = "Could not write to the selected location."
                return@launch
            }
            _message.value = "Exported ${takes.size} takes to CSV."
        } catch (e: Exception) {
            _message.value = "Export failed: ${e.message ?: "unknown error"}"
        }
    }

    fun suggestedFileName(): String =
        "shadowjp_scores_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv"
}
