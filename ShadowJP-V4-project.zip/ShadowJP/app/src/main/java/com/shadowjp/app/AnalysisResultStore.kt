package com.shadowjp.app

import com.shadowjp.app.dsp.AnalysisEngine

/**
 * Process-wide holder for the most recent analysis result, passed from the
 * practice screen to the analysis screen. Results are real analysis output,
 * never fabricated; a missing result renders an explicit error state.
 */
class AnalysisResultStore {
    var last: AnalysisEngine.Result? = null
    var segmentId: Long? = null
    var audioSourceId: Long? = null
    /** Path of the native audio file used for the analyzed take. */
    var nativePath: String? = null
    /** A-B range (ms) of the analyzed phrase inside [nativePath]. */
    var aMs: Long = 0
    var bMs: Long = 0
    /** Path of the stored take WAV (playback/export candidate). */
    var takePath: String? = null
}
