package com.shadowjp.app.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Microphone recorder producing deterministic uncompressed mono PCM at
 * [SAMPLE_RATE] Hz, 16-bit, which is exactly what the analysis pipeline
 * consumes (and what [WavFile] persists).
 */
class MicRecorder {

    companion object {
        const val SAMPLE_RATE = 16000
        const val MIN_DURATION_MS = 400L
    }

    sealed class State {
        object Idle : State()
        object Recording : State()
        data class Failed(val message: String) : State()
    }

    private var audioRecord: AudioRecord? = null
    private var job: Job? = null
    private val collected = ArrayList<Float>()

    @Volatile
    var state: State = State.Idle
        private set

    @Volatile
    var recordedDurationMs: Long = 0L
        private set

    @SuppressLint("MissingPermission") // permission checked by caller
    fun start(scope: CoroutineScope): Boolean {
        stopInternal()
        collected.clear()
        recordedDurationMs = 0

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) {
            state = State.Failed("Microphone is not available on this device.")
            return false
        }
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2
            )
        } catch (e: Exception) {
            state = State.Failed("Could not open the microphone: ${e.message}")
            return false
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            state = State.Failed("Microphone failed to initialize.")
            return false
        }
        audioRecord = record
        try {
            record.startRecording()
        } catch (e: Exception) {
            record.release()
            audioRecord = null
            state = State.Failed("Recording could not start: ${e.message}")
            return false
        }
        state = State.Recording

        job = scope.launch(Dispatchers.IO) {
            val buffer = ShortArray(1024)
            val rec = audioRecord ?: return@launch
            while (isActive && state == State.Recording) {
                val read = rec.read(buffer, 0, buffer.size)
                if (read > 0) {
                    synchronized(collected) {
                        for (i in 0 until read) collected.add(buffer[i] / 32768f)
                    }
                    recordedDurationMs = recordedSamples() * 1000L / SAMPLE_RATE
                } else if (read < 0) {
                    state = State.Failed("Recording was interrupted.")
                    break
                }
            }
        }
        return true
    }

    private fun recordedSamples(): Int = synchronized(collected) { collected.size }

    /** Stop and return the recorded PCM, or null if nothing usable was captured. */
    fun stop(): PcmData? {
        val wasRecording = state == State.Recording
        stopInternal()
        val samples = synchronized(collected) { collected.toFloatArray() }
        state = State.Idle
        if (!wasRecording || samples.size < SAMPLE_RATE * MIN_DURATION_MS / 1000) return null
        return PcmData(SAMPLE_RATE, samples)
    }

    fun cancel() {
        stopInternal()
        collected.clear()
        state = State.Idle
    }

    private fun stopInternal() {
        job?.cancel()
        job = null
        audioRecord?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        audioRecord = null
    }
}
