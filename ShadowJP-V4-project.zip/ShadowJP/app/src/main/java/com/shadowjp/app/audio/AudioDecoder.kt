package com.shadowjp.app.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File

/**
 * Audio decoding built on MediaExtractor + MediaCodec.
 *
 * Three deliberately separate operations (v3):
 *
 *  - [probe]: container/track metadata only (duration, sample rate, channel
 *    count, mime). NEVER decodes; returns in milliseconds even for very long
 *    files. This is all the UI needs to open a clip, show its duration and
 *    enable numerical A-B entry.
 *
 *  - [decodeRange]: decodes ONLY the requested [startMs, endMs) window. The
 *    extractor seeks to the sync point at/before the start; decoded frames
 *    preceding the exact start are discarded via [RangeCutter] timestamp
 *    math; decoding stops at the end boundary. Memory use is bounded by the
 *    window length, not the file length.
 *
 *  - [decode]: full-file decode, retained ONLY for the explicit, rare
 *    user-initiated "trim source silence" scan. Cancellable.
 *
 * All variants downmix to mono float samples and resample (linear) to
 * [TARGET_SAMPLE_RATE]. None of them may run on the main thread.
 */
object AudioDecoder {

    const val TARGET_SAMPLE_RATE = 16000

    sealed class DecodeResult {
        data class Ok(val pcm: PcmData) : DecodeResult()
        data class Error(val message: String) : DecodeResult()
    }

    /** Container metadata obtained without decoding a single frame. */
    data class AudioMetadata(
        val durationMs: Long,
        val sampleRateHz: Int?,
        val channelCount: Int?,
        val mimeType: String?
    )

    // ---------------------------------------------------------------
    // Metadata probe (no decoding)
    // ---------------------------------------------------------------

    /**
     * Read duration / sample rate / channel count from the container without
     * decoding. Returns null when the file cannot be opened as audio at all.
     */
    fun probe(context: Context, file: File): AudioMetadata? {
        // Primary: MediaExtractor track format (cheap header parse).
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, Uri.fromFile(file), null)
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("audio/")) continue
                val durationUs = if (f.containsKey(MediaFormat.KEY_DURATION))
                    f.getLong(MediaFormat.KEY_DURATION) else -1L
                val sampleRate = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE))
                    f.getInteger(MediaFormat.KEY_SAMPLE_RATE) else null
                val channels = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT))
                    f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else null
                if (durationUs > 0) {
                    return AudioMetadata(
                        durationMs = durationUs / 1000L,
                        sampleRateHz = sampleRate,
                        channelCount = channels,
                        mimeType = mime
                    )
                }
            }
        } catch (e: Exception) {
            // fall through to the retriever
        } finally {
            extractor.release()
        }

        // Fallback: MediaMetadataRetriever (duration only on older devices).
        val retriever = android.media.MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durMs = retriever.extractMetadata(
                android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull()
            val sr = retriever.extractMetadata(
                android.media.MediaMetadataRetriever.METADATA_KEY_SAMPLERATE
            )?.toIntOrNull()
            if (durMs != null && durMs > 0) AudioMetadata(durMs, sr, null, null) else null
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------
    // Range decode (seek + decode only [startMs, endMs))
    // ---------------------------------------------------------------

    /**
     * Decode only the [startMs, endMs) window of [file].
     *
     * Strategy: seek the extractor to the closest sync point at or before the
     * requested start, decode forward, discard frames preceding the exact
     * start using each buffer's presentation timestamp, and stop as soon as a
     * buffer reaches the end boundary. Frames partially overlapping the
     * boundaries are kept (sub-frame accuracy, < 1 sample-frame error).
     *
     * [isActive] is polled every codec round-trip; when it returns false the
     * decode aborts and an Error("cancelled") is returned so callers can
     * silently drop obsolete work.
     *
     * If the format/decoder refuses to seek or yields nothing in range, the
     * caller-visible result is an explicit Error - callers decide on a
     * fallback (never a silent full-file decode on the UI thread).
     */
    fun decodeRange(
        context: Context,
        file: File,
        startMs: Long,
        endMs: Long,
        isActive: () -> Boolean = { true }
    ): DecodeResult {
        if (endMs <= startMs) return DecodeResult.Error("Empty range.")
        return try {
            decodeInternal(
                context, file,
                startUs = startMs * 1000L,
                endUs = endMs * 1000L,
                isActive = isActive
            )
        } catch (e: Exception) {
            DecodeResult.Error("Could not decode audio: ${e.message ?: "unsupported or corrupt file"}")
        }
    }

    // ---------------------------------------------------------------
    // Full decode (bounded use: silence scan of the source)
    // ---------------------------------------------------------------

    /** Full-file decode. Cancellable via [isActive]. Never call on the main thread. */
    fun decode(
        context: Context,
        file: File,
        isActive: () -> Boolean = { true }
    ): DecodeResult {
        return try {
            decodeInternal(context, file, startUs = 0L, endUs = Long.MAX_VALUE, isActive)
        } catch (e: Exception) {
            DecodeResult.Error("Could not decode audio: ${e.message ?: "unsupported or corrupt file"}")
        }
    }

    // ---------------------------------------------------------------
    // Shared decode pipeline
    // ---------------------------------------------------------------

    private fun decodeInternal(
        context: Context,
        file: File,
        startUs: Long,
        endUs: Long,
        isActive: () -> Boolean
    ): DecodeResult {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, Uri.fromFile(file), null)
        } catch (e: Exception) {
            extractor.release()
            return DecodeResult.Error("Could not open audio file. It may be corrupt or inaccessible.")
        }

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex < 0 || format == null) {
            extractor.release()
            return DecodeResult.Error("No audio track found in this file.")
        }

        extractor.selectTrack(trackIndex)
        // Seek to the sync point at or before the requested start. The seek
        // granularity is format-dependent (mp3 frames, aac packets); the
        // timestamp-based trimming below corrects for the early landing.
        if (startUs > 0) {
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        }

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            extractor.release()
            return DecodeResult.Error("Unsupported audio format ($mime).")
        }

        val chunks = ArrayList<FloatArray>()
        var totalSamples = 0
        var outSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var outChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var sawOutput = false
        var sawInRangeOutput = false

        try {
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val timeoutUs = 10_000L

            while (!outputDone) {
                if (!isActive()) return DecodeResult.Error("cancelled")

                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(timeoutUs)
                    if (inIdx >= 0) {
                        val buf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        // Stop feeding once we are well past the requested
                        // end; queued buffers are enough to cover it.
                        // (Guard against endUs == Long.MAX_VALUE overflow.)
                        val pastEnd = endUs < Long.MAX_VALUE - 300_000L &&
                            extractor.sampleTime >= endUs + 300_000L
                        if (size < 0 || pastEnd) {
                            codec.queueInputBuffer(
                                inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(
                                inIdx, 0, size, extractor.sampleTime, 0
                            )
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, timeoutUs)
                when {
                    outIdx >= 0 -> {
                        val buf = codec.getOutputBuffer(outIdx)
                        if (buf != null && info.size > 0) {
                            val chunkFormat = codec.outputFormat
                            outSampleRate = chunkFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            outChannels = chunkFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            sawOutput = true
                            val floats = pcmBytesToFloatMono(buf, info, outChannels)
                            val keep = RangeCutter.frameRange(
                                bufferPtsUs = info.presentationTimeUs,
                                frameCount = floats.size,
                                sampleRate = outSampleRate,
                                startUs = startUs,
                                endUs = endUs
                            )
                            if (keep != null) {
                                val slice = floats.copyOfRange(keep.first, keep.last + 1)
                                if (slice.isNotEmpty()) {
                                    chunks.add(slice)
                                    totalSamples += slice.size
                                    sawInRangeOutput = true
                                }
                            }
                            // Past the end boundary: nothing more to collect.
                            if (RangeCutter.isPastEnd(info.presentationTimeUs, endUs)) {
                                codec.releaseOutputBuffer(outIdx, false)
                                outputDone = true
                                continue
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            outputDone = true
                        }
                    }
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        outSampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outChannels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
        }

        if (totalSamples == 0) {
            return if (!sawOutput) DecodeResult.Error("Decoded audio is empty.")
            else if (!sawInRangeOutput) DecodeResult.Error(
                "The selected range produced no audio (unsupported seeking?)."
            )
            else DecodeResult.Error("Decoded audio is empty.")
        }

        val merged = FloatArray(totalSamples)
        var offset = 0
        for (chunk in chunks) {
            chunk.copyInto(merged, offset)
            offset += chunk.size
        }
        val pcm = PcmData(outSampleRate, merged)
        return DecodeResult.Ok(Resampler.resample(pcm, TARGET_SAMPLE_RATE))
    }

    /** Convert 16-bit PCM bytes to mono float samples (averaging channels). */
    private fun pcmBytesToFloatMono(
        buf: java.nio.ByteBuffer,
        info: MediaCodec.BufferInfo,
        channels: Int
    ): FloatArray {
        val dup = buf.duplicate()
        dup.position(info.offset)
        dup.limit(info.offset + info.size)
        val shorts = dup.order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val frameCount = shorts.remaining() / channels
        val out = FloatArray(frameCount)
        for (i in 0 until frameCount) {
            var acc = 0f
            for (c in 0 until channels) acc += shorts.get() / 32768f
            out[i] = acc / channels
        }
        return out
    }
}
