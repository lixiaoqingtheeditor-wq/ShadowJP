package com.shadowjp.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.shadowjp.app.ui.analysis.AnalysisScreen
import com.shadowjp.app.ui.home.HomeScreen
import com.shadowjp.app.ui.home.HomeViewModel
import com.shadowjp.app.ui.practice.PracticeScreen
import com.shadowjp.app.ui.practice.PracticeViewModel
import com.shadowjp.app.ui.segments.SegmentHistoryScreen
import com.shadowjp.app.ui.segments.SegmentsScreen
import com.shadowjp.app.ui.segments.SegmentsViewModel
import com.shadowjp.app.ui.settings.SettingsScreen
import com.shadowjp.app.ui.settings.SettingsViewModel
import com.shadowjp.app.ui.stats.StatsScreen
import com.shadowjp.app.ui.stats.StatsViewModel
import com.shadowjp.app.ui.theme.ShadowTheme

object Routes {
    const val HOME = "home"
    const val PRACTICE_SOURCE = "practice/source/{sourceId}"
    const val PRACTICE_SEGMENT = "practice/segment/{segmentId}"
    const val ANALYSIS = "analysis"
    const val SEGMENTS = "segments"
    const val SEGMENT_HISTORY = "segments/{segmentId}/history"
    const val STATS = "stats"
    const val SETTINGS = "settings"

    fun practiceSource(sourceId: Long) = "practice/source/$sourceId"
    fun practiceSegment(segmentId: Long) = "practice/segment/$segmentId"
    fun segmentHistory(segmentId: Long) = "segments/$segmentId/history"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ShadowApp
        setContent {
            ShadowTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNav(app)
                }
            }
        }
    }
}

@Suppress("UNCHECKED_CAST")
private class Factory<VM : ViewModel>(private val create: () -> VM) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = create() as T
}

@Composable
fun AppNav(app: ShadowApp) {
    val nav = rememberNavController()

    // Shared analysis state holder so the analysis screen survives recomposition
    // without re-running the pipeline.
    val analysisStore = remember { AnalysisResultStore() }

    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            val vm: HomeViewModel = viewModel(
                factory = Factory { HomeViewModel(app) }
            )
            HomeScreen(
                vm = vm,
                onPracticeSegment = { nav.navigate(Routes.practiceSegment(it)) },
                onPracticeSource = { nav.navigate(Routes.practiceSource(it)) },
                onOpenSegments = { nav.navigate(Routes.SEGMENTS) },
                onOpenStats = { nav.navigate(Routes.STATS) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(
            Routes.PRACTICE_SOURCE,
            arguments = listOf(navArgument("sourceId") { type = NavType.LongType })
        ) { entry ->
            val sourceId = entry.arguments?.getLong("sourceId") ?: return@composable
            val vm: PracticeViewModel = viewModel(
                key = "practice-src-$sourceId",
                factory = Factory {
                    PracticeViewModel(app, PracticeViewModel.Target.Source(sourceId))
                }
            )
            PracticeScreen(
                vm = vm,
                analysisStore = analysisStore,
                onBack = { nav.popBackStack() },
                onAnalyzed = { nav.navigate(Routes.ANALYSIS) }
            )
        }
        composable(
            Routes.PRACTICE_SEGMENT,
            arguments = listOf(navArgument("segmentId") { type = NavType.LongType })
        ) { entry ->
            val segmentId = entry.arguments?.getLong("segmentId") ?: return@composable
            val vm: PracticeViewModel = viewModel(
                key = "practice-seg-$segmentId",
                factory = Factory {
                    PracticeViewModel(app, PracticeViewModel.Target.Segment(segmentId))
                }
            )
            PracticeScreen(
                vm = vm,
                analysisStore = analysisStore,
                onBack = { nav.popBackStack() },
                onAnalyzed = { nav.navigate(Routes.ANALYSIS) }
            )
        }
        composable(Routes.ANALYSIS) {
            AnalysisScreen(
                app = app,
                store = analysisStore,
                onRetake = { nav.popBackStack() },
                onDone = { nav.popBackStack(Routes.HOME, inclusive = false) }
            )
        }
        composable(Routes.SEGMENTS) {
            val vm: SegmentsViewModel = viewModel(factory = Factory { SegmentsViewModel(app) })
            SegmentsScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onPractice = { nav.navigate(Routes.practiceSegment(it)) },
                onHistory = { nav.navigate(Routes.segmentHistory(it)) }
            )
        }
        composable(
            Routes.SEGMENT_HISTORY,
            arguments = listOf(navArgument("segmentId") { type = NavType.LongType })
        ) { entry ->
            val segmentId = entry.arguments?.getLong("segmentId") ?: return@composable
            val vm: SegmentsViewModel = viewModel(factory = Factory { SegmentsViewModel(app) })
            SegmentHistoryScreen(vm = vm, segmentId = segmentId, onBack = { nav.popBackStack() })
        }
        composable(Routes.STATS) {
            val vm: StatsViewModel = viewModel(factory = Factory { StatsViewModel(app) })
            StatsScreen(vm = vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            val vm: SettingsViewModel = viewModel(factory = Factory { SettingsViewModel(app) })
            SettingsScreen(vm = vm, onBack = { nav.popBackStack() })
        }
    }
}
