package com.shadowjp.app.dsp

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * YIN pitch detector, implemented from scratch in Kotlin following
 * de Cheveigné & Kawahara (2002), steps 1-5:
 *
 *  1. Autocorrelation-based difference function d(tau).
 *  2. Cumulative mean normalized difference d'(tau).
 *  3. Absolute-threshold search: first local minimum of d' below
 *     [absoluteThreshold] wins; otherwise the frame is unvoiced.
 *  4. Parabolic interpolation around the winning tau.
 *  5. f0 = sampleRate / tau.
 *
 * Frames whose RMS energy is below [silenceRms] are forced unvoiced, so
 * silence/noise is never reported as pitch. Confidence is 1 - d'(tau*),
 * i.e. the periodicity strength of the winning lag.
 *
 * Pure Kotlin / JVM - no native code, no external DSP libraries.
 */
class YinPitchExtractor(
    val sampleRate: Int = DEFAULT_SAMPLE_RATE,
    val minF0Hz: Float = 60f,
    val maxF0Hz: Float = 400f,
    val absoluteThreshold: Float = 0.15f,
    val silenceRms: Float = 0.008f,
    val frameSizeSamples: Int = 1024,
    val hopSizeSamples: Int = 160 // 10 ms at 16 kHz
) {
    companion object {
        const val DEFAULT_SAMPLE_RATE = 16000
    }

    private val minTau = (sampleRate / maxF0Hz).toInt().coerceAtLeast(2)
    private val maxTau = (sampleRate / minF0Hz).toInt().coerceAtMost(frameSizeSamples / 2)

    /** Full-contour extraction over a mono float PCM signal in [-1, 1]. */
    fun extract(samples: FloatArray): PitchContour {
        if (samples.size < frameSizeSamples) return PitchContour(emptyList())
        val frames = ArrayList<PitchFrame>()
        var start = 0
        while (start + frameSizeSamples <= samples.size) {
            frames.add(analyzeFrame(samples, start))
            start += hopSizeSamples
        }
        return PitchContour(frames)
    }

    /** Analyze a single frame beginning at [start] inside [samples]. */
    fun analyzeFrame(samples: FloatArray, start: Int): PitchFrame {
        val centerSec = (start + frameSizeSamples / 2f) / sampleRate

        // Energy gate first: silence is unvoiced, never pitched.
        var sumSq = 0.0
        for (i in start until start + frameSizeSamples) {
            val s = samples[i].toDouble()
            sumSq += s * s
        }
        val rms = sqrt(sumSq / frameSizeSamples).toFloat()
        if (rms < silenceRms) {
            return PitchFrame(centerSec, 0f, voiced = false, confidence = 0f)
        }

        // Step 1: difference function d(tau) over [minTau, maxTau].
        val tauCount = maxTau + 1
        val d = DoubleArray(tauCount)
        for (tau in minTau..maxTau) {
            var sum = 0.0
            val limit = start + frameSizeSamples - tau
            var i = start
            while (i < limit) {
                val diff = samples[i] - samples[i + tau]
                sum += diff * diff
                i++
            }
            d[tau] = sum
        }

        // Step 2: cumulative mean normalized difference d'(tau).
        val dPrime = DoubleArray(tauCount)
        dPrime[0] = 1.0
        var running = 0.0
        for (tau in 1 until tauCount) {
            running += d[tau]
            dPrime[tau] = if (running == 0.0) 1.0 else d[tau] * tau / running
        }

        // Step 3: absolute threshold - first local minimum below threshold.
        var bestTau = -1
        var tau = minTau
        while (tau <= maxTau) {
            if (dPrime[tau] < absoluteThreshold) {
                while (tau + 1 <= maxTau && dPrime[tau + 1] < dPrime[tau]) tau++
                bestTau = tau
                break
            }
            tau++
        }

        if (bestTau < 0) {
            // No periodicity found: unvoiced (consonant, noise, breath).
            return PitchFrame(centerSec, 0f, voiced = false, confidence = 0f)
        }

        // Step 4: parabolic interpolation for sub-sample lag.
        val refinedTau = parabolicInterp(dPrime, bestTau)
        if (refinedTau <= 0.0) {
            return PitchFrame(centerSec, 0f, voiced = false, confidence = 0f)
        }

        val f0 = (sampleRate / refinedTau).toFloat()
        if (!f0.isFinite() || f0 < minF0Hz * 0.9f || f0 > maxF0Hz * 1.1f) {
            return PitchFrame(centerSec, 0f, voiced = false, confidence = 0f)
        }

        val confidence = (1.0 - dPrime[bestTau]).toFloat().coerceIn(0f, 1f)
        return PitchFrame(centerSec, f0, voiced = true, confidence = confidence)
    }

    private fun parabolicInterp(y: DoubleArray, x: Int): Double {
        if (x <= 0 || x >= y.size - 1) return x.toDouble()
        val y0 = y[x - 1]; val y1 = y[x]; val y2 = y[x + 1]
        val denom = (y0 - 2 * y1 + y2)
        if (abs(denom) < 1e-12) return x.toDouble()
        val shift = 0.5 * (y0 - y2) / denom
        return x + shift.coerceIn(-1.0, 1.0)
    }
}

/**
 * Removes unreliable pitch estimates: voiced frames whose confidence is
 * below [confidenceThreshold] are re-marked unvoiced. Optionally applies a
 * short median filter to suppress single-frame octave jumps.
 */
fun PitchContour.cleaned(
    confidenceThreshold: Float = 0.6f,
    medianFilter: Boolean = true
): PitchContour {
    val out = frames.map { f ->
        if (f.voiced && f.confidence < confidenceThreshold) f.copy(voiced = false, confidence = 0f)
        else f
    }.toMutableList()

    if (medianFilter) {
        val f0s = out.map { if (it.voiced) it.f0Hz else Float.NaN }
        for (i in 1 until out.size - 1) {
            if (!out[i].voiced) continue
            val window = listOfNotNull(
                f0s.getOrNull(i - 1), f0s[i], f0s.getOrNull(i + 1)
            ).filter { it.isFinite() }.sorted()
            if (window.size == 3) {
                out[i] = out[i].copy(f0Hz = window[1])
            }
        }
    }
    return PitchContour(out)
}
