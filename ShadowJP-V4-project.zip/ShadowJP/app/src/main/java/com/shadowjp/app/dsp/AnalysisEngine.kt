package com.shadowjp.app.dsp

/**
 * End-to-end analysis pipeline:
 * PCM in -> pitch + intensity extraction -> speaker normalization ->
 * DTW alignment -> sub-scores + overall + verdict + graph data.
 *
 * All steps are pure Kotlin and deterministic; identical inputs always
 * produce identical scores. Failures return explicit reasons - a score is
 * never fabricated when analysis is impossible.
 */
object AnalysisEngine {

    const val MIN_VOICED_FRAMES = 8
    const val MIN_ACTIVE_INTENSITY_FRAMES = 8
    const val CONFIDENCE_THRESHOLD = 0.6f

    sealed class Result {
        data class Success(val analysis: Analysis) : Result()
        data class Failure(val reason: Reason) : Result()
    }

    enum class Reason(val message: String) {
        RECORDING_TOO_SHORT("Recording is too short to analyze. Hold the phrase a little longer."),
        NO_USABLE_PITCH_NATIVE("No usable pitch found in the native segment. Pick a phrase with clear voiced speech."),
        NO_USABLE_PITCH_USER("No usable pitch detected in your take. Speak clearly, closer to the microphone."),
        INSUFFICIENT_SIGNAL("Not enough voiced speech to compare. Try again with a longer phrase."),
        EMPTY_INPUT("Nothing to analyze.")
    }

    /** Graph-ready, normalized analysis data for one take. */
    class Analysis(
        val scores: Scorer.Scores,
        val verdict: String,
        /** Native contour: semitone offsets vs. its own median (NaN = unvoiced). */
        val nativeSemitones: FloatArray,
        /** User contour, same normalization. */
        val userSemitones: FloatArray,
        /** Native intensity, mean-normalized dB (NaN = silent). */
        val nativeIntensity: FloatArray,
        /** User intensity, mean-normalized dB (NaN = silent). */
        val userIntensity: FloatArray,
        /** DTW alignment path (nativeIdx, userIdx). */
        val alignmentPath: List<Pair<Int, Int>>,
        val nativeDurationSec: Float,
        val userDurationSec: Float,
        val nativeMedianF0: Float,
        val userMedianF0: Float,
        val nativeVoicedRatio: Float,
        val userVoicedRatio: Float
    )

    fun analyze(
        nativePcm: FloatArray,
        userPcm: FloatArray,
        sampleRate: Int = YinPitchExtractor.DEFAULT_SAMPLE_RATE,
        minF0Hz: Float = 60f,
        maxF0Hz: Float = 400f
    ): Result {
        if (nativePcm.isEmpty() || userPcm.isEmpty()) return Result.Failure(Reason.EMPTY_INPUT)
        if (userPcm.size < sampleRate / 4) return Result.Failure(Reason.RECORDING_TOO_SHORT)

        val pitchExtractor = YinPitchExtractor(
            sampleRate = sampleRate, minF0Hz = minF0Hz, maxF0Hz = maxF0Hz
        )
        val intensityExtractor = IntensityExtractor(sampleRate = sampleRate)

        val nativePitch = pitchExtractor.extract(nativePcm).cleaned(CONFIDENCE_THRESHOLD)
        val userPitch = pitchExtractor.extract(userPcm).cleaned(CONFIDENCE_THRESHOLD)

        if (nativePitch.voicedFrames.size < MIN_VOICED_FRAMES)
            return Result.Failure(Reason.NO_USABLE_PITCH_NATIVE)
        if (userPitch.voicedFrames.isEmpty())
            return Result.Failure(Reason.NO_USABLE_PITCH_USER)
        if (userPitch.voicedFrames.size < MIN_VOICED_FRAMES)
            return Result.Failure(Reason.INSUFFICIENT_SIGNAL)

        val nativeIntensity = intensityExtractor.extract(nativePcm)
        val userIntensity = intensityExtractor.extract(userPcm)
        if (nativeIntensity.activeFrames.size < MIN_ACTIVE_INTENSITY_FRAMES ||
            userIntensity.activeFrames.size < MIN_ACTIVE_INTENSITY_FRAMES
        ) return Result.Failure(Reason.INSUFFICIENT_SIGNAL)

        val nativeSt = nativePitch.semitoneContour
        val userSt = userPitch.semitoneContour
        if (nativeSt.isEmpty() || userSt.isEmpty()) return Result.Failure(Reason.INSUFFICIENT_SIGNAL)

        val nativeDb = nativeIntensity.normalizedDb
        val userDb = userIntensity.normalizedDb

        val dtw = try {
            Dtw.align(nativeSt, userSt)
        } catch (e: Exception) {
            return Result.Failure(Reason.INSUFFICIENT_SIGNAL)
        }

        val scores = Scorer.score(
            nativeSt = nativeSt,
            userSt = userSt,
            nativeIntensityDb = nativeDb,
            userIntensityDb = userDb,
            dtw = dtw,
            nativeDurationSec = nativePitch.durationSec,
            userDurationSec = userPitch.durationSec
        )

        return Result.Success(
            Analysis(
                scores = scores,
                verdict = Scorer.verdict(scores),
                nativeSemitones = nativeSt,
                userSemitones = userSt,
                nativeIntensity = nativeDb,
                userIntensity = userDb,
                alignmentPath = dtw.path,
                nativeDurationSec = nativePitch.durationSec,
                userDurationSec = userPitch.durationSec,
                nativeMedianF0 = nativePitch.medianVoicedF0,
                userMedianF0 = userPitch.medianVoicedF0,
                nativeVoicedRatio = nativePitch.voicedRatio,
                userVoicedRatio = userPitch.voicedRatio
            )
        )
    }
}
