package com.shadowjp.app.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.shadowjp.app.ui.theme.Bad
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.NativeGhost
import com.shadowjp.app.ui.theme.SoftWhite

private fun fmtSecs(totalSecs: Int): String {
    val h = totalSecs / 3600
    val m = (totalSecs % 3600) / 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}

private fun fmtMs(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onPracticeSegment: (Long) -> Unit,
    onPracticeSource: (Long) -> Unit,
    onOpenSegments: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by vm.state.collectAsState()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { vm.importAudio(it) } }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "ShadowJP",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                        Text(
                            "Japanese shadowing practice",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedGray
                        )
                    }
                    IconButton(onClick = onOpenStats) {
                        Icon(Icons.Default.BarChart, "Statistics", tint = MutedGray)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, "Settings", tint = MutedGray)
                    }
                }
            }

            // Dual goal card: practice time (ring) + completed takes (bar).
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GoalRing(
                            progress = state.timeProgress,
                            modifier = Modifier.size(110.dp)
                        ) {
                            Text(
                                "${(state.timeProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = SoftWhite
                            )
                            Text("time goal", style = MaterialTheme.typography.labelSmall, color = MutedGray)
                        }
                        Spacer(Modifier.width(20.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatLine("Practice time", fmtSecs(state.todaySeconds) + " / ${state.goalMinutes}m")
                            Column {
                                Row {
                                    Text("Takes today", style = MaterialTheme.typography.bodySmall,
                                        color = MutedGray, modifier = Modifier.width(110.dp))
                                    Text("${state.todayTakes} / ${state.takeGoal}",
                                        style = MaterialTheme.typography.bodyMedium, color = SoftWhite)
                                }
                                Spacer(Modifier.size(4.dp))
                                LinearProgressIndicator(
                                    progress = { state.takeProgress.coerceAtMost(1f) },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Cyan,
                                    trackColor = NativeGhost.copy(alpha = 0.25f)
                                )
                            }
                            StatLine("Total practice", fmtSecs(state.totalSeconds))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = if (state.streak > 0) Cyan else MutedGray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "${state.streak} day streak",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SoftWhite
                                )
                            }
                        }
                    }
                }
            }

            // Import CTA
            item {
                Button(
                    onClick = { picker.launch(arrayOf("audio/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.importing
                ) {
                    if (state.importing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Importing...")
                    } else {
                        Icon(Icons.Default.AudioFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Import audio")
                    }
                }
            }

            // Imported sources
            if (state.sources.isNotEmpty()) {
                item {
                    Text(
                        "Imported audio",
                        style = MaterialTheme.typography.titleSmall,
                        color = MutedGray
                    )
                }
                items(state.sources.size) { i ->
                    val s = state.sources[i]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPracticeSource(s.id) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AudioFile, null, tint = Cyan, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.displayName, color = SoftWhite, maxLines = 1,
                                style = MaterialTheme.typography.bodyMedium)
                            Text(
                                fmtMs(s.durationMs) + (
                                    s.sampleRateHz?.let { " · ${it / 1000f}kHz" } ?: ""
                                    ) + (
                                    s.channelCount?.let {
                                        " · " + if (it == 1) "mono" else if (it == 2) "stereo" else "${it}ch"
                                    } ?: ""
                                    ),
                                color = MutedGray,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        IconButton(onClick = { vm.requestDeleteClip(s.id) }) {
                            Icon(Icons.Default.Delete, "Delete clip", tint = MutedGray,
                                modifier = Modifier.size(20.dp))
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                    }
                }
            }

            // Recent segments
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenSegments() }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LibraryMusic, null, tint = Cyan, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Segments (${state.segments.size})",
                        style = MaterialTheme.typography.titleSmall,
                        color = SoftWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                }
            }
            items(minOf(state.segments.size, 3)) { i ->
                val seg = state.segments[i]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPracticeSegment(seg.id) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(seg.displayName, color = SoftWhite, maxLines = 1,
                            style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${fmtMs(seg.startMs)} - ${fmtMs(seg.endMs)}",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                }
            }
        }

        state.importError?.let { err ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                action = {
                    TextButton(onClick = { vm.clearImportError() }) { Text("OK") }
                }
            ) { Text(err) }
        }

        state.deleteMessage?.let { msg ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                action = {
                    TextButton(onClick = { vm.clearDeleteMessage() }) { Text("OK") }
                }
            ) { Text(msg) }
        }

        // Deletion confirmation with the ACTUAL dependent-record counts.
        state.deleteCandidate?.let { info ->
            val dependents = when {
                info.segmentCount == 0 -> "It has no saved segments or practice history."
                else -> "This will also remove ${info.segmentCount} associated " +
                    "segment(s) and ${info.takeCount} stored take(s) with their " +
                    "practice history."
            }
            AlertDialog(
                onDismissRequest = { if (!state.deleting) vm.cancelDeleteClip() },
                title = { Text("Remove this clip?") },
                text = {
                    Text(
                        "\"${info.displayName}\" (${fmtMs(info.durationMs)}) will be " +
                            "removed from ShadowJP. $dependents The original file " +
                            "outside the app is not touched. This cannot be undone."
                    )
                },
                confirmButton = {
                    TextButton(
                        enabled = !state.deleting,
                        onClick = { vm.confirmDeleteClip() }
                    ) { Text(if (state.deleting) "Removing..." else "Remove", color = Bad) }
                },
                dismissButton = {
                    TextButton(
                        enabled = !state.deleting,
                        onClick = { vm.cancelDeleteClip() }
                    ) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MutedGray,
            modifier = Modifier.width(110.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = SoftWhite)
    }
}

@Composable
fun GoalRing(progress: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val inset = stroke / 2
            drawArc(
                color = NativeGhost.copy(alpha = 0.25f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = Cyan,
                startAngle = -90f,
                sweepAngle = 360f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { content() }
    }
}
