package com.shadowjp.app.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Mono PCM at a fixed sample rate, samples normalized to [-1, 1]. */
class PcmData(
    val sampleRate: Int,
    val samples: FloatArray
) {
    val durationSec: Float get() = samples.size.toFloat() / sampleRate
    val durationMs: Long get() = (durationSec * 1000f).toLong()

    /** Extract [startMs, endMs) as a new PcmData. */
    fun slice(startMs: Long, endMs: Long): PcmData {
        val s = (startMs * sampleRate / 1000).toInt().coerceIn(0, samples.size)
        val e = (endMs * sampleRate / 1000).toInt().coerceIn(s, samples.size)
        return PcmData(sampleRate, samples.copyOfRange(s, e))
    }
}

/** Minimal 16-bit PCM WAV reader/writer for local take storage. */
object WavFile {

    fun write(file: File, pcm: PcmData) {
        file.parentFile?.mkdirs()
        val dataSize = pcm.samples.size * 2
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray(Charsets.US_ASCII))
            header.putInt(36 + dataSize)
            header.put("WAVE".toByteArray(Charsets.US_ASCII))
            header.put("fmt ".toByteArray(Charsets.US_ASCII))
            header.putInt(16)              // PCM chunk size
            header.putShort(1)             // PCM format
            header.putShort(1)             // mono
            header.putInt(pcm.sampleRate)
            header.putInt(pcm.sampleRate * 2) // byte rate
            header.putShort(2)             // block align
            header.putShort(16)            // bits per sample
            header.put("data".toByteArray(Charsets.US_ASCII))
            header.putInt(dataSize)
            raf.write(header.array())

            val buf = ByteBuffer.allocate(pcm.samples.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (s in pcm.samples) {
                val v = (s.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
                buf.putShort(v)
            }
            raf.write(buf.array())
        }
    }

    fun read(file: File): PcmData {
        RandomAccessFile(file, "r").use { raf ->
            val probe = ByteArray(44)
            raf.readFully(probe)
            val buf = ByteBuffer.wrap(probe).order(ByteOrder.LITTLE_ENDIAN)
            val audioFormat = buf.getShort(22).toInt()
            val channels = buf.getShort(24).toInt()
            val sampleRate = buf.getInt(28)
            val bits = buf.getShort(34).toInt()
            require(audioFormat == 1 && bits == 16) { "Only 16-bit PCM WAV supported" }
            // Walk chunks to find "data".
            var dataOffset = 44
            var dataSize = (raf.length() - 44).toInt()
            raf.seek(12)
            val chunkHeader = ByteArray(8)
            while (raf.filePointer + 8 <= raf.length()) {
                raf.readFully(chunkHeader)
                val id = String(chunkHeader, 0, 4, Charsets.US_ASCII)
                val size = ByteBuffer.wrap(chunkHeader, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                if (id == "data") {
                    dataOffset = raf.filePointer.toInt()
                    dataSize = minOf(size, (raf.length() - raf.filePointer).toInt())
                    break
                }
                raf.skipBytes(size)
            }
            raf.seek(dataOffset.toLong())
            val raw = ByteArray(dataSize)
            raf.readFully(raw)
            val shorts = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            val frames = dataSize / (2 * channels)
            val samples = FloatArray(frames)
            for (i in 0 until frames) {
                var acc = 0f
                for (c in 0 until channels) acc += shorts.short / 32768f
                samples[i] = acc / channels
            }
            return PcmData(sampleRate, samples)
        }
    }
}

/** Linear-interpolation resampler (adequate for speech analysis at 16 kHz). */
object Resampler {
    fun resample(pcm: PcmData, targetRate: Int): PcmData {
        if (pcm.sampleRate == targetRate || pcm.samples.isEmpty()) return pcm
        val ratio = pcm.sampleRate.toDouble() / targetRate
        val outSize = (pcm.samples.size / ratio).toInt()
        if (outSize <= 0) return PcmData(targetRate, FloatArray(0))
        val out = FloatArray(outSize)
        for (i in 0 until outSize) {
            val pos = i * ratio
            val i0 = pos.toInt().coerceAtMost(pcm.samples.size - 1)
            val i1 = (i0 + 1).coerceAtMost(pcm.samples.size - 1)
            val frac = (pos - i0).toFloat()
            out[i] = pcm.samples[i0] * (1f - frac) + pcm.samples[i1] * frac
        }
        return PcmData(targetRate, out)
    }
}
