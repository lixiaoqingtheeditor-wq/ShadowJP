package com.shadowjp.app.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Scoring of a user take against the native reference, after DTW alignment.
 *
 * All scores are in [0, 100]. Every constant below is a documented
 * calibration parameter (see README "Scoring formulas").
 */
object Scorer {

    // ---- Pitch calibration constants ----
    /** Semitone error at which the error term falls to 1/e (~37%). */
    const val PITCH_ERROR_TAU_SEMITONES = 2.5f
    /** Dead zone (semitones) inside which movement between anchors counts as "flat". */
    const val DIRECTION_DEAD_ZONE_ST = 0.3f
    /** Movements differing by less than this many semitones count as agreeing. */
    const val DIRECTION_MATCH_TOLERANCE_ST = 0.5f
    /** Weight of mean-error vs. direction agreement in the pitch base score. */
    const val PITCH_ERROR_WEIGHT = 0.75f
    /** Max fraction of the pitch score that drop displacement can remove. */
    const val DROP_MAX_PENALTY = 0.25f
    /** Penalty per full-phrase (1.0) of drop-location displacement. */
    const val DROP_PENALTY_PER_DISPLACEMENT = 1.25f

    // ---- Timing calibration constants ----
    /** Weight of duration ratio vs. DTW warp deviation. */
    const val TIMING_DURATION_WEIGHT = 0.4f
    /** Normalized warp deviation at which the warp term falls to 1/e. */
    const val TIMING_WARP_TAU = 0.10f

    // ---- Intensity calibration constants ----
    /** dB error at which the intensity term falls to 1/e. */
    const val INTENSITY_ERROR_TAU_DB = 6.0f
    /** Fraction of the intensity score removed when all frames disagree on silence. */
    const val INTENSITY_SILENCE_MISMATCH_WEIGHT = 0.5f

    // ---- Overall weights (fixed by product spec) ----
    const val W_PITCH = 0.50f
    const val W_TIMING = 0.30f
    const val W_INTENSITY = 0.20f

    data class Scores(
        val overall: Float,
        val pitch: Float,
        val timing: Float,
        val intensity: Float,
        val meanSemitoneError: Float,
        val directionAgreement: Float,
        val dropDisplacement: Float,
        val durationRatio: Float,
        val meanWarpDeviation: Float,
        val meanIntensityErrorDb: Float
    )

    fun score(
        nativeSt: FloatArray,
        userSt: FloatArray,
        nativeIntensityDb: FloatArray,
        userIntensityDb: FloatArray,
        dtw: Dtw.Result,
        nativeDurationSec: Float,
        userDurationSec: Float
    ): Scores {
        val path = dtw.path

        // ---------- PITCH ----------
        var errSum = 0.0
        var errCount = 0
        var dirAgree = 0
        var dirTotal = 0
        // Direction agreement is measured between successive anchors: pairs of
        // aligned frames where BOTH sides are voiced. Anchoring (instead of
        // raw consecutive path steps) lets a movement spanning an unvoiced
        // gap - exactly where Japanese accent drops tend to sit - count.
        var anchorI = -1
        var anchorJ = -1
        for (k in path.indices) {
            val (i, j) = path[k]
            val a = nativeSt[i]
            val b = userSt[j]
            if (a.isNaN() || b.isNaN()) continue
            errSum += abs(a - b)
            errCount++
            if (anchorI >= 0) {
                val dA = a - nativeSt[anchorI]
                val dB = b - userSt[anchorJ]
                val flatA = abs(dA) <= DIRECTION_DEAD_ZONE_ST
                val flatB = abs(dB) <= DIRECTION_DEAD_ZONE_ST
                if (!(flatA && flatB)) {
                    // At least one side moved: does the other side move with it?
                    dirTotal++
                    val agree = abs(dA - dB) <= DIRECTION_MATCH_TOLERANCE_ST ||
                            (!flatA && !flatB && (dA > 0f) == (dB > 0f))
                    if (agree) dirAgree++
                }
            }
            anchorI = i
            anchorJ = j
        }
        val meanErr = if (errCount > 0) (errSum / errCount).toFloat() else 12f
        // No directional evidence (both contours flat): the error term alone
        // carries the pitch score, so treat direction as fully agreeing.
        val dirAgreement = if (dirTotal > 0) dirAgree.toFloat() / dirTotal else 1f
        val dropDisplacement = dropDisplacement(nativeSt, userSt)

        val errorTerm = (100f * exp(-meanErr / PITCH_ERROR_TAU_SEMITONES))
        val dirTerm = 100f * dirAgreement
        val pitchBase = PITCH_ERROR_WEIGHT * errorTerm + (1f - PITCH_ERROR_WEIGHT) * dirTerm
        val dropPenalty = min(DROP_MAX_PENALTY, dropDisplacement * DROP_PENALTY_PER_DISPLACEMENT)
        val pitch = (pitchBase * (1f - dropPenalty)).coerceIn(0f, 100f)

        // ---------- TIMING ----------
        val durRatio = if (max(nativeDurationSec, userDurationSec) > 0f)
            min(nativeDurationSec, userDurationSec) / max(nativeDurationSec, userDurationSec)
        else 1f
        val n = nativeSt.size
        val m = userSt.size
        var devSum = 0.0
        for ((i, j) in path) {
            val ni = if (n > 1) i.toFloat() / (n - 1) else 0f
            val nj = if (m > 1) j.toFloat() / (m - 1) else 0f
            devSum += abs(ni - nj)
        }
        val meanDev = if (path.isNotEmpty()) (devSum / path.size).toFloat() else 0f
        val timing = (100f * (TIMING_DURATION_WEIGHT * durRatio +
                (1f - TIMING_DURATION_WEIGHT) * exp(-meanDev / TIMING_WARP_TAU)))
            .coerceIn(0f, 100f)

        // ---------- INTENSITY ----------
        var dbErrSum = 0.0
        var dbErrCount = 0
        var silMismatch = 0
        for ((i, j) in path) {
            val a = nativeIntensityDb[i]
            val b = userIntensityDb[j]
            val aActive = !a.isNaN()
            val bActive = !b.isNaN()
            if (aActive && bActive) {
                dbErrSum += abs(a - b)
                dbErrCount++
            } else if (aActive != bActive) {
                silMismatch++
            }
        }
        val meanDbErr = if (dbErrCount > 0) (dbErrSum / dbErrCount).toFloat() else 12f
        val silMismatchFrac = if (path.isNotEmpty()) silMismatch.toFloat() / path.size else 0f
        val intensity = (100f * exp(-meanDbErr / INTENSITY_ERROR_TAU_DB) *
                (1f - INTENSITY_SILENCE_MISMATCH_WEIGHT * silMismatchFrac))
            .coerceIn(0f, 100f)

        // ---------- OVERALL ----------
        val overall = (W_PITCH * pitch + W_TIMING * timing + W_INTENSITY * intensity)
            .coerceIn(0f, 100f)

        return Scores(
            overall = round1(overall),
            pitch = round1(pitch),
            timing = round1(timing),
            intensity = round1(intensity),
            meanSemitoneError = round1(meanErr),
            directionAgreement = round1(dirAgreement * 100f) / 100f,
            dropDisplacement = round1(dropDisplacement * 100f) / 100f,
            durationRatio = round1(durRatio * 100f) / 100f,
            meanWarpDeviation = round1(meanDev * 1000f) / 1000f,
            meanIntensityErrorDb = round1(meanDbErr)
        )
    }

    /**
     * Location (as fraction of the phrase) of the end of the strongest pitch
     * drop, computed as the largest cumulative negative semitone movement over
     * a window of up to [DROP_WINDOW] voiced steps. Returns |locNative - locUser|.
     */
    fun dropDisplacement(nativeSt: FloatArray, userSt: FloatArray): Float {
        val locN = strongestDropLocation(nativeSt) ?: return 0f
        val locU = strongestDropLocation(userSt) ?: return 0f
        return abs(locN - locU)
    }

    const val DROP_WINDOW = 4

    private fun strongestDropLocation(st: FloatArray): Float? {
        val voicedIdx = st.indices.filter { !st[it].isNaN() }
        if (voicedIdx.size < DROP_WINDOW + 1) return null
        var bestDrop = -1.5f // ignore trivial wobble; a real accent drop is bigger
        var bestLoc: Float? = null
        for (k in 0 until voicedIdx.size - 1) {
            val end = min(voicedIdx.size - 1, k + DROP_WINDOW)
            for (e in k + 1..end) {
                val drop = st[voicedIdx[k]] - st[voicedIdx[e]]
                if (drop > bestDrop) {
                    bestDrop = drop
                    bestLoc = voicedIdx[e].toFloat() / (st.size - 1).coerceAtLeast(1)
                }
            }
        }
        return bestLoc
    }

    /** Short deterministic verdict keyed to the weakest sub-score. */
    fun verdict(scores: Scores): String {
        val entries = listOf(
            "pitch" to scores.pitch,
            "timing" to scores.timing,
            "intensity" to scores.intensity
        )
        val weakest = entries.minBy { it.second }.first
        return when {
            scores.overall >= 85f ->
                "Excellent take - contour, rhythm and emphasis all line up closely."
            weakest == "pitch" ->
                "Pitch is weakest. Listen for where the native contour drops and mirror that shape, not the absolute pitch."
            weakest == "timing" ->
                "Timing is weakest. Match the native rhythm: keep the same pace and the same pause positions."
            else ->
                "Intensity is weakest. Match the relative emphasis - which parts get louder and which stay soft."
        }
    }

    private fun round1(v: Float): Float = (v * 10f).roundToInt() / 10f
}
