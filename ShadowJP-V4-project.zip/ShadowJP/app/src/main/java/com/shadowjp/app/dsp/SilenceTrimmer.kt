package com.shadowjp.app.dsp

import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Automatic leading/trailing silence trimmer.
 *
 * Uses windowed RMS of the actual PCM signal: a window is "silent" when its
 * level is below [thresholdDb] dBFS. Leading and trailing silent runs longer
 * than [minSilenceMs] are removed; a small [paddingMs] of context is kept so
 * word onsets/offsets are not clipped. Internal pauses are NEVER removed —
 * only the edges are trimmed, because intra-phrase pauses carry timing
 * information that matters for shadowing.
 *
 * Pure Kotlin / JVM — unit-tested.
 */
object SilenceTrimmer {

    const val DEFAULT_THRESHOLD_DB = -45f
    const val DEFAULT_MIN_SILENCE_MS = 250
    const val DEFAULT_PADDING_MS = 120

    data class Result(
        val samples: FloatArray,
        val removedLeadingMs: Long,
        val removedTrailingMs: Long
    ) {
        val trimmedMs: Long get() = removedLeadingMs + removedTrailingMs
    }

    /**
     * Trim leading/trailing silence from [samples].
     *
     * @return a [Result] when anything was trimmed, or null when the signal
     * contains no detectable edge silence (callers keep the original audio).
     */
    fun trim(
        samples: FloatArray,
        sampleRate: Int,
        thresholdDb: Float = DEFAULT_THRESHOLD_DB,
        minSilenceMs: Int = DEFAULT_MIN_SILENCE_MS,
        paddingMs: Int = DEFAULT_PADDING_MS
    ): Result? {
        if (samples.isEmpty()) return null
        val windowMs = 20
        val win = (sampleRate * windowMs / 1000).coerceAtLeast(1)
        val thresholdLinear = Math.pow(10.0, thresholdDb / 20.0).toFloat()

        fun rmsAt(start: Int): Float {
            var sumSq = 0.0
            var n = 0
            var i = start
            val end = minOf(start + win, samples.size)
            while (i < end) {
                val s = samples[i].toDouble()
                sumSq += s * s
                i++
                n++
            }
            return if (n == 0) 0f else sqrt(sumSq / n).toFloat()
        }

        val minSilentWindows = (minSilenceMs / windowMs).coerceAtLeast(1)
        val padSamples = sampleRate * paddingMs / 1000
        val windowCount = (samples.size + win - 1) / win
        if (windowCount <= minSilentWindows * 2) return null

        // First non-silent window from the front.
        var firstActive = -1
        var runSilent = 0
        for (wI in 0 until windowCount) {
            if (rmsAt(wI * win) < thresholdLinear) {
                runSilent++
            } else {
                if (runSilent >= minSilentWindows) firstActive = wI
                break
            }
        }
        // Last non-silent window from the back.
        var lastActive = -1
        runSilent = 0
        for (wI in windowCount - 1 downTo 0) {
            if (rmsAt(wI * win) < thresholdLinear) {
                runSilent++
            } else {
                if (runSilent >= minSilentWindows) lastActive = wI
                break
            }
        }

        if (firstActive < 0 && lastActive < 0) return null // no edge silence
        val start = if (firstActive > 0)
            (firstActive * win - padSamples).coerceIn(0, samples.size) else 0
        val end = if (lastActive >= 0)
            ((lastActive + 1) * win + padSamples).coerceIn(0, samples.size) else samples.size
        if (end <= start) return null
        if (start == 0 && end == samples.size) return null

        return Result(
            samples = samples.copyOfRange(start, end),
            removedLeadingMs = start * 1000L / sampleRate,
            removedTrailingMs = (samples.size - end) * 1000L / sampleRate
        )
    }
}
