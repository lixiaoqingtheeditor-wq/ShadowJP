package com.shadowjp.app.ui.segments

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.Good
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite
import com.shadowjp.app.ui.theme.Warn
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtMs(ms: Long): String = "%d:%05.2f".format(ms / 60000, (ms % 60000) / 1000f)
private fun fmtDate(ts: Long): String =
    SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(ts))

@Composable
fun SegmentsScreen(
    vm: SegmentsViewModel,
    onBack: () -> Unit,
    onPractice: (Long) -> Unit,
    onHistory: (Long) -> Unit
) {
    val segments by vm.segments.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
            }
            Text("Saved segments", style = MaterialTheme.typography.titleLarge, color = SoftWhite)
        }

        if (segments.isEmpty()) {
            Text(
                "No segments yet. Import audio, pick an A-B phrase and shadow it - the phrase is saved automatically.",
                color = MutedGray,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(segments.size) { i ->
                val seg = segments[i]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPractice(seg.id) }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(seg.displayName, color = SoftWhite, maxLines = 1,
                            style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${fmtMs(seg.startMs)} - ${fmtMs(seg.endMs)} · ${fmtDate(seg.createdAt)}",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                        if (seg.transcript.isNotBlank()) {
                            Text(
                                seg.transcript,
                                color = SoftWhite.copy(alpha = 0.75f),
                                maxLines = 2,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    IconButton(onClick = { onHistory(seg.id) }) {
                        Icon(Icons.Default.History, "History", tint = Cyan)
                    }
                    IconButton(onClick = { vm.deleteSegment(seg.id) }) {
                        Icon(Icons.Default.Delete, "Delete", tint = MutedGray)
                    }
                }
            }
        }
    }
}

@Composable
fun SegmentHistoryScreen(
    vm: SegmentsViewModel,
    segmentId: Long,
    onBack: () -> Unit
) {
    LaunchedEffect(segmentId) { vm.loadHistory(segmentId) }
    val takes by vm.history.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
            }
            Text("Take history", style = MaterialTheme.typography.titleLarge, color = SoftWhite)
        }

        if (takes.isEmpty()) {
            Text("No takes yet for this segment.", color = MutedGray)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(takes.size) { i ->
                val t = takes[i]
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(fmtDate(t.createdAt), color = SoftWhite,
                            style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "P ${t.pitchScore.toInt()} · T ${t.timingScore.toInt()} · I ${t.intensityScore.toInt()}" +
                                if (t.trimmed) " · trimmed" else "",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Text(
                        "${t.overallScore.toInt()}",
                        style = MaterialTheme.typography.titleLarge,
                        color = when {
                            t.overallScore >= 80f -> Good
                            t.overallScore >= 60f -> Warn
                            else -> Bad
                        }
                    )
                }
            }
        }
    }
}
