package com.shadowjp.app.audio

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/**
 * Playback of the imported native audio, built on ExoPlayer.
 *
 * Playback speed changes use ExoPlayer's Sonic time-stretcher, which is
 * pitch-preserving by default ([PlaybackParameters] with pitch = 1), so
 * 0.5x/0.75x slow the native speaker down WITHOUT lowering their pitch.
 *
 * A-B looping is driven by a lightweight position poller at 10 ms
 * granularity, which is precise enough for phrase-level looping.
 */
class NativePlayer(private val context: Context, private val scope: CoroutineScope) {

    enum class Speed(val factor: Float, val label: String) {
        HALF(0.5f, "0.5x"),
        THREE_QUARTER(0.75f, "0.75x"),
        FULL(1.0f, "1.0x")
    }

    data class PlayerState(
        val loaded: Boolean = false,
        val playing: Boolean = false,
        val positionMs: Long = 0,
        val durationMs: Long = 0,
        val speed: Speed = Speed.FULL,
        val loopingAB: Boolean = false,
        val error: String? = null
    )

    private var player: ExoPlayer? = null
    private var pollJob: Job? = null

    var aMs: Long = 0
    var bMs: Long = 0

    /** Remaining A-B loop repetitions; -1 = infinite, 0 = stop at B. */
    var loopRepetitionsRemaining: Int = -1

    var onLoopFinished: (() -> Unit)? = null

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(playing = isPlaying)
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            _state.value = _state.value.copy(
                playing = false,
                error = "Playback failed: ${error.errorCodeName}"
            )
        }
    }

    fun load(file: File) {
        release()
        val p = ExoPlayer.Builder(context).build()
        player = p
        p.addListener(listener)
        try {
            p.setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(file)))
            p.prepare()
            p.playWhenReady = false
            _state.value = PlayerState(loaded = true)
            startPolling()
        } catch (e: Exception) {
            _state.value = PlayerState(error = "Could not load audio: ${e.message}")
        }
    }

    fun play() {
        player?.play()
    }

    fun pause() {
        player?.pause()
    }

    fun seekTo(ms: Long) {
        player?.seekTo(ms.coerceAtLeast(0))
    }

    fun setSpeed(speed: Speed) {
        // pitch = 1f is the key: Sonic stretches time without shifting pitch.
        player?.playbackParameters = PlaybackParameters(speed.factor, 1f)
        _state.value = _state.value.copy(speed = speed)
    }

    /** Play [aMs, bMs] exactly [repetitions] times (-1 = infinite). */
    fun playAB(repetitions: Int = -1) {
        val p = player ?: return
        if (bMs <= aMs) return
        loopRepetitionsRemaining = repetitions
        _state.value = _state.value.copy(loopingAB = true)
        p.seekTo(aMs)
        p.play()
    }

    fun stopLoop() {
        loopRepetitionsRemaining = -1
        _state.value = _state.value.copy(loopingAB = false)
        player?.pause()
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                val p = player
                if (p != null) {
                    val pos = p.currentPosition
                    val dur = p.duration.coerceAtLeast(0)
                    _state.value = _state.value.copy(
                        positionMs = pos,
                        durationMs = if (dur > 0) dur else _state.value.durationMs
                    )
                    if (_state.value.loopingAB && bMs > aMs && pos >= bMs - 15) {
                        if (loopRepetitionsRemaining > 0) {
                            loopRepetitionsRemaining--
                            if (loopRepetitionsRemaining == 0) {
                                _state.value = _state.value.copy(loopingAB = false)
                                p.pause()
                                p.seekTo(aMs)
                                onLoopFinished?.invoke()
                            } else {
                                p.seekTo(aMs)
                            }
                        } else {
                            p.seekTo(aMs)
                        }
                    }
                }
                delay(10)
            }
        }
    }

    fun release() {
        pollJob?.cancel()
        pollJob = null
        player?.removeListener(listener)
        player?.release()
        player = null
        _state.value = PlayerState()
    }
}
