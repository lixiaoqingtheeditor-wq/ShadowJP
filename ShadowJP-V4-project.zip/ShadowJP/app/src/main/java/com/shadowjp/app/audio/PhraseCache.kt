package com.shadowjp.app.audio

import java.io.File

/**
 * Tiny in-memory LRU for decoded A-B phrase PCM.
 *
 * Retaking the same phrase must not re-decode the source. Entries are keyed
 * by file identity (path + length + mtime) and the exact A-B window, so a
 * changed file or a changed range can never hit stale PCM.
 *
 * Hard-capped at [MAX_ENTRIES] entries: a 60 s phrase at 16 kHz mono float
 * is ~3.8 MB, so the cache stays within ~8 MB regardless of source length.
 * This is deliberately NOT a full-file PCM cache.
 */
object PhraseCache {

    private const val MAX_ENTRIES = 2

    private data class Key(
        val path: String,
        val length: Long,
        val lastModified: Long,
        val aMs: Long,
        val bMs: Long
    )

    private val lock = Any()
    private val map = object : LinkedHashMap<Key, PcmData>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Key, PcmData>?): Boolean =
            size > MAX_ENTRIES
    }

    fun get(file: File, aMs: Long, bMs: Long): PcmData? {
        if (!file.exists()) return null
        val key = Key(file.absolutePath, file.length(), file.lastModified(), aMs, bMs)
        return synchronized(lock) { map[key] }
    }

    fun put(file: File, aMs: Long, bMs: Long, pcm: PcmData) {
        if (!file.exists()) return
        val key = Key(file.absolutePath, file.length(), file.lastModified(), aMs, bMs)
        synchronized(lock) { map[key] = pcm }
    }

    fun clear() = synchronized(lock) { map.clear() }
}
