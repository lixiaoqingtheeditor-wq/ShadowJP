package com.shadowjp.app.dsp

import kotlin.math.abs
import kotlin.math.min

/**
 * Banded (Sakoe-Chiba) Dynamic Time Warping over normalized pitch contours.
 *
 * Inputs are semitone contours where unvoiced frames are NaN.
 *
 * Local cost between two frames:
 *  - both voiced:      |a - b| capped at [MAX_SEMITONE_COST]
 *  - one voiced only:  [VOICED_MISMATCH_COST] (penalizes voicing disagreement)
 *  - both unvoiced:    0 (silence aligns with silence for free)
 *
 * A Sakoe-Chiba band of width [bandFraction] * max(n, m) (at least
 * |n - m| + 2 and [MIN_BAND]) prevents pathological warping of sequences
 * with very different lengths.
 *
 * The returned path is the list of aligned (nativeIndex, userIndex) pairs.
 */
object Dtw {

    const val MAX_SEMITONE_COST = 12f
    const val VOICED_MISMATCH_COST = 6f
    const val MIN_BAND = 10

    data class Result(
        /** Total accumulated cost of the optimal path. */
        val totalCost: Float,
        /** Average per-step cost = totalCost / pathLength. */
        val meanCost: Float,
        /** Aligned index pairs, monotonically non-decreasing in both axes. */
        val path: List<Pair<Int, Int>>
    )

    fun align(
        native: FloatArray,
        user: FloatArray,
        bandFraction: Float = 0.25f
    ): Result {
        require(native.isNotEmpty() && user.isNotEmpty()) { "DTW inputs must be non-empty" }
        val n = native.size
        val m = user.size
        val band = maxOf((bandFraction * maxOf(n, m)).toInt(), abs(n - m) + 2, MIN_BAND)

        // Rolling-window DP.
        val prev = FloatArray(m) { Float.POSITIVE_INFINITY }
        val cur = FloatArray(m) { Float.POSITIVE_INFINITY }
        // Back-pointer per cell: 0 = diag, 1 = up (advance native), 2 = left (advance user)
        val back = Array(n) { ByteArray(m) }

        for (i in 0 until n) {
            // Center of the diagonal for this row, banded around it.
            val center = (i.toLong() * m / n).toInt()
            val jStart = maxOf(0, center - band)
            val jEnd = minOf(m - 1, center + band)
            for (j in jStart..jEnd) {
                val cost = localCost(native[i], user[j])
                val fromDiag = if (i > 0 && j > 0) prev[j - 1] else Float.POSITIVE_INFINITY
                val fromUp = if (i > 0) prev[j] else Float.POSITIVE_INFINITY
                val fromLeft = if (j > 0) cur[j - 1] else Float.POSITIVE_INFINITY
                var best = fromDiag; var dir: Byte = 0
                if (fromUp < best) { best = fromUp; dir = 1 }
                if (fromLeft < best) { best = fromLeft; dir = 2 }
                cur[j] = if (i == 0 && j == 0) cost else {
                    if (best == Float.POSITIVE_INFINITY) Float.POSITIVE_INFINITY else cost + best
                }
                back[i][j] = dir
            }
            // Reset cells outside the band so stale values never leak.
            for (j in 0 until jStart) cur[j] = Float.POSITIVE_INFINITY
            for (j in jEnd + 1 until m) cur[j] = Float.POSITIVE_INFINITY
            System.arraycopy(cur, 0, prev, 0, m)
            cur.fill(Float.POSITIVE_INFINITY)
        }

        val total = prev[m - 1]
        if (total == Float.POSITIVE_INFINITY) {
            // Degenerate case: band too narrow. Fall back to full DTW.
            return align(native, user, bandFraction = 1.0f)
        }

        // Backtrack.
        val path = ArrayList<Pair<Int, Int>>()
        var i = n - 1
        var j = m - 1
        while (i > 0 || j > 0) {
            path.add(i to j)
            when (back[i][j].toInt()) {
                0 -> { i--; j-- }
                1 -> i--
                else -> j--
            }
            if (i < 0) i = 0
            if (j < 0) j = 0
        }
        path.add(0 to 0)
        path.reverse()

        return Result(
            totalCost = total,
            meanCost = total / path.size,
            path = path
        )
    }

    fun localCost(a: Float, b: Float): Float {
        val aVoiced = !a.isNaN()
        val bVoiced = !b.isNaN()
        return when {
            aVoiced && bVoiced -> min(abs(a - b), MAX_SEMITONE_COST)
            aVoiced != bVoiced -> VOICED_MISMATCH_COST
            else -> 0f
        }
    }
}
