package com.shadowjp.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.shadowjp.app.prefs.PitchRange
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val message by vm.message.collectAsState()
    val context = LocalContext.current
    var showClearConfirm by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri -> if (uri != null) vm.exportCsv(context, uri) }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
                }
                Text("Settings", style = MaterialTheme.typography.titleLarge, color = SoftWhite)
            }

            // Daily goals
            Column {
                Text("Daily practice time goal: ${settings.dailyGoalMinutes} min", color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = settings.dailyGoalMinutes.toFloat(),
                    onValueChange = { vm.setGoal(it.roundToInt()) },
                    valueRange = 5f..60f,
                    steps = 10
                )
            }
            Column {
                Text("Daily takes goal: ${settings.dailyTakeGoal} takes", color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = settings.dailyTakeGoal.toFloat(),
                    onValueChange = { vm.setTakeGoal(it.roundToInt()) },
                    valueRange = 1f..30f,
                    steps = 28
                )
                Text(
                    "A take counts once it is recorded, analyzed and saved. A day counts " +
                        "toward your streak only when BOTH daily goals are met.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
            }

            // Pitch range
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Pitch range", color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PitchRange.entries.forEach { r ->
                        FilterChip(
                            selected = settings.pitchRange == r,
                            onClick = { vm.setPitchRange(r) },
                            label = { Text(r.label.substringBefore(" (")) }
                        )
                    }
                }
                Text("Match this to the speaker's voice, not yours - scoring is range-normalized.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
            }

            // Replay count
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Default A-B replay count", color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3, 5).forEach { n ->
                        FilterChip(
                            selected = settings.defaultReplayCount == n,
                            onClick = { vm.setReplayCount(n) },
                            label = { Text("$n") }
                        )
                    }
                }
            }

            // Silence-trim sensitivity (windowed RMS threshold, dBFS).
            Column {
                Text(
                    "Silence trim threshold: ${"%.0f".format(settings.silenceThresholdDb)} dBFS",
                    color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Higher trims more aggressively; only leading/trailing silence is ever removed.",
                    color = MutedGray,
                    style = MaterialTheme.typography.labelSmall
                )
                Slider(
                    value = settings.silenceThresholdDb,
                    onValueChange = { vm.setSilenceThreshold(it) },
                    valueRange = -60f..-25f
                )
            }

            // Export
            OutlinedButton(
                onClick = { exportLauncher.launch(vm.suggestedFileName()) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export scores as CSV") }

            Spacer(Modifier.height(8.dp))

            // Clear all data
            Button(
                onClick = { showClearConfirm = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Bad)
            ) { Text("Clear all data") }
        }

        message?.let {
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = { TextButton(onClick = { vm.clearMessage() }) { Text("OK") } }
            ) { Text(it) }
        }

        if (showClearConfirm) {
            AlertDialog(
                onDismissRequest = { showClearConfirm = false },
                title = { Text("Delete everything?") },
                text = {
                    Text(
                        "This permanently deletes all imported audio, segments, " +
                            "take history, recordings, and practice statistics. " +
                            "This cannot be undone."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showClearConfirm = false
                        vm.clearAllData()
                    }) { Text("Delete all", color = Bad) }
                },
                dismissButton = {
                    TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
                }
            )
        }
    }
}
