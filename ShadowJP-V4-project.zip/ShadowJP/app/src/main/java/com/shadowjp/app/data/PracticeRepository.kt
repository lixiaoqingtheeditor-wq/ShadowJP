package com.shadowjp.app.data

import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.ShadowDao
import com.shadowjp.app.data.db.TakeEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Practice-time accounting and streak logic.
 *
 * PRACTICE TIME RULE (see README): only active practice counts -
 * seconds of native-phrase playback plus seconds of microphone recording,
 * accumulated while the user is on the practice flow. App-open time,
 * browsing and idle time never count.
 *
 * TAKE RULE (v3, see README): a take counts toward the daily takes goal when
 * it has been recorded, successfully analyzed AND persisted. The takes table
 * is the only source of truth - abandoned recordings, failed analyses and
 * unsaved recordings never reach the table and therefore never count.
 *
 * STREAK RULE (v3, see README): a day counts toward the streak ONLY when
 * BOTH goals were met that day:
 *   practiceSeconds >= dailyGoalMinutes * 60  AND  takes >= dailyTakeGoal
 * Historical per-day goal values are not stored; past days are evaluated
 * against the CURRENT goal settings (documented fallback). Day boundaries
 * are local calendar days. The streak itself lives in [StreakRules] (pure,
 * JVM-unit-tested).
 */
class PracticeRepository(private val dao: ShadowDao) {

    val practiceDays: Flow<List<PracticeDayEntity>> = dao.practiceDays()
    val totalPracticeSeconds: Flow<Int> = dao.totalPracticeSeconds()
    val allTakes: Flow<List<TakeEntity>> = dao.allTakesAscending()

    suspend fun addPracticeSeconds(seconds: Int) {
        if (seconds <= 0) return
        dao.addPracticeSeconds(today(), seconds)
    }

    suspend fun todaySeconds(): Int = dao.practiceDay(today())?.practiceSeconds ?: 0

    /** Completed takes since the start of the given local day. */
    fun takeCountSince(sinceMs: Long): Flow<Int> = dao.takeCountSince(sinceMs)

    /** Epoch millis of local midnight today. */
    fun startOfTodayMs(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    data class StreakInfo(
        val currentStreak: Int,
        val todaySeconds: Int,
        val todayTakes: Int,
        val goalMetToday: Boolean
    )

    suspend fun streak(dailyGoalMinutes: Int, dailyTakeGoal: Int): StreakInfo {
        val secondsByDay = dao.practiceDays().first()
            .associate { it.date to it.practiceSeconds }
        val takesByDay = HashMap<String, Int>()
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (t in dao.allTakesList()) {
            val key = fmt.format(Date(t.createdAt))
            takesByDay[key] = (takesByDay[key] ?: 0) + 1
        }
        val days = (secondsByDay.keys + takesByDay.keys).associateWith { date ->
            StreakRules.DayActivity(
                practiceSeconds = secondsByDay[date] ?: 0,
                takes = takesByDay[date] ?: 0
            )
        }
        val todayKey = today()
        val todayActivity = days[todayKey]
        return StreakInfo(
            currentStreak = StreakRules.currentStreak(
                days, dailyGoalMinutes, dailyTakeGoal, Calendar.getInstance()
            ),
            todaySeconds = todayActivity?.practiceSeconds ?: 0,
            todayTakes = todayActivity?.takes ?: 0,
            goalMetToday = StreakRules.dayQualifies(todayActivity, dailyGoalMinutes, dailyTakeGoal)
        )
    }

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    suspend fun exportCsvRows(): List<TakeEntity> = dao.allTakesList()
}
