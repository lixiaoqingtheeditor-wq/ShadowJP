package com.shadowjp.app.audio

/**
 * Pure timestamp math for range-based decoding.
 *
 * MediaExtractor.seekTo() lands on a sync point at or before the requested
 * position (SEEK_TO_PREVIOUS_SYNC), and decoders may emit priming frames, so
 * the first decoded buffer almost always starts BEFORE the requested start.
 * This helper maps [startUs, endUs) onto frame indices of each decoded
 * output buffer using the buffer's own presentation timestamp, so content
 * preceding the exact requested start is discarded and decoding stops at the
 * requested end. Frame i of a buffer covers
 * [pts + i*1e6/sr, pts + (i+1)*1e6/sr); boundary frames that only partially
 * overlap the requested window are kept, so the effective error is below one
 * frame (62.5 us at 16 kHz).
 */
object RangeCutter {

    /**
     * Returns the [fromIndex, toIndex) frame range of a decoded buffer that
     * overlaps [startUs, endUs), or null when the buffer lies fully outside
     * the window.
     *
     * @param bufferPtsUs presentation timestamp of the buffer's first frame
     * @param frameCount  number of frames (samples per channel) in the buffer
     * @param sampleRate  sample rate of the buffer
     */
    fun frameRange(
        bufferPtsUs: Long,
        frameCount: Int,
        sampleRate: Int,
        startUs: Long,
        endUs: Long
    ): IntRange? {
        if (frameCount <= 0 || endUs <= startUs) return null
        val bufferEndUs = bufferPtsUs + frameCount.toLong() * 1_000_000L / sampleRate
        if (bufferEndUs <= startUs || bufferPtsUs >= endUs) return null

        val from = if (bufferPtsUs >= startUs) 0
        else (((startUs - bufferPtsUs) * sampleRate) / 1_000_000L).toInt()
                .coerceIn(0, frameCount)

        val to = if (bufferEndUs <= endUs) frameCount
        else (((endUs - bufferPtsUs) * sampleRate + 999_999L) / 1_000_000L).toInt()
                .coerceIn(from, frameCount)

        return if (to > from) IntRange(from, to - 1) else null
    }

    /** True when a buffer starting at [bufferPtsUs] is already past [endUs). */
    fun isPastEnd(bufferPtsUs: Long, endUs: Long): Boolean = bufferPtsUs >= endUs
}
