package com.shadowjp.app.audio

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/**
 * Side-by-side native/user comparison playback for the analysis screen.
 *
 * Exactly one of the two clips can play at a time: starting one stops the
 * other. Native playback is restricted to the analyzed A-B phrase; user
 * playback plays the stored take file. No simultaneous mixing.
 */
class ComparisonPlayer(private val context: Context, private val scope: CoroutineScope) {

    enum class Clip { NONE, NATIVE, USER }

    data class State(
        val playing: Clip = Clip.NONE,
        val positionMs: Long = 0
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state

    private var player: ExoPlayer? = null
    private var current: Clip = Clip.NONE
    private var aMs = 0L
    private var bMs = 0L
    private var pollJob: Job? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!isPlaying && player?.playbackState == Player.STATE_ENDED) stop()
            _state.value = _state.value.copy(
                playing = if (isPlaying) current else Clip.NONE
            )
        }

        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
            stop()
        }
    }

    /** Play the native A-B phrase from [path]. */
    fun playNative(path: String, aMs: Long, bMs: Long) {
        this.aMs = aMs
        this.bMs = bMs
        start(File(path), Clip.NATIVE, seekToMs = aMs)
    }

    /** Play the recorded take from [path]. */
    fun playUser(path: String) {
        start(File(path), Clip.USER, seekToMs = 0)
    }

    private fun start(file: File, clip: Clip, seekToMs: Long) {
        stopInternal()
        if (!file.exists()) {
            _state.value = State()
            return
        }
        val p = ExoPlayer.Builder(context).build()
        player = p
        current = clip
        p.addListener(listener)
        p.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        p.prepare()
        p.seekTo(seekToMs)
        p.play()
        _state.value = State(playing = clip, positionMs = seekToMs)
        pollJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                val pos = p.currentPosition
                _state.value = _state.value.copy(positionMs = pos)
                // Native clip stops at B.
                if (current == Clip.NATIVE && bMs > aMs && pos >= bMs) {
                    stop()
                    break
                }
                delay(50)
            }
        }
    }

    fun stop() {
        stopInternal()
        _state.value = State()
    }

    private fun stopInternal() {
        pollJob?.cancel()
        pollJob = null
        player?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        player = null
        current = Clip.NONE
    }

    fun release() = stopInternal()
}
