package com.shadowjp.app.ui.components

/** Accepts mm:ss.mmm, seconds (including decimals), or whole seconds. */
fun parseTimeMs(text: String): Long? {
    val t = text.trim()
    if (t.isEmpty()) return null
    return try {
        if (t.contains(':')) {
            if (t.count { it == ':' } != 1) return null
            val minutes = t.substringBefore(':').toLongOrNull() ?: return null
            val seconds = t.substringAfter(':').toDoubleOrNull() ?: return null
            if (!seconds.isFinite() || minutes < 0 || seconds < 0 || seconds >= 60.0) return null
            if (minutes > Long.MAX_VALUE / 60_000L) return null
            val wholeMinutes = minutes * 60_000L
            val partial = (seconds * 1000.0).toLong()
            if (wholeMinutes > Long.MAX_VALUE - partial) null else wholeMinutes + partial
        } else {
            val seconds = t.toDoubleOrNull() ?: return null
            if (!seconds.isFinite() || seconds < 0.0 || seconds > Long.MAX_VALUE / 1000.0) null
            else (seconds * 1000.0).toLong()
        }
    } catch (_: NumberFormatException) {
        null
    } catch (_: ArithmeticException) {
        null
    }
}

fun formatTimeMs(ms: Long): String {
    val clamped = ms.coerceAtLeast(0)
    val minutes = clamped / 60_000
    val seconds = (clamped % 60_000) / 1000
    val millis = clamped % 1000
    return "%02d:%02d.%03d".format(minutes, seconds, millis)
}
