package com.shadowjp.app.audio

import android.content.Context
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * On-disk cache for waveform peak data.
 *
 * The original audio file stays the single source of truth; cache entries
 * are pure derivatives and can be deleted at any time (they are simply
 * regenerated on the next open).
 *
 * Cache file name: <sha1(absPath)>_<length>_<lastModified>.wf
 *  - The length/mtime suffix is the invalidation mechanism: if the file on
 *    disk changes, its length or mtime changes, the old entry never matches,
 *    and stale files are swept on the next save.
 *  - The path-hash prefix lets clip deletion remove every cached waveform
 *    for a source without needing to know the old file stats.
 *
 * Binary layout: "SJPW" magic, int32 version(=1), int32 bucketCount,
 * then bucketCount * 2 little-endian float32 (min, max) pairs.
 */
class WaveformCache(context: Context) {

    private val dir = File(context.cacheDir, "waveforms").apply { mkdirs() }

    private fun pathHash(path: String): String {
        val digest = MessageDigest.getInstance("SHA-1")
            .digest(path.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.substring(0, 16)
    }

    private fun fileFor(path: String, length: Long, lastModified: Long) =
        File(dir, "${pathHash(path)}_${length}_$lastModified.wf")

    /** Cached min/max pairs for [file], or null on miss/corruption. */
    fun load(file: File): FloatArray? {
        if (!file.exists()) return null
        val f = fileFor(file.absolutePath, file.length(), file.lastModified())
        if (!f.exists()) return null
        return try {
            val bytes = f.readBytes()
            if (bytes.size < 12) return null
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            if (buf.int != MAGIC) return null
            if (buf.int != VERSION) return null
            val buckets = buf.int
            if (buckets <= 0 || bytes.size != 12 + buckets * 8) return null
            val out = FloatArray(buckets * 2)
            for (i in out.indices) out[i] = buf.float
            out
        } catch (e: Exception) {
            null
        }
    }

    /** Persist [peaks] (min/max pairs) for [file]; sweeps stale entries. */
    fun save(file: File, peaks: FloatArray) {
        if (!file.exists() || peaks.isEmpty() || peaks.size % 2 != 0) return
        try {
            val hash = pathHash(file.absolutePath)
            // Sweep stale entries for the same path (changed length/mtime).
            dir.listFiles()?.forEach {
                if (it.name.startsWith("${hash}_") && it.name.endsWith(".wf")) it.delete()
            }
            val buckets = peaks.size / 2
            val buf = ByteBuffer.allocate(12 + peaks.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            buf.putInt(MAGIC)
            buf.putInt(VERSION)
            buf.putInt(buckets)
            for (v in peaks) buf.putFloat(v)
            fileFor(file.absolutePath, file.length(), file.lastModified())
                .writeBytes(buf.array())
        } catch (_: Exception) { /* cache is best-effort by design */ }
    }

    /** Remove every cached waveform belonging to [path] (any file stats). */
    fun deleteFor(path: String) {
        val prefix = "${pathHash(path)}_"
        dir.listFiles()?.forEach {
            if (it.name.startsWith(prefix)) it.delete()
        }
    }

    /** Drop the whole cache (used by Clear All Data). */
    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    companion object {
        private const val MAGIC = 0x534A5057 // "SJPW"
        private const val VERSION = 1
    }
}
