package com.shadowjp.app.prefs

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

/** Pitch range presets used by the YIN extractor. */
enum class PitchRange(val minF0: Float, val maxF0: Float, val label: String) {
    LOW(50f, 300f, "Low (50-300 Hz)"),
    STANDARD(60f, 400f, "Standard (60-400 Hz)"),
    HIGH(100f, 500f, "High (100-500 Hz)")
}

data class Settings(
    val dailyGoalMinutes: Int = 15,
    /**
     * Daily completed-takes goal. Default 5: a small number of focused,
     * fully analyzed repetitions - enough to build a habit without
     * encouraging rushed takes.
     */
    val dailyTakeGoal: Int = 5,
    val pitchRange: PitchRange = PitchRange.STANDARD,
    val defaultReplayCount: Int = 1,
    /** Silence-trim detector threshold in dBFS (windowed RMS). */
    val silenceThresholdDb: Float = com.shadowjp.app.dsp.SilenceTrimmer.DEFAULT_THRESHOLD_DB
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DAILY_GOAL = intPreferencesKey("daily_goal_minutes")
        val DAILY_TAKE_GOAL = intPreferencesKey("daily_take_goal")
        val PITCH_RANGE = stringPreferencesKey("pitch_range")
        val REPLAY_COUNT = intPreferencesKey("default_replay_count")
        val SILENCE_DB = floatPreferencesKey("silence_threshold_db")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            dailyGoalMinutes = p[Keys.DAILY_GOAL] ?: 15,
            dailyTakeGoal = p[Keys.DAILY_TAKE_GOAL] ?: 5,
            pitchRange = p[Keys.PITCH_RANGE]?.let {
                runCatching { PitchRange.valueOf(it) }.getOrNull()
            } ?: PitchRange.STANDARD,
            defaultReplayCount = p[Keys.REPLAY_COUNT] ?: 1,
            silenceThresholdDb = p[Keys.SILENCE_DB]
                ?: com.shadowjp.app.dsp.SilenceTrimmer.DEFAULT_THRESHOLD_DB
        )
    }

    suspend fun setDailyGoalMinutes(minutes: Int) {
        context.dataStore.edit { it[Keys.DAILY_GOAL] = minutes.coerceIn(1, 180) }
    }

    suspend fun setDailyTakeGoal(takes: Int) {
        context.dataStore.edit { it[Keys.DAILY_TAKE_GOAL] = takes.coerceIn(1, 60) }
    }

    suspend fun setPitchRange(range: PitchRange) {
        context.dataStore.edit { it[Keys.PITCH_RANGE] = range.name }
    }

    suspend fun setDefaultReplayCount(count: Int) {
        context.dataStore.edit { it[Keys.REPLAY_COUNT] = count.coerceIn(1, 10) }
    }

    suspend fun setSilenceThresholdDb(db: Float) {
        context.dataStore.edit { it[Keys.SILENCE_DB] = db.coerceIn(-60f, -25f) }
    }
}
