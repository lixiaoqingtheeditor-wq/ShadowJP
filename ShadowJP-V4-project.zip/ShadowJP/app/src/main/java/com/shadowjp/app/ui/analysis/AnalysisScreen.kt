package com.shadowjp.app.ui.analysis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.compose.ui.platform.LocalContext
import com.shadowjp.app.AnalysisResultStore
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.audio.AudioDecoder
import com.shadowjp.app.audio.ComparisonPlayer
import com.shadowjp.app.dsp.AnalysisEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.Good
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.NativeGhost
import com.shadowjp.app.ui.theme.SoftWhite
import com.shadowjp.app.ui.theme.Warn

private fun scoreColor(v: Float): Color = when {
    v >= 80f -> Good
    v >= 60f -> Warn
    else -> Bad
}

/**
 * Draws one overlaid contour pair. Both series use NaN for unvoiced/silent
 * frames, which break the polyline - unvoiced regions are shown as explicit
 * gaps with faint ticks at the baseline, never as fake interpolated pitch.
 * X axis = normalized position within each contour's own duration.
 */
@Composable
private fun ContourGraph(
    native: FloatArray,
    user: FloatArray,
    yMin: Float,
    yMax: Float,
    title: String,
    unit: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = SoftWhite)
            Spacer(Modifier.width(10.dp))
            LegendDot(NativeGhost, "native")
            Spacer(Modifier.width(8.dp))
            LegendDot(Cyan, "you")
            Spacer(Modifier.weight(1f))
            Text(unit, style = MaterialTheme.typography.labelSmall, color = MutedGray)
        }
        Spacer(Modifier.height(6.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            val w = size.width
            val h = size.height
            val range = (yMax - yMin).coerceAtLeast(0.001f)
            fun yOf(v: Float) = h - ((v - yMin) / range).coerceIn(0f, 1f) * h

            // Zero reference line.
            drawLine(
                color = NativeGhost.copy(alpha = 0.35f),
                start = Offset(0f, yOf(0f)),
                end = Offset(w, yOf(0f)),
                strokeWidth = 1f
            )

            fun drawSeries(values: FloatArray, color: Color, stroke: Float) {
                if (values.isEmpty()) return
                val path = Path()
                var pen = false
                for (i in values.indices) {
                    val v = values[i]
                    val x = i.toFloat() / (values.size - 1).coerceAtLeast(1) * w
                    if (v.isNaN()) {
                        pen = false
                        // explicit unvoiced marker: faint tick at the baseline
                        drawLine(
                            color = color.copy(alpha = 0.22f),
                            start = Offset(x, h - 3.dp.toPx()),
                            end = Offset(x, h),
                            strokeWidth = 1.5f
                        )
                    } else {
                        val y = yOf(v)
                        if (!pen) { path.moveTo(x, y); pen = true }
                        else path.lineTo(x, y)
                    }
                }
                drawPath(path, color = color, style = Stroke(width = stroke))
            }

            drawSeries(native, NativeGhost, 2.dp.toPx())
            drawSeries(user, Cyan, 2.5f.dp.toPx())
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.width(14.dp).height(3.dp)) {
            drawLine(color, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), strokeWidth = size.height)
        }
        Spacer(Modifier.width(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MutedGray)
    }
}

private fun exportStamp(): String =
    SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date())

@Composable
fun AnalysisScreen(
    app: ShadowApp,
    store: AnalysisResultStore,
    onRetake: () -> Unit,
    onDone: () -> Unit
) {
    val result = store.last

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Take analysis",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = SoftWhite
        )

        when (result) {
            null -> {
                Text("No analysis available yet.", color = MutedGray)
                OutlinedButton(onClick = onRetake) { Text("Back") }
            }
            is AnalysisEngine.Result.Failure -> {
                Text(result.reason.message, color = Bad)
                OutlinedButton(onClick = onRetake) { Text("Try again") }
            }
            is AnalysisEngine.Result.Success -> {
                val a = result.analysis
                val s = a.scores

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "${s.overall.toInt()}",
                            style = MaterialTheme.typography.displayLarge,
                            fontWeight = FontWeight.Bold,
                            color = scoreColor(s.overall)
                        )
                        Text("overall", color = MutedGray, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            SubScore("Pitch", s.pitch, "50%")
                            SubScore("Timing", s.timing, "30%")
                            SubScore("Intensity", s.intensity, "20%")
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            a.verdict,
                            color = SoftWhite,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        ContourGraph(
                            native = a.nativeSemitones,
                            user = a.userSemitones,
                            yMin = -12f, yMax = 12f,
                            title = "Pitch contour",
                            unit = "semitones vs own median"
                        )
                        Spacer(Modifier.height(16.dp))
                        ContourGraph(
                            native = a.nativeIntensity,
                            user = a.userIntensity,
                            yMin = -20f, yMax = 20f,
                            title = "Intensity contour",
                            unit = "dB vs own mean"
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "native ${fmtDur(a.nativeDurationSec)} · you ${fmtDur(a.userDurationSec)}",
                        color = MutedGray, style = MaterialTheme.typography.labelSmall
                    )
                    Text(
                        "median F0: native ${a.nativeMedianF0.toInt()} Hz / you ${a.userMedianF0.toInt()} Hz",
                        color = MutedGray, style = MaterialTheme.typography.labelSmall
                    )
                }

                CompareCard(app = app, store = store)

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onRetake, modifier = Modifier.weight(1f)) {
                        Text("Retake")
                    }
                    Button(onClick = onDone, modifier = Modifier.weight(1f)) {
                        Text("Done")
                    }
                }
            }
        }
    }
}

@Composable
private fun SubScore(label: String, value: Float, weight: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "${value.toInt()}",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = scoreColor(value)
        )
        Text(label, style = MaterialTheme.typography.labelMedium, color = SoftWhite)
        Text("weight $weight", style = MaterialTheme.typography.labelSmall, color = MutedGray)
    }
}

private fun fmtDur(sec: Float) = "%.1fs".format(sec)


/**
 * Direct auditory comparison: Play Native (the analyzed A-B phrase) vs
 * Play My Recording (the stored take) - never both at once - plus local
 * WAV export of either artifact through the system save picker.
 */
@Composable
private fun CompareCard(app: ShadowApp, store: AnalysisResultStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ComparisonPlayer(context, scope) }
    val pState by player.state.collectAsState()
    var exportMsg by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) { onDispose { player.release() } }

    val nativePath = store.nativePath
    val takePath = store.takePath

    var exportNative by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("audio/wav")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val forNative = exportNative
        scope.launch {
            val result = if (!forNative) {
                takePath?.let { app.audioLibrary.exportTakeFile(uri, it) }
            } else {
                // Export native segment: range-decode exactly A..B (no
                // full-file decode), then write WAV.
                val np = nativePath
                if (np == null) null
                else {
                    val pcm = withContext(Dispatchers.Default) {
                        when (val d = AudioDecoder.decodeRange(
                            app, File(np), store.aMs, store.bMs
                        )) {
                            is AudioDecoder.DecodeResult.Ok -> d.pcm
                            is AudioDecoder.DecodeResult.Error -> null
                        }
                    }
                    pcm?.let { app.audioLibrary.exportWav(uri, it) }
                }
            }
            exportMsg = when (result) {
                is com.shadowjp.app.data.AudioLibraryRepository.ExportResult.Ok ->
                    "Exported ${result.bytes / 1024} KB WAV."
                is com.shadowjp.app.data.AudioLibraryRepository.ExportResult.Error ->
                    result.message
                null -> "Nothing to export."
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "Listen & compare",
                style = MaterialTheme.typography.labelMedium,
                color = SoftWhite
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        if (pState.playing == ComparisonPlayer.Clip.NATIVE) player.stop()
                        else nativePath?.let { player.playNative(it, store.aMs, store.bMs) }
                    },
                    enabled = nativePath != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (pState.playing == ComparisonPlayer.Clip.NATIVE)
                            Icons.Default.Stop else Icons.Default.GraphicEq,
                        null, tint = NativeGhost, modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (pState.playing == ComparisonPlayer.Clip.NATIVE) "Stop" else "Play native",
                        color = SoftWhite
                    )
                }
                Button(
                    onClick = {
                        if (pState.playing == ComparisonPlayer.Clip.USER) player.stop()
                        else takePath?.let { player.playUser(it) }
                    },
                    enabled = takePath != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (pState.playing == ComparisonPlayer.Clip.USER)
                            Icons.Default.Stop else Icons.Default.Mic,
                        null, modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (pState.playing == ComparisonPlayer.Clip.USER) "Stop" else "Play my recording"
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(
                    onClick = {
                        exportNative = true
                        exportLauncher.launch("native_segment_${exportStamp()}.wav")
                    },
                    enabled = nativePath != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FileDownload, null, tint = MutedGray,
                        modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Export native", color = MutedGray)
                }
                TextButton(
                    onClick = {
                        exportNative = false
                        exportLauncher.launch("my_take_${exportStamp()}.wav")
                    },
                    enabled = takePath != null,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FileDownload, null, tint = MutedGray,
                        modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Export my take", color = MutedGray)
                }
            }
            exportMsg?.let {
                Text(it, color = MutedGray, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
