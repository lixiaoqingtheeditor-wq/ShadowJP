package com.shadowjp.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class SegmentWithSource(
    val id: Long,
    val audioSourceId: Long,
    val startMs: Long,
    val endMs: Long,
    val transcript: String,
    val createdAt: Long,
    val displayName: String,
    val localPath: String,
    val sourceDurationMs: Long
)

@Dao
interface ShadowDao {

    // ---- audio sources ----
    @Insert
    suspend fun insertAudioSource(source: AudioSourceEntity): Long

    @Query("SELECT * FROM audio_sources ORDER BY importedAt DESC")
    fun audioSources(): Flow<List<AudioSourceEntity>>

    @Query("SELECT * FROM audio_sources WHERE id = :id")
    suspend fun audioSource(id: Long): AudioSourceEntity?

    @Query("DELETE FROM audio_sources WHERE id = :id")
    suspend fun deleteAudioSource(id: Long)

    /** Number of OTHER audio sources referencing the same file path. */
    @Query("SELECT COUNT(*) FROM audio_sources WHERE localPath = :path AND id != :excludeId")
    suspend fun otherSourcesWithPath(path: String, excludeId: Long): Int

    // ---- segments ----
    @Insert
    suspend fun insertSegment(segment: SegmentEntity): Long

    @Transaction
    @Query(
        """SELECT s.id AS id, s.audioSourceId AS audioSourceId, s.startMs AS startMs,
                  s.endMs AS endMs, s.transcript AS transcript, s.createdAt AS createdAt,
                  a.displayName AS displayName, a.localPath AS localPath,
                  a.durationMs AS sourceDurationMs
           FROM segments s JOIN audio_sources a ON a.id = s.audioSourceId
           ORDER BY s.createdAt DESC"""
    )
    fun segmentsWithSource(): Flow<List<SegmentWithSource>>

    @Transaction
    @Query(
        """SELECT s.id AS id, s.audioSourceId AS audioSourceId, s.startMs AS startMs,
                  s.endMs AS endMs, s.transcript AS transcript, s.createdAt AS createdAt,
                  a.displayName AS displayName, a.localPath AS localPath,
                  a.durationMs AS sourceDurationMs
           FROM segments s JOIN audio_sources a ON a.id = s.audioSourceId
           WHERE s.id = :segmentId"""
    )
    suspend fun segmentWithSource(segmentId: Long): SegmentWithSource?

    @Query("SELECT EXISTS(SELECT 1 FROM segments WHERE audioSourceId = :audioSourceId AND startMs = :startMs AND endMs = :endMs)")
    suspend fun segmentExists(audioSourceId: Long, startMs: Long, endMs: Long): Boolean

    @Query("DELETE FROM segments WHERE id = :id")
    suspend fun deleteSegment(id: Long)

    @Query("UPDATE segments SET transcript = :transcript WHERE id = :id")
    suspend fun updateSegmentTranscript(id: Long, transcript: String)

    @Query("SELECT * FROM segments WHERE audioSourceId = :sourceId")
    suspend fun segmentsForSource(sourceId: Long): List<SegmentEntity>

    @Query("SELECT COUNT(*) FROM segments WHERE audioSourceId = :sourceId")
    suspend fun segmentCountForSource(sourceId: Long): Int

    @Query("DELETE FROM segments WHERE audioSourceId = :sourceId")
    suspend fun deleteSegmentsForSource(sourceId: Long)

    // ---- takes ----
    @Insert
    suspend fun insertTake(take: TakeEntity): Long

    @Query("SELECT * FROM takes WHERE segmentId = :segmentId ORDER BY createdAt DESC")
    fun takesForSegment(segmentId: Long): Flow<List<TakeEntity>>

    @Query("SELECT * FROM takes ORDER BY createdAt ASC")
    fun allTakesAscending(): Flow<List<TakeEntity>>

    @Query("SELECT * FROM takes ORDER BY createdAt ASC")
    suspend fun allTakesList(): List<TakeEntity>

    @Query("SELECT COUNT(*) FROM takes")
    fun takeCount(): Flow<Int>

    /** Takes created at/after [sinceMs] (epoch millis) - for "today" counts. */
    @Query("SELECT COUNT(*) FROM takes WHERE createdAt >= :sinceMs")
    fun takeCountSince(sinceMs: Long): Flow<Int>

    @Query("SELECT * FROM takes WHERE segmentId = :segmentId ORDER BY createdAt ASC")
    suspend fun takesForSegmentList(segmentId: Long): List<TakeEntity>

    @Query("SELECT * FROM takes WHERE segmentId IN (SELECT id FROM segments WHERE audioSourceId = :sourceId)")
    suspend fun takesForSource(sourceId: Long): List<TakeEntity>

    @Query("SELECT COUNT(*) FROM takes WHERE segmentId IN (SELECT id FROM segments WHERE audioSourceId = :sourceId)")
    suspend fun takeCountForSource(sourceId: Long): Int

    @Query("DELETE FROM takes WHERE segmentId IN (SELECT id FROM segments WHERE audioSourceId = :sourceId)")
    suspend fun deleteTakesForSource(sourceId: Long)

    /** Number of OTHER takes referencing the same recording file. */
    @Query(
        "SELECT COUNT(*) FROM takes WHERE id != :excludeTakeId AND " +
            "(recordingPath = :path OR originalRecordingPath = :path)"
    )
    suspend fun otherTakesWithRecordingPath(path: String, excludeTakeId: Long): Int

    /**
     * One-clip deletion policy (v3): the clip's takes and segments go first,
     * then the clip row itself - a single transaction, so the DB can never
     * end up with segments pointing at a missing source.
     */
    @Transaction
    suspend fun deleteClipCascade(sourceId: Long) {
        deleteTakesForSource(sourceId)
        deleteSegmentsForSource(sourceId)
        deleteAudioSource(sourceId)
    }

    // ---- practice days ----
    @Query(
        """INSERT INTO practice_days (date, practiceSeconds) VALUES (:date, :seconds)
           ON CONFLICT(date) DO UPDATE SET practiceSeconds = practiceSeconds + :seconds"""
    )
    suspend fun addPracticeSeconds(date: String, seconds: Int)

    @Query("SELECT * FROM practice_days")
    fun practiceDays(): Flow<List<PracticeDayEntity>>

    @Query("SELECT * FROM practice_days WHERE date = :date")
    suspend fun practiceDay(date: String): PracticeDayEntity?

    @Query("SELECT COALESCE(SUM(practiceSeconds), 0) FROM practice_days")
    fun totalPracticeSeconds(): Flow<Int>

    // ---- destructive ----
    @Query("DELETE FROM takes")
    suspend fun clearTakes()

    @Query("DELETE FROM segments")
    suspend fun clearSegments()

    @Query("DELETE FROM audio_sources")
    suspend fun clearAudioSources()

    @Query("DELETE FROM practice_days")
    suspend fun clearPracticeDays()
}
