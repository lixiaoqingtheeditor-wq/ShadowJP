package com.shadowjp.app.ui.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.TakeEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class StatsUiState(
    val days: List<PracticeDayEntity> = emptyList(),
    val takes: List<TakeEntity> = emptyList(),
    val streak: Int = 0,
    val totalSeconds: Int = 0,
    val goalMinutes: Int = 15,
    val takeGoal: Int = 5,
    val todayTakes: Int = 0
) {
    val avgPitch: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.pitchScore }.average().toFloat()
    val avgTiming: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.timingScore }.average().toFloat()
    val avgIntensity: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.intensityScore }.average().toFloat()

    /** Completed takes per local calendar day ("yyyy-MM-dd" -> count). */
    val takesByDate: Map<String, Int>
        get() {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val map = HashMap<String, Int>()
            for (t in takes) {
                val key = fmt.format(Date(t.createdAt))
                map[key] = (map[key] ?: 0) + 1
            }
            return map
        }
}

class StatsViewModel(private val app: ShadowApp) : ViewModel() {

    private val streak = MutableStateFlow(0)

    val state: StateFlow<StatsUiState> = combine(
        app.practice.practiceDays,
        app.practice.allTakes,
        app.practice.totalPracticeSeconds,
        app.settings.settings
    ) { days, takes, total, settings ->
        StatsUiState(
            days = days,
            takes = takes,
            streak = streak.value,
            totalSeconds = total,
            goalMinutes = settings.dailyGoalMinutes,
            takeGoal = settings.dailyTakeGoal,
            todayTakes = takes.count { it.createdAt >= app.practice.startOfTodayMs() }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatsUiState())

    init {
        viewModelScope.launch {
            combine(
                app.settings.settings,
                app.practice.allTakes,
                app.practice.practiceDays
            ) { s, _, _ -> s }.collect { s ->
                streak.value =
                    app.practice.streak(s.dailyGoalMinutes, s.dailyTakeGoal).currentStreak
            }
        }
    }
}
