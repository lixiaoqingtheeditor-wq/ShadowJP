package com.shadowjp.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.AudioLibraryRepository
import com.shadowjp.app.data.db.AudioSourceEntity
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.SegmentWithSource
import com.shadowjp.app.data.db.TakeEntity
import com.shadowjp.app.prefs.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val todaySeconds: Int = 0,
    val goalMinutes: Int = 15,
    val todayTakes: Int = 0,
    val takeGoal: Int = 5,
    val streak: Int = 0,
    val totalSeconds: Int = 0,
    val takeCount: Int = 0,
    val sources: List<AudioSourceEntity> = emptyList(),
    val segments: List<SegmentWithSource> = emptyList(),
    val importing: Boolean = false,
    val importError: String? = null,
    /** Clip pending deletion confirmation (with real dependent counts). */
    val deleteCandidate: AudioLibraryRepository.ClipDeletionInfo? = null,
    val deleting: Boolean = false,
    val deleteMessage: String? = null
) {
    val goalSeconds: Int get() = goalMinutes * 60

    /** 0..1 for indicator fill; raw ratio for the label (may exceed 1). */
    val timeProgress: Float get() =
        if (goalSeconds <= 0) 0f else todaySeconds.toFloat() / goalSeconds
    val takeProgress: Float get() =
        if (takeGoal <= 0) 0f else todayTakes.toFloat() / takeGoal
}

class HomeViewModel(private val app: ShadowApp) : ViewModel() {

    private val importing = MutableStateFlow(false)
    private val importError = MutableStateFlow<String?>(null)
    private val streak = MutableStateFlow(0)
    private val deleteCandidate =
        MutableStateFlow<AudioLibraryRepository.ClipDeletionInfo?>(null)
    private val deleting = MutableStateFlow(false)
    private val deleteMessage = MutableStateFlow<String?>(null)

    /** Re-emits so "today" counts roll over at midnight while the screen is open. */
    private val dayTicker = flow {
        while (true) {
            emit(Unit)
            delay(30_000)
        }
    }

    val state: StateFlow<HomeUiState> = combine(
        app.practice.practiceDays,
        app.practice.totalPracticeSeconds,
        app.settings.settings,
        app.audioLibrary.audioSources,
        app.audioLibrary.segments,
        combine(importing, importError, deleteCandidate, deleting, deleteMessage) { it },
        combine(app.practice.allTakes, dayTicker) { takes, _ -> takes },
        streak
    ) { arr ->
        val days = arr[0] as List<*>
        val total = arr[1] as Int
        val settings = arr[2] as Settings
        val sources = arr[3] as List<*>
        val segments = arr[4] as List<*>
        val misc = arr[5] as Array<*>
        val takes = arr[6] as List<*>
        val todayKey = app.practice.today()
        val dayStart = app.practice.startOfTodayMs()
        @Suppress("UNCHECKED_CAST")
        HomeUiState(
            todaySeconds = (days as List<PracticeDayEntity>)
                .firstOrNull { it.date == todayKey }?.practiceSeconds ?: 0,
            goalMinutes = settings.dailyGoalMinutes,
            todayTakes = (takes as List<TakeEntity>).count { it.createdAt >= dayStart },
            takeGoal = settings.dailyTakeGoal,
            streak = streak.value,
            totalSeconds = total,
            takeCount = takes.size,
            sources = sources as List<AudioSourceEntity>,
            segments = segments as List<SegmentWithSource>,
            importing = misc[0] as Boolean,
            importError = misc[1] as String?,
            deleteCandidate =
                misc[2] as AudioLibraryRepository.ClipDeletionInfo?,
            deleting = misc[3] as Boolean,
            deleteMessage = misc[4] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    init {
        // Streak depends on BOTH daily goals and on the underlying activity;
        // recompute when settings, takes or practice days change.
        viewModelScope.launch {
            combine(
                app.settings.settings,
                app.practice.allTakes,
                app.practice.practiceDays
            ) { s, _, _ -> s }.collect { s ->
                streak.value =
                    app.practice.streak(s.dailyGoalMinutes, s.dailyTakeGoal).currentStreak
            }
        }
    }

    fun importAudio(uri: android.net.Uri) {
        viewModelScope.launch {
            importing.value = true
            importError.value = null
            when (val r = app.audioLibrary.import(uri)) {
                is AudioLibraryRepository.ImportResult.Ok -> Unit
                is AudioLibraryRepository.ImportResult.Error -> importError.value = r.message
            }
            importing.value = false
        }
    }

    fun clearImportError() {
        importError.value = null
    }

    // ---------------- individual clip deletion ----------------

    /** Load real dependent counts and show the confirmation dialog. */
    fun requestDeleteClip(sourceId: Long) {
        viewModelScope.launch {
            deleteCandidate.value = app.audioLibrary.clipDeletionInfo(sourceId)
        }
    }

    /** Cancel leaves everything untouched. */
    fun cancelDeleteClip() {
        deleteCandidate.value = null
    }

    fun confirmDeleteClip() {
        val info = deleteCandidate.value ?: return
        viewModelScope.launch {
            deleting.value = true
            when (val r = app.audioLibrary.deleteClip(info.sourceId)) {
                is AudioLibraryRepository.DeleteClipResult.Ok ->
                    deleteMessage.value =
                        "Removed \"${info.displayName}\" with ${r.segmentsRemoved} segment(s) " +
                            "and ${r.takesRemoved} take(s)."
                is AudioLibraryRepository.DeleteClipResult.Error ->
                    deleteMessage.value = r.message
            }
            deleting.value = false
            deleteCandidate.value = null
        }
    }

    fun clearDeleteMessage() {
        deleteMessage.value = null
    }
}
