package com.shadowjp.app.dsp

import kotlin.math.log2

/** One analysis frame of pitch data. */
data class PitchFrame(
    /** Frame center time in seconds. */
    val timeSec: Float,
    /** Estimated fundamental frequency in Hz. Only meaningful when [voiced] is true. */
    val f0Hz: Float,
    /** Whether this frame was classified as voiced speech. */
    val voiced: Boolean,
    /** YIN-based confidence in [0, 1]. 0 for unvoiced frames. */
    val confidence: Float
)

/** One analysis frame of intensity data. */
data class IntensityFrame(
    val timeSec: Float,
    /** RMS level in dBFS (0 = full scale). Silent frames are clamped to [MIN_DBFS]. */
    val dbfs: Float,
    /** True when the frame RMS is below the silence gate. */
    val silent: Boolean
)

/** Pitch contour for one speaker over one phrase. */
class PitchContour(val frames: List<PitchFrame>) {

    val voicedFrames: List<PitchFrame> by lazy { frames.filter { it.voiced } }

    /** Median F0 over voiced frames, or NaN when there are no voiced frames. */
    val medianVoicedF0: Float by lazy {
        val voiced = voicedFrames
        if (voiced.isEmpty()) Float.NaN
        else {
            val sorted = voiced.map { it.f0Hz }.sorted()
            if (sorted.size % 2 == 1) sorted[sorted.size / 2]
            else ((sorted[sorted.size / 2 - 1] + sorted[sorted.size / 2]) / 2f)
        }
    }

    /**
     * Speaker-normalized representation: voiced frames become semitone offsets
     * relative to this contour's median voiced F0; unvoiced frames become NaN.
     */
    val semitoneContour: FloatArray by lazy {
        val med = medianVoicedF0
        FloatArray(frames.size) { i ->
            val f = frames[i]
            if (f.voiced && med.isFinite() && med > 0f) hzToSemitones(f.f0Hz, med) else Float.NaN
        }
    }

    val durationSec: Float get() = frames.lastOrNull()?.timeSec ?: 0f

    val voicedRatio: Float
        get() = if (frames.isEmpty()) 0f else voicedFrames.size.toFloat() / frames.size

    companion object {
        fun hzToSemitones(hz: Float, referenceHz: Float): Float =
            (12.0 * log2(hz.toDouble() / referenceHz.toDouble())).toFloat()

        fun semitonesToHz(semitones: Float, referenceHz: Float): Float =
            (referenceHz * Math.pow(2.0, semitones / 12.0)).toFloat()
    }
}

/** Intensity contour for one speaker over one phrase. */
class IntensityContour(val frames: List<IntensityFrame>) {
    val durationSec: Float get() = frames.lastOrNull()?.timeSec ?: 0f

    val activeFrames: List<IntensityFrame> by lazy { frames.filter { !it.silent } }

    /**
     * Gain-normalized contour: dB values shifted so the mean of non-silent
     * frames is 0 dB. A microphone gain difference is a constant additive
     * offset in the dB domain, so mean-shifting cancels it exactly.
     * Silent frames become NaN.
     */
    val normalizedDb: FloatArray by lazy {
        val act = activeFrames
        val mean = if (act.isEmpty()) 0f else act.map { it.dbfs }.average().toFloat()
        FloatArray(frames.size) { i ->
            val f = frames[i]
            if (f.silent) Float.NaN else f.dbfs - mean
        }
    }

    companion object {
        const val MIN_DBFS = -60f
        const val SILENCE_GATE_DBFS = -50f
    }
}
