package com.shadowjp.app.data

import java.util.Calendar

/**
 * Dual-goal streak rules (v3).
 *
 * A day qualifies toward the streak ONLY when BOTH configured daily goals
 * were met on that local calendar day:
 *   practiceSeconds >= goalMinutes * 60  AND  takes >= takeGoal
 *
 * Historical goal values are not stored, so past days are evaluated against
 * the CURRENT goal settings (documented fallback in the README). Day
 * boundaries are local calendar days ("yyyy-MM-dd").
 *
 * Pure Kotlin + java.util.Calendar: JVM-unit-tested with injected dates.
 */
object StreakRules {

    data class DayActivity(
        val practiceSeconds: Int,
        val takes: Int
    )

    fun dayQualifies(activity: DayActivity?, goalMinutes: Int, takeGoal: Int): Boolean =
        activity != null &&
            activity.practiceSeconds >= goalMinutes * 60 &&
            activity.takes >= takeGoal

    /**
     * Consecutive qualifying days ending today; when today has not qualified
     * (yet), the streak counts backward from yesterday - a streak is not
     * broken until the day ends.
     *
     * @param days   map of local date key "yyyy-MM-dd" -> activity
     * @param today  calendar positioned on the day to evaluate from
     */
    fun currentStreak(
        days: Map<String, DayActivity>,
        goalMinutes: Int,
        takeGoal: Int,
        today: Calendar
    ): Int {
        val cal = today.clone() as Calendar
        var streak = 0
        if (!dayQualifies(days[key(cal)], goalMinutes, takeGoal)) {
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        while (dayQualifies(days[key(cal)], goalMinutes, takeGoal)) {
            streak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return streak
    }

    fun key(cal: Calendar): String = "%04d-%02d-%02d".format(
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH) + 1,
        cal.get(Calendar.DAY_OF_MONTH)
    )
}
