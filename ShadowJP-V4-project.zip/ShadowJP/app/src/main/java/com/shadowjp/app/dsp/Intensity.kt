package com.shadowjp.app.dsp

import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Frame-based RMS intensity extraction, aligned with the pitch frame grid
 * (same frame/hop sizes) so the two contours can be aligned sample-for-sample.
 *
 * Levels are reported in dBFS: 20 * log10(rms), clamped to [MIN_DBFS].
 * Frames below [IntensityContour.SILENCE_GATE_DBFS] are flagged silent and
 * carry no meaningful value downstream (NaN after normalization) - silence
 * is never invented.
 */
class IntensityExtractor(
    val sampleRate: Int = YinPitchExtractor.DEFAULT_SAMPLE_RATE,
    val frameSizeSamples: Int = 1024,
    val hopSizeSamples: Int = 160
) {
    fun extract(samples: FloatArray): IntensityContour {
        if (samples.size < frameSizeSamples) return IntensityContour(emptyList())
        val frames = ArrayList<IntensityFrame>()
        var start = 0
        while (start + frameSizeSamples <= samples.size) {
            var sumSq = 0.0
            for (i in start until start + frameSizeSamples) {
                val s = samples[i].toDouble()
                sumSq += s * s
            }
            val rms = sqrt(sumSq / frameSizeSamples)
            val db = if (rms <= 0.0) IntensityContour.MIN_DBFS
            else (20.0 * log10(rms)).toFloat().coerceAtLeast(IntensityContour.MIN_DBFS)
            frames.add(
                IntensityFrame(
                    timeSec = (start + frameSizeSamples / 2f) / sampleRate,
                    dbfs = db,
                    silent = db < IntensityContour.SILENCE_GATE_DBFS
                )
            )
            start += hopSizeSamples
        }
        return IntensityContour(frames)
    }
}
