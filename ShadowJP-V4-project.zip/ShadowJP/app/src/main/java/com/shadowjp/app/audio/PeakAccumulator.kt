package com.shadowjp.app.audio

/**
 * Incrementally folds a stream of PCM samples into a fixed number of
 * min/max peak buckets for waveform rendering.
 *
 * Pure Kotlin, no Android dependencies (JVM-unit-tested). Memory use is
 * O(buckets), independent of the audio length - the samples themselves are
 * never retained.
 *
 * Buckets that have not received any sample yet report 0/0 in snapshots so
 * the UI can show an honest "not generated yet" region while generation is
 * still in progress.
 */
class PeakAccumulator(
    val buckets: Int,
    /** Expected total sample count (from container metadata). */
    val totalSamples: Long
) {
    private val mins = FloatArray(buckets) { Float.POSITIVE_INFINITY }
    private val maxs = FloatArray(buckets) { Float.NEGATIVE_INFINITY }

    /** Samples fed so far. */
    var samplesSeen: Long = 0
        private set

    /** Highest bucket index that has received at least one sample, -1 = none. */
    var highestTouchedBucket: Int = -1
        private set

    /** Fraction of buckets reached, 0..1. */
    val progress: Float
        get() = if (buckets <= 0) 1f
        else ((highestTouchedBucket + 1).toFloat() / buckets).coerceIn(0f, 1f)

    /** Add [count] consecutive samples starting at the current position. */
    fun add(samples: FloatArray, count: Int = samples.size) {
        if (count <= 0 || buckets <= 0) return
        val total = totalSamples.coerceAtLeast(1)
        var i = 0
        while (i < count) {
            val globalIdx = samplesSeen + i
            var bucket = ((globalIdx * buckets) / total).toInt()
            if (bucket >= buckets) bucket = buckets - 1
            // End of this bucket (exclusive) in global sample index space.
            var bucketEnd = ((bucket + 1).toLong() * total) / buckets
            if (bucketEnd <= globalIdx) bucketEnd = globalIdx + 1
            val n = minOf(count - i, (bucketEnd - globalIdx).toInt())
            var mn = Float.POSITIVE_INFINITY
            var mx = Float.NEGATIVE_INFINITY
            for (j in i until i + n) {
                val v = samples[j]
                if (v < mn) mn = v
                if (v > mx) mx = v
            }
            if (mn < mins[bucket]) mins[bucket] = mn
            if (mx > maxs[bucket]) maxs[bucket] = mx
            if (bucket > highestTouchedBucket) highestTouchedBucket = bucket
            i += n
        }
        samplesSeen += count
    }

    /**
     * Snapshot as interleaved min/max pairs (2 * buckets floats). Buckets not
     * reached yet are 0/0. [mergeWith] a previously cached snapshot is not
     * needed - snapshots are cheap to take at any time.
     */
    fun snapshot(): FloatArray {
        val out = FloatArray(buckets * 2)
        for (b in 0 until buckets) {
            if (mins[b] != Float.POSITIVE_INFINITY) {
                out[b * 2] = mins[b]
                out[b * 2 + 1] = maxs[b]
            }
        }
        return out
    }
}
