package com.shadowjp.app.ui.practice

import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.AnalysisResultStore
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.audio.AudioDecoder
import com.shadowjp.app.audio.MicRecorder
import com.shadowjp.app.audio.NativePlayer
import com.shadowjp.app.audio.PcmData
import com.shadowjp.app.audio.PeakAccumulator
import com.shadowjp.app.audio.PhraseCache
import com.shadowjp.app.audio.WavFile
import com.shadowjp.app.audio.WaveformBuilder
import com.shadowjp.app.ui.components.SelectionMath
import com.shadowjp.app.data.SrtParser
import com.shadowjp.app.data.SubtitleCue
import com.shadowjp.app.data.db.TakeEntity
import com.shadowjp.app.dsp.AnalysisEngine
import com.shadowjp.app.dsp.SilenceTrimmer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Practice flow ViewModel (V4 practice workflow, retaining the V3 audio architecture).
 *
 * Import/playback/visualization/analysis are deliberately decoupled:
 *
 *  - OPEN: needs only the import-time metadata (duration). The clip becomes
 *    READY immediately - the full file is NEVER decoded to open it.
 *  - PLAYBACK: ExoPlayer streams from the file on disk; no in-memory PCM.
 *  - WAVEFORM: generated in the background as downsampled min/max peaks
 *    ([WaveformBuilder]), published progressively, cached on disk
 *    ([com.shadowjp.app.audio.WaveformCache]) and reused on reopen. The UI
 *    stays fully usable while it builds.
 *  - ANALYSIS: decodes ONLY the selected A-B window
 *    ([AudioDecoder.decodeRange]) with a small LRU ([PhraseCache]) so
 *    retakes of an unchanged phrase skip decoding entirely.
 *
 * The whole-file PCM is decoded only for the explicit "trim source silence"
 * action, always off the main thread and cancellable.
 */
class PracticeViewModel(
    private val app: ShadowApp,
    private val target: Target
) : ViewModel() {

    sealed class Target {
        data class Source(val sourceId: Long) : Target()
        data class Segment(val segmentId: Long) : Target()
    }

    enum class Phase { LOADING, ERROR, READY, RECORDING, ANALYZING }
    enum class PracticeMode { REPEAT_AFTER, CHORUS }

    data class UiState(
        val phase: Phase = Phase.LOADING,
        val error: String? = null,
        val title: String = "",
        val audioSourceId: Long = 0,
        val segmentId: Long = 0,
        val durationMs: Long = 0,
        val aMs: Long = 0,
        val bMs: Long = 0,
        val positionMs: Long = 0,
        val playing: Boolean = false,
        val loopingAB: Boolean = false,
        val speed: NativePlayer.Speed = NativePlayer.Speed.FULL,
        val replayCount: Int = 1,
        /** Min/max peak pairs; fills in progressively while generating. */
        val waveform: FloatArray = FloatArray(0),
        /** Waveform generation progress 0..1 (1 = complete or cache hit). */
        val waveformProgress: Float = 0f,
        /** True while background waveform generation is still running. */
        val waveformPending: Boolean = false,
        /** High-resolution peaks for the current time window, decoded on demand. */
        val detailWaveform: FloatArray = FloatArray(0),
        val viewportStartMs: Long = 0,
        val viewportEndMs: Long = 0,
        val detailWaveformPending: Boolean = false,
        val micPermissionNeeded: Boolean = false,
        /** Live timer values are UI state only; DSP still runs after stop. */
        val recordingElapsedMs: Long = 0L,
        val recordingLimitMs: Long = 0L,
        /** Locks the phrase while native replay/gap precedes the recording. */
        val preparingToRecord: Boolean = false,
        val statusHint: String? = null,
        /** Imported SRT captions use source-timeline timestamps. */
        val subtitleCues: List<SubtitleCue> = emptyList(),
        val subtitleFileName: String? = null,
        val captionsVisible: Boolean = true,
        val captionFontSp: Float = 13f,
        val captionLaneHeightDp: Float = 58f,
        val waveformVisible: Boolean = true,
        val waveformHeightDp: Float = 158f,
        val practiceMode: PracticeMode = PracticeMode.REPEAT_AFTER,
        /** Retained for older segment data; new practice text comes from timed SRT captions. */
        val transcript: String = "",
        /** True when a session-local silence-trimmed copy of the source is in use. */
        val sourceTrimmed: Boolean = false,
        /** True while the on-demand full decode for silence trimming runs. */
        val trimming: Boolean = false,
        /** Path of the (possibly session-trimmed) file the player uses. */
        val playbackPath: String = ""
    )

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    private var player: NativePlayer? = null
    private var recorder: MicRecorder? = null

    /** Seconds of genuine practice activity bucketed by local activity date until flushed. */
    private val pendingPracticeSecondsByDate = linkedMapOf<String, Int>()
    /** Preserve sub-second playback increments per day instead of flooring each poll to zero. */
    private val pendingPracticeMillisByDate = linkedMapOf<String, Long>()
    private var recordingPracticeDate: String? = null
    private var lastPositionMs = 0L
    private var wasPlaying = false
    private var gapJob: Job? = null
    private var waveformJob: Job? = null
    private var detailWaveformJob: Job? = null

    /** Monotonic token guarding against stale waveform/decode results. */
    private var sessionToken = 0
    private var detailRequestToken = 0

    companion object {
        /** Fixed listen-then-repeat gap (repeat-after design). */
        const val REPEAT_GAP_MS = 600L
        /** Recording auto-stops after this multiple of the phrase length. */
        const val MAX_RECORD_FACTOR = 3.0f
        const val MIN_PHRASE_MS = 300L
        /** Cap on phrase length keeps DTW memory bounded (60s -> ~36 MB backtrack matrix). */
        const val MAX_PHRASE_MS = 60_000L
        const val WAVEFORM_BUCKETS = 240
        const val DETAIL_WAVEFORM_BUCKETS = 720
        /** Minimum total removed edge-silence before a trimmed take copy is kept. */
        const val MIN_TAKE_TRIM_MS = 150L
    }

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            try {
                val settings = app.settings.settings.first()
                when (target) {
                    is Target.Source -> {
                        val src = app.database.dao().audioSource(target.sourceId)
                        if (src == null || !File(src.localPath).exists()) {
                            _state.value = UiState(
                                phase = Phase.ERROR,
                                error = "This audio file is no longer available."
                            )
                            return@launch
                        }
                        initSession(
                            title = src.displayName,
                            audioSourceId = src.id,
                            segmentId = 0,
                            path = src.localPath,
                            durationMs = src.durationMs,
                            aMs = 0,
                            bMs = minOf(src.durationMs, 5000),
                            replayCount = settings.defaultReplayCount,
                            transcript = ""
                        )
                    }
                    is Target.Segment -> {
                        val seg = app.audioLibrary.segment(target.segmentId)
                        if (seg == null || !File(seg.localPath).exists()) {
                            _state.value = UiState(
                                phase = Phase.ERROR,
                                error = "This segment's audio file is no longer available."
                            )
                            return@launch
                        }
                        initSession(
                            title = seg.displayName,
                            audioSourceId = seg.audioSourceId,
                            segmentId = seg.id,
                            path = seg.localPath,
                            durationMs = seg.sourceDurationMs,
                            aMs = seg.startMs,
                            bMs = seg.endMs,
                            replayCount = settings.defaultReplayCount,
                            transcript = seg.transcript
                        )
                    }
                }
            } catch (e: Exception) {
                _state.value = UiState(
                    phase = Phase.ERROR,
                    error = "Could not open audio: ${e.message ?: "unknown error"}"
                )
            }
        }
    }

    /**
     * Open the clip for practice WITHOUT decoding it: the player streams from
     * disk and the duration comes from the import-time metadata probe. The
     * overview waveform builds in the background and fills in progressively;
     * the editor separately decodes only its viewport at higher resolution.
     */
    private suspend fun initSession(
        title: String,
        audioSourceId: Long,
        segmentId: Long,
        path: String,
        durationMs: Long,
        aMs: Long,
        bMs: Long,
        replayCount: Int,
        transcript: String
    ) {
        val p = NativePlayer(app, viewModelScope)
        p.load(File(path))
        p.aMs = aMs
        p.bMs = minOf(bMs, durationMs)
        player = p
        val initialViewport = SelectionMath.initialViewport(durationMs, aMs, minOf(bMs, durationMs))
        val (storedCues, storedSubtitleName) = withContext(Dispatchers.IO) {
            val subtitleFile = subtitleFileFor(audioSourceId)
            val subtitleText = runCatching { if (subtitleFile.isFile) subtitleFile.readText(Charsets.UTF_8) else "" }.getOrDefault("")
            val cues = SrtParser.parse(subtitleText)
            val subtitleNameFile = File(subtitleFile.parentFile, "source_${audioSourceId}.name")
            val name = runCatching { if (subtitleNameFile.isFile) subtitleNameFile.readText(Charsets.UTF_8) else null }.getOrNull()
            cues to name
        }
        _state.value = UiState(
            phase = Phase.READY,
            title = title,
            audioSourceId = audioSourceId,
            segmentId = segmentId,
            durationMs = durationMs,
            aMs = aMs,
            bMs = minOf(bMs, durationMs),
            replayCount = replayCount,
            transcript = transcript,
            subtitleCues = storedCues,
            subtitleFileName = if (storedCues.isNotEmpty()) storedSubtitleName ?: "source_${audioSourceId}.srt" else null,
            playbackPath = path,
            viewportStartMs = initialViewport.startMs,
            viewportEndMs = initialViewport.endMs
        )
        viewModelScope.launch {
            p.state.collect { ps ->
                trackPracticeTime(ps.playing, ps.positionMs)
                _state.value = _state.value.copy(
                    positionMs = ps.positionMs,
                    playing = ps.playing,
                    loopingAB = ps.loopingAB,
                    speed = ps.speed,
                    error = ps.error ?: _state.value.error
                )
            }
        }
        startWaveformJob(File(path), durationMs)
        startDetailWaveformJob(File(path), initialViewport)
    }

    // ---------------- background waveform generation ----------------

    /**
     * Generate (or reuse the cached) waveform for [file] on a background
     * dispatcher. Cache hit -> instant. Miss -> progressive decode with
     * partial snapshots, then persisted to the cache. Cancelling the job
     * (clip switch / trim / leaving the screen) never touches playback or
     * saved data; stale results are dropped via [sessionToken].
     */
    private fun startWaveformJob(file: File, durationMs: Long) {
        waveformJob?.cancel()
        val token = ++sessionToken
        waveformJob = viewModelScope.launch(Dispatchers.Default) {
            _state.value = _state.value.copy(
                waveform = FloatArray(0),
                waveformProgress = 0f,
                waveformPending = true
            )
            val cached = app.waveformCache.load(file)
            if (cached != null) {
                if (token == sessionToken) {
                    _state.value = _state.value.copy(
                        waveform = cached,
                        waveformProgress = 1f,
                        waveformPending = false
                    )
                }
                return@launch
            }
            val result = WaveformBuilder.build(
                context = app,
                file = file,
                durationMsHint = durationMs,
                buckets = WAVEFORM_BUCKETS,
                isActive = { isActive && token == sessionToken }
            ) { partial, progress ->
                if (token == sessionToken) {
                    _state.value = _state.value.copy(
                        waveform = partial,
                        waveformProgress = progress
                    )
                }
            }
            if (result != null) {
                app.waveformCache.save(file, result)
                if (token == sessionToken) {
                    _state.value = _state.value.copy(
                        waveform = result,
                        waveformProgress = 1f,
                        waveformPending = false
                    )
                }
            } else if (token == sessionToken && isActive) {
                // Failed (unsupported container etc.): the clip stays fully
                // usable; the waveform simply remains a flat timeline.
                _state.value = _state.value.copy(
                    waveformPending = false,
                    statusHint = "Waveform preview is unavailable for this file; " +
                        "playback and A-B selection still work."
                )
            }
        }
    }

    /** Practice time = seconds of native playback + recording. Nothing else. */
    private fun trackPracticeTime(playing: Boolean, positionMs: Long) {
        if (wasPlaying && playing && positionMs > lastPositionMs) {
            val deltaMs = positionMs - lastPositionMs
            if (deltaMs in 1..2000) {
                val activityDate = app.practice.dateKey(System.currentTimeMillis())
                val totalMillis = (pendingPracticeMillisByDate[activityDate] ?: 0L) + deltaMs
                val wholeSeconds = (totalMillis / 1000L).toInt()
                pendingPracticeMillisByDate[activityDate] = totalMillis % 1000L
                if (wholeSeconds > 0) {
                    pendingPracticeSecondsByDate[activityDate] =
                        (pendingPracticeSecondsByDate[activityDate] ?: 0) + wholeSeconds
                }
                if (pendingPracticeSecondsByDate.values.sum() >= 10) flushPracticeTime()
            }
        }
        wasPlaying = playing
        lastPositionMs = positionMs
    }

    private fun flushPracticeTime() {
        if (pendingPracticeSecondsByDate.isEmpty()) return
        val buckets = pendingPracticeSecondsByDate.toMap()
        pendingPracticeSecondsByDate.clear()
        viewModelScope.launch(Dispatchers.IO) {
            for ((date, seconds) in buckets) app.practice.addPracticeSecondsForDate(date, seconds)
        }
    }

    // ---------------- transport ----------------

    fun togglePlay() {
        val p = player ?: return
        if (_state.value.playing) p.pause() else p.play()
    }

    fun seekTo(ms: Long) {
        player?.seekTo(ms)
    }

    fun setSpeed(speed: NativePlayer.Speed) {
        player?.setSpeed(speed)
    }

    fun setReplayCount(count: Int) {
        _state.value = _state.value.copy(replayCount = count.coerceIn(1, 10))
    }

    fun setA(ms: Long) {
        val s = _state.value
        val newA = SelectionMath.setStart(ms, s.bMs, s.durationMs)
        _state.value = s.copy(
            aMs = newA,
            transcript = transcriptForRange(s.subtitleCues, newA, s.bMs, s.transcript)
        )
        player?.aMs = newA
    }

    fun setB(ms: Long) {
        val s = _state.value
        val newB = SelectionMath.setEnd(ms, s.aMs, s.durationMs)
        _state.value = s.copy(
            bMs = newB,
            transcript = transcriptForRange(s.subtitleCues, s.aMs, newB, s.transcript)
        )
        player?.bMs = newB
    }

    fun setAAtPlayhead() {
        val s = _state.value
        val range = SelectionMath.rangeStartingAt(s.positionMs, s.durationMs, s.bMs - s.aMs)
        setRangeExact(range.aMs, range.bMs)
    }

    fun setBAtPlayhead() {
        val s = _state.value
        val range = SelectionMath.rangeEndingAt(s.positionMs, s.durationMs, s.bMs - s.aMs)
        setRangeExact(range.aMs, range.bMs)
    }

    fun nudgeA(deltaMs: Long) = setA(_state.value.aMs + deltaMs)

    fun nudgeB(deltaMs: Long) = setB(_state.value.bMs + deltaMs)

    fun zoomDetail(zoomIn: Boolean) {
        val s = _state.value
        val current = SelectionMath.Viewport(s.viewportStartMs, s.viewportEndMs)
        updateDetailViewport(SelectionMath.zoom(current, s.durationMs, if (zoomIn) 0.65f else 1.55f))
    }

    fun panDetail(direction: Int) {
        val s = _state.value
        val current = SelectionMath.Viewport(s.viewportStartMs, s.viewportEndMs)
        updateDetailViewport(SelectionMath.pan(current, s.durationMs, 0.7f * direction))
    }

    fun centerDetailOnSelection() {
        val s = _state.value
        updateDetailViewport(SelectionMath.initialViewport(s.durationMs, s.aMs, s.bMs))
    }

    fun seekFromOverview(ms: Long) {
        seekTo(ms)
        val s = _state.value
        val span = (s.viewportEndMs - s.viewportStartMs).coerceAtLeast(1L)
        if (ms < s.viewportStartMs + span / 10L || ms > s.viewportEndMs - span / 10L) {
            updateDetailViewport(SelectionMath.centeredViewport(s.durationMs, ms, span))
        }
    }

    private fun updateDetailViewport(viewport: SelectionMath.Viewport) {
        val s = _state.value
        if (viewport.startMs == s.viewportStartMs && viewport.endMs == s.viewportEndMs) return
        _state.value = s.copy(
            viewportStartMs = viewport.startMs,
            viewportEndMs = viewport.endMs,
            detailWaveform = FloatArray(0),
            detailWaveformPending = true
        )
        startDetailWaveformJob(File(s.playbackPath), viewport)
    }

    /** Decode only the visible time window for true high-resolution peaks. */
    private fun startDetailWaveformJob(file: File, viewport: SelectionMath.Viewport) {
        detailWaveformJob?.cancel()
        val request = ++detailRequestToken
        if (viewport.spanMs <= 0L) {
            _state.value = _state.value.copy(detailWaveform = FloatArray(0), detailWaveformPending = false)
            return
        }
        detailWaveformJob = viewModelScope.launch(Dispatchers.Default) {
            when (val decoded = AudioDecoder.decodeRange(
                app, file, viewport.startMs, viewport.endMs
            ) { isActive && request == detailRequestToken }) {
                is AudioDecoder.DecodeResult.Ok -> {
                    val samples = decoded.pcm.samples
                    val peaks = if (samples.isEmpty()) FloatArray(0) else {
                        PeakAccumulator(DETAIL_WAVEFORM_BUCKETS, samples.size.toLong()).also {
                            it.add(samples)
                        }.snapshot()
                    }
                    if (request == detailRequestToken && isActive) {
                        _state.value = _state.value.copy(
                            detailWaveform = peaks,
                            detailWaveformPending = false
                        )
                    }
                }
                is AudioDecoder.DecodeResult.Error -> {
                    if (request == detailRequestToken && isActive) {
                        _state.value = _state.value.copy(
                            detailWaveform = FloatArray(0),
                            detailWaveformPending = false,
                            statusHint = if (decoded.message == "cancelled") _state.value.statusHint
                                else "Detailed waveform unavailable for this range; the overview and selection still work."
                        )
                    }
                }
            }
        }
    }

    /**
     * Precise numerical entry of the A-B range. Works as soon as the clip is
     * open - waveform generation does not gate it. Returns an error message
     * when the requested range is invalid (nothing applied); null on success.
     */
    fun setRangeExact(aMs: Long, bMs: Long): String? {
        val s = _state.value
        if (aMs < 0) return "Start must be 0 or later."
        if (bMs <= aMs) return "End must be after start."
        if (bMs - aMs < MIN_PHRASE_MS)
            return "Phrase must be at least ${MIN_PHRASE_MS / 1000f}s long."
        if (bMs > s.durationMs) return "End exceeds the audio duration."
        if (bMs - aMs > MAX_PHRASE_MS)
            return "Phrase is capped at ${MAX_PHRASE_MS / 1000}s."
        if (!SelectionMath.isValidRange(aMs, bMs, s.durationMs)) return "Invalid phrase range."
        _state.value = s.copy(
            aMs = aMs,
            bMs = bMs,
            transcript = transcriptForRange(s.subtitleCues, aMs, bMs, s.transcript)
        )
        player?.aMs = aMs
        player?.bMs = bMs
        // A manually entered phrase (or a Set A/B action at the playhead) may
        // be outside the current detail viewport. Keep the timestamps as the
        // source of truth and move the viewport to the new phrase when needed.
        val viewport = SelectionMath.Viewport(s.viewportStartMs, s.viewportEndMs)
        if (aMs < viewport.startMs || bMs > viewport.endMs) {
            updateDetailViewport(SelectionMath.initialViewport(s.durationMs, aMs, bMs))
        }
        return null
    }

    fun playSelection() {
        val s = _state.value
        player?.playAB(s.replayCount)
    }

    fun stopLoop() {
        player?.stopLoop()
    }

    // ---------------- timed SRT captions ----------------

    private fun transcriptForRange(cues: List<SubtitleCue>, aMs: Long, bMs: Long, fallback: String): String {
        if (cues.isEmpty()) return fallback
        // SRT cues are sorted by start time. Binary-search into the selected
        // range so dragging an A/B handle doesn't scan a whole long subtitle file.
        var low = 0
        var high = cues.size
        while (low < high) {
            val mid = (low + high) ushr 1
            if (cues[mid].startMs < aMs) low = mid + 1 else high = mid
        }
        val first = (low - 1).coerceAtLeast(0)
        val selected = ArrayList<String>()
        for (index in first until cues.size) {
            val cue = cues[index]
            if (cue.startMs >= bMs) break
            if (cue.endMs > aMs) selected += cue.text.replace('\n', ' ').trim()
        }
        return selected.joinToString(" ").trim()
    }

    private fun subtitleFileFor(sourceId: Long): File = File(app.filesDir, "subtitles/source_${sourceId}.srt")

    fun importSrt(uri: Uri) {
        val sourceId = _state.value.audioSourceId
        val token = sessionToken
        if (sourceId <= 0L) return
        viewModelScope.launch {
            try {
                val textAndName = withContext(Dispatchers.IO) {
                    val displayName = runCatching {
                        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                            ?.use { cursor ->
                                if (cursor.moveToFirst()) cursor.getString(0) else null
                            }
                    }.getOrNull()?.takeIf { it.isNotBlank() } ?: "captions.srt"
                    val text = app.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalArgumentException("The selected subtitle file could not be opened.")
                    val cues = SrtParser.parse(text)
                    if (cues.isEmpty()) throw IllegalArgumentException("No valid SRT captions were found. Check the file's timestamps and try again.")
                    val destination = subtitleFileFor(sourceId)
                    destination.parentFile?.mkdirs()
                    destination.writeText(text, Charsets.UTF_8)
                    val nameFile = File(destination.parentFile, "source_${sourceId}.name")
                    nameFile.writeText(displayName, Charsets.UTF_8)
                    Pair(cues, displayName)
                }
                if (token == sessionToken && _state.value.audioSourceId == sourceId) {
                    val current = _state.value
                    _state.value = current.copy(
                        subtitleCues = textAndName.first,
                        subtitleFileName = textAndName.second,
                        transcript = transcriptForRange(textAndName.first, current.aMs, current.bMs, ""),
                        captionsVisible = true,
                        statusHint = "Loaded ${textAndName.first.size} timed captions. Tap a caption block to practice that line."
                    )
                }
            } catch (e: Exception) {
                if (token == sessionToken) {
                    _state.value = _state.value.copy(
                        statusHint = e.message ?: "Could not import this SRT file."
                    )
                }
            }
        }
    }

    /** Tap a timed SRT cue to use its timestamp range as the current practice phrase. */
    fun selectSubtitleCue(cue: SubtitleCue) {
        val s = _state.value
        if (s.durationMs < MIN_PHRASE_MS) {
            _state.value = s.copy(statusHint = "This audio is too short for a practice phrase.")
            return
        }
        val a = cue.startMs.coerceIn(0L, (s.durationMs - MIN_PHRASE_MS).coerceAtLeast(0L))
        val latestB = minOf(s.durationMs, a + MAX_PHRASE_MS)
        val b = cue.endMs.coerceIn(a + MIN_PHRASE_MS, latestB)
        val error = setRangeExact(a, b)
        if (error != null) {
            _state.value = _state.value.copy(statusHint = error)
            return
        }
        player?.seekTo(a)
        _state.value = _state.value.copy(statusHint = "Selected caption range ${a}–${b} ms. You can adjust A/B if needed.")
    }

    fun setCaptionsVisible(visible: Boolean) {
        _state.value = _state.value.copy(captionsVisible = visible)
    }

    fun setCaptionFontSp(size: Float) {
        _state.value = _state.value.copy(captionFontSp = size.coerceIn(10f, 22f))
    }

    fun setCaptionLaneHeightDp(height: Float) {
        _state.value = _state.value.copy(captionLaneHeightDp = height.coerceIn(38f, 110f))
    }

    fun setWaveformVisible(visible: Boolean) {
        _state.value = _state.value.copy(waveformVisible = visible)
    }

    fun setWaveformHeightDp(height: Float) {
        _state.value = _state.value.copy(waveformHeightDp = height.coerceIn(88f, 240f))
    }

    fun setPracticeMode(mode: PracticeMode) {
        if (_state.value.phase == Phase.RECORDING || _state.value.preparingToRecord) return
        _state.value = _state.value.copy(practiceMode = mode)
    }

    // ---------------- source silence trimming ----------------

    /**
     * Trim leading/trailing silence of the SOURCE audio. Non-destructive:
     * writes a session copy under filesDir/imports and points playback +
     * analysis at it; the imported file on disk is never modified.
     *
     * This is the one feature that still needs the full source PCM; the
     * decode happens HERE, on demand, on a background dispatcher, and is
     * cancelled when the screen is left.
     */
    fun trimSourceSilence() {
        val s = _state.value
        if (s.phase != Phase.READY || s.sourceTrimmed || s.trimming) return
        viewModelScope.launch {
            val token = sessionToken
            _state.value = _state.value.copy(
                trimming = true,
                statusHint = "Scanning the full source for silence (one-time)..."
            )
            val decoded = withContext(Dispatchers.Default) {
                AudioDecoder.decode(app, File(s.playbackPath)) { isActive && token == sessionToken }
            }
            if (decoded !is AudioDecoder.DecodeResult.Ok) {
                if (token == sessionToken) {
                    _state.value = _state.value.copy(
                        trimming = false,
                        statusHint = (decoded as? AudioDecoder.DecodeResult.Error)?.message
                            ?: "Could not decode the source."
                    )
                }
                return@launch
            }
            val pcm = decoded.pcm
            val result = withContext(Dispatchers.Default) {
                val threshold = app.settings.settings.first().silenceThresholdDb
                SilenceTrimmer.trim(pcm.samples, pcm.sampleRate, thresholdDb = threshold)
            }
            if (result == null || result.trimmedMs < MIN_TAKE_TRIM_MS) {
                _state.value = _state.value.copy(
                    trimming = false,
                    statusHint = "No significant leading/trailing silence found."
                )
                return@launch
            }
            val trimmedPcm = PcmData(pcm.sampleRate, result.samples)
            val copy = File(
                app.filesDir,
                "imports/trimmed_${s.audioSourceId}_${System.currentTimeMillis()}.wav"
            )
            withContext(Dispatchers.IO) { WavFile.write(copy, trimmedPcm) }
            val dur = trimmedPcm.durationMs
            val newA = s.aMs.coerceIn(0, maxOf(0, dur - MIN_PHRASE_MS))
            val newB = s.bMs.coerceIn(newA + MIN_PHRASE_MS, dur)
            val p = player
            p?.load(copy)
            p?.aMs = newA
            p?.bMs = newB
            // We already hold the PCM - fold it into peaks directly instead
            // of re-reading the file we just wrote.
            val acc = PeakAccumulator(WAVEFORM_BUCKETS, trimmedPcm.samples.size.toLong())
            acc.add(trimmedPcm.samples)
            val shiftedSubtitles = s.subtitleCues.mapNotNull { cue ->
                val shiftedStart = (cue.startMs - result.removedLeadingMs).coerceAtLeast(0L)
                val shiftedEnd = (cue.endMs - result.removedLeadingMs).coerceAtMost(dur)
                if (shiftedEnd <= shiftedStart) null else cue.copy(startMs = shiftedStart, endMs = shiftedEnd)
            }
            _state.value = _state.value.copy(
                durationMs = dur,
                aMs = newA,
                bMs = newB,
                subtitleCues = shiftedSubtitles,
                transcript = transcriptForRange(shiftedSubtitles, newA, newB, s.transcript),
                waveform = acc.snapshot(),
                waveformProgress = 1f,
                waveformPending = false,
                trimming = false,
                sourceTrimmed = true,
                playbackPath = copy.absolutePath,
                statusHint = "Using a silence-trimmed copy (-${"%.1f".format(result.trimmedMs / 1000f)}s). The original import is untouched."
            )
            val viewport = SelectionMath.initialViewport(dur, newA, newB)
            _state.value = _state.value.copy(
                viewportStartMs = viewport.startMs,
                viewportEndMs = viewport.endMs,
                detailWaveform = FloatArray(0),
                detailWaveformPending = true
            )
            startDetailWaveformJob(copy, viewport)
        }
    }

    // ---------------- repeat-after recording ----------------

    /** Start the classic listen-then-record workflow. */
    fun startRepeatAfterFlow() {
        val s = _state.value
        if (s.phase != Phase.READY) return
        if (s.bMs - s.aMs < MIN_PHRASE_MS) {
            _state.value = s.copy(statusHint = "Select a longer phrase first (A-B too short).")
            return
        }
        gapJob?.cancel()
        player?.onLoopFinished = null
        player?.stopLoop()
        player?.pause()
        _state.value = s.copy(
            practiceMode = PracticeMode.REPEAT_AFTER,
            statusHint = "Requesting microphone permission…",
            micPermissionNeeded = true,
            preparingToRecord = true
        )
    }

    /** Chorus: listen to the phrase once, then record while that phrase plays again. */
    fun startChorusFlow() {
        val s = _state.value
        if (s.phase != Phase.READY) return
        if (s.bMs - s.aMs < MIN_PHRASE_MS) {
            _state.value = s.copy(statusHint = "Select a longer phrase first (A-B too short).")
            return
        }
        gapJob?.cancel()
        player?.onLoopFinished = null
        player?.stopLoop()
        player?.pause()
        _state.value = s.copy(
            practiceMode = PracticeMode.CHORUS,
            statusHint = "Requesting microphone permission…",
            micPermissionNeeded = true,
            preparingToRecord = true
        )
    }

    /** Called after the mic permission result; starts the selected practice flow. */
    fun onMicPermissionResult(granted: Boolean) {
        val s = _state.value
        _state.value = s.copy(micPermissionNeeded = false)
        if (!granted) {
            _state.value = _state.value.copy(
                preparingToRecord = false,
                statusHint = "Microphone permission is required to record your take."
            )
            return
        }
        val p = player
        if (p == null) {
            _state.value = _state.value.copy(
                preparingToRecord = false,
                statusHint = "The native audio player is unavailable. Reopen this phrase and try again."
            )
            return
        }
        gapJob?.cancel()
        val phraseMs = _state.value.bMs - _state.value.aMs
        val speed = _state.value.speed.factor
        if (_state.value.practiceMode == PracticeMode.CHORUS) {
            startChorusListenPass(p, phraseMs, speed)
            return
        }
        gapJob = viewModelScope.launch {
            // Listen the selected number of times before the automatic recording starts.
            val repeats = _state.value.replayCount
            _state.value = _state.value.copy(
                statusHint = if (repeats == 1) "Listen to the native phrase..."
                    else "Listen to the native phrase ($repeats plays)..."
            )
            p.playAB(repetitions = repeats)
            val playMs = (phraseMs * repeats / speed).toLong() + 250
            delay(playMs)
            p.pause()
            _state.value = _state.value.copy(statusHint = "Get ready...")
            delay(REPEAT_GAP_MS)
            beginRecording(phraseMs, speed)
        }
    }

    private fun startChorusListenPass(p: NativePlayer, phraseMs: Long, speed: Float) {
        p.onLoopFinished = {
            // NativePlayer calls this on its main-thread position poller after the
            // listen-only pass has stopped at B. Start mic capture, then the chorus pass.
            p.onLoopFinished = null
            beginRecording(phraseMs, speed, (phraseMs / speed).toLong() + 500L)
            if (_state.value.phase == Phase.RECORDING) {
                _state.value = _state.value.copy(statusHint = "Chorus pass — speak along with the audio.")
                p.onLoopFinished = {
                    p.onLoopFinished = null
                    if (_state.value.phase == Phase.RECORDING) finishRecordingAndAnalyze()
                }
                p.playAB(repetitions = 1)
            } else {
                _state.value = _state.value.copy(preparingToRecord = false)
            }
        }
        _state.value = _state.value.copy(statusHint = "Listen once. Then speak along with the second play.")
        p.playAB(repetitions = 1)
    }

    /** Record immediately. */
    fun beginRecording(phraseMs: Long, speedFactor: Float, maxDurationOverrideMs: Long? = null) {
        val rec = MicRecorder()
        recorder = rec
        if (!rec.start(viewModelScope)) {
            val message = (rec.state as? MicRecorder.State.Failed)?.message
                ?: "Could not start recording."
            rec.cancel()
            _state.value = _state.value.copy(preparingToRecord = false, statusHint = message)
            recorder = null
            return
        }
        recordingPracticeDate = app.practice.today()
        val maxMs = maxDurationOverrideMs?.coerceAtLeast(300L)
            ?: (phraseMs / speedFactor * MAX_RECORD_FACTOR).toLong() + 1000
        _state.value = _state.value.copy(
            phase = Phase.RECORDING,
            preparingToRecord = false,
            recordingElapsedMs = 0L,
            recordingLimitMs = maxMs,
            statusHint = null
        )
        viewModelScope.launch {
            while (_state.value.phase == Phase.RECORDING) {
                delay(100)
                _state.value = _state.value.copy(recordingElapsedMs = rec.recordedDurationMs)
                val micState = rec.state
                if (micState is MicRecorder.State.Failed) {
                    if (recorder === rec) {
                        recorder = null
                        recordingPracticeDate = null
                        rec.cancel()
                        _state.value = _state.value.copy(
                            phase = Phase.READY,
                            preparingToRecord = false,
                            statusHint = micState.message
                        )
                    }
                    break
                }
                if (rec.recordedDurationMs >= maxMs) {
                    finishRecordingAndAnalyze()
                    break
                }
            }
        }
    }

    fun finishRecordingAndAnalyze() {
        val rec = recorder ?: return
        recorder = null
        player?.onLoopFinished = null
        player?.stopLoop()
        player?.pause()
        val userPcm = rec.stop()
        if (userPcm == null) {
            recordingPracticeDate = null
            _state.value = _state.value.copy(
                phase = Phase.READY,
                statusHint = "Recording was too short - try again and speak right after the prompt."
            )
            return
        }
        // Recording seconds count as activity on the date capture began. Cancelled
        // recordings never reach this point; failed analysis still represents actual practice.
        val recordDate = recordingPracticeDate ?: app.practice.today()
        recordingPracticeDate = null
        val recordingSeconds = (userPcm.durationSec + 0.5f).toInt()
        if (recordingSeconds > 0) {
            pendingPracticeSecondsByDate[recordDate] =
                (pendingPracticeSecondsByDate[recordDate] ?: 0) + recordingSeconds
        }
        flushPracticeTime()
        analyze(userPcm, recordDate)
    }

    fun cancelPendingRepeat() {
        gapJob?.cancel()
        gapJob = null
        player?.onLoopFinished = null
        player?.stopLoop()
        player?.pause()
        _state.value = _state.value.copy(
            preparingToRecord = false,
            micPermissionNeeded = false,
            statusHint = null
        )
    }

    fun cancelRecording() {
        player?.onLoopFinished = null
        player?.stopLoop()
        recorder?.cancel()
        recorder = null
        recordingPracticeDate = null
        _state.value = _state.value.copy(
            phase = Phase.READY,
            preparingToRecord = false,
            statusHint = null
        )
    }

    /**
     * Analyze the take against the SELECTED A-B window only.
     *
     * The source is decoded range-wise ([AudioDecoder.decodeRange]): the
     * extractor seeks near A, only the necessary region is decoded, and
     * decoded content outside the window is discarded. Unchanged phrases hit
     * [PhraseCache] instead of re-decoding. If range decoding is rejected by
     * a pathological format, an explicit full-decode + slice fallback keeps
     * analysis possible - off the main thread in every case.
     */
    private fun analyze(userPcm: PcmData, practiceDate: String) {
        val s = _state.value
        _state.value = s.copy(phase = Phase.ANALYZING, statusHint = "Analyzing...")
        val token = sessionToken
        viewModelScope.launch {
            val sourceFile = File(s.playbackPath)
            val segmentPcm = withContext(Dispatchers.Default) {
                PhraseCache.get(sourceFile, s.aMs, s.bMs)
                    ?: run {
                        when (val d = AudioDecoder.decodeRange(
                            app, sourceFile, s.aMs, s.bMs
                        ) { isActive && token == sessionToken }) {
                            is AudioDecoder.DecodeResult.Ok ->
                                d.pcm.also { PhraseCache.put(sourceFile, s.aMs, s.bMs, it) }
                            is AudioDecoder.DecodeResult.Error -> {
                                // Explicit fallback for formats that refuse
                                // seeking: bounded to the selected range after
                                // a one-off full decode (background thread).
                                when (val full = AudioDecoder.decode(
                                    app, sourceFile
                                ) { isActive && token == sessionToken }) {
                                    is AudioDecoder.DecodeResult.Ok ->
                                        full.pcm.slice(s.aMs, s.bMs)
                                    is AudioDecoder.DecodeResult.Error -> null
                                }
                            }
                        }
                    }
            }
            if (segmentPcm == null || segmentPcm.samples.isEmpty()) {
                _state.value = _state.value.copy(
                    phase = Phase.READY,
                    statusHint = "Could not decode the selected phrase."
                )
                return@launch
            }
            val result = withContext(Dispatchers.Default) {
                val settings = app.settings.settings.first()
                AnalysisEngine.analyze(
                    nativePcm = segmentPcm.samples,
                    userPcm = userPcm.samples,
                    minF0Hz = settings.pitchRange.minF0,
                    maxF0Hz = settings.pitchRange.maxF0
                )
            }
            handleAnalysisResult(result, userPcm, practiceDate)
        }
    }

    private suspend fun handleAnalysisResult(
        result: AnalysisEngine.Result,
        userPcm: PcmData,
        practiceDate: String
    ) {
        val s = _state.value
        when (result) {
            is AnalysisEngine.Result.Failure -> {
                _state.value = s.copy(phase = Phase.READY, statusHint = result.reason.message)
            }
            is AnalysisEngine.Result.Success -> {
                // Auto-save the A-B range as a reusable segment (with transcript).
                var segmentId = s.segmentId
                if (segmentId == 0L) {
                    val newId = app.audioLibrary.saveSegment(
                        s.audioSourceId, s.aMs, s.bMs, s.transcript
                    )
                    if (newId > 0) segmentId = newId
                    else if (newId == -2L) {
                        // identical segment already exists: look it up + keep transcript fresh
                        segmentId = app.audioLibrary.segments.first()
                            .firstOrNull {
                                it.audioSourceId == s.audioSourceId &&
                                    it.startMs == s.aMs && it.endMs == s.bMs
                            }?.id ?: 0L
                        if (segmentId > 0 && s.transcript.isNotBlank()) {
                            app.audioLibrary.updateSegmentTranscript(segmentId, s.transcript)
                        }
                    }
                } else if (s.transcript != (app.audioLibrary.segment(segmentId)?.transcript ?: "")) {
                    app.audioLibrary.updateSegmentTranscript(segmentId, s.transcript)
                }

                val a = result.analysis
                var takePath: String? = null
                if (segmentId > 0) {
                    val stamp = System.currentTimeMillis()
                    // Always keep the untouched original recording.
                    val origFile = File(app.filesDir, "recordings/${stamp}_orig.wav")
                    withContext(Dispatchers.IO) { WavFile.write(origFile, userPcm) }

                    // Automatic silence trimming: the trimmed copy becomes the
                    // playback/export candidate; the original stays on disk.
                    val trim = withContext(Dispatchers.Default) {
                        val threshold = app.settings.settings.first().silenceThresholdDb
                        SilenceTrimmer.trim(
                            userPcm.samples, userPcm.sampleRate, thresholdDb = threshold
                        )
                    }
                    val trimmed = trim != null && trim.trimmedMs >= MIN_TAKE_TRIM_MS
                    val playbackFile = if (trim != null && trimmed) {
                        val f = File(app.filesDir, "recordings/${stamp}_trim.wav")
                        withContext(Dispatchers.IO) {
                            WavFile.write(f, PcmData(userPcm.sampleRate, trim.samples))
                        }
                        f
                    } else origFile

                    app.audioLibrary.insertTake(
                        TakeEntity(
                            segmentId = segmentId,
                            createdAt = stamp,
                            overallScore = a.scores.overall,
                            pitchScore = a.scores.pitch,
                            timingScore = a.scores.timing,
                            intensityScore = a.scores.intensity,
                            nativeDurationMs = s.bMs - s.aMs,
                            userDurationMs = userPcm.durationMs,
                            recordingPath = playbackFile.absolutePath,
                            originalRecordingPath =
                                if (trimmed) origFile.absolutePath else null,
                            practiceDate = practiceDate,
                            trimmed = trimmed,
                            verdict = a.verdict
                        )
                    )
                    takePath = playbackFile.absolutePath
                    _state.value = _state.value.copy(segmentId = segmentId)
                }
                flushPracticeTime()
                _state.value = _state.value.copy(phase = Phase.READY, statusHint = null)
                analysisStore?.let {
                    it.last = result
                    it.segmentId = segmentId.takeIf { id -> id > 0 }
                    it.audioSourceId = s.audioSourceId
                    it.nativePath = _state.value.playbackPath
                    it.aMs = _state.value.aMs
                    it.bMs = _state.value.bMs
                    it.takePath = takePath
                }
                onAnalyzed?.invoke()
            }
        }
    }

    // Wired in by the composable so the VM can hand results to the nav layer.
    var analysisStore: AnalysisResultStore? = null
    var onAnalyzed: (() -> Unit)? = null

    fun clearHint() {
        _state.value = _state.value.copy(statusHint = null)
    }

    override fun onCleared() {
        sessionToken++ // invalidate in-flight waveform/decode results
        detailRequestToken++
        flushPracticeTime()
        waveformJob?.cancel()
        detailWaveformJob?.cancel()
        gapJob?.cancel()
        recorder?.cancel()
        player?.release()
        super.onCleared()
    }
}
