package com.shadowjp.app.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "audio_sources")
data class AudioSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    /** Path to the app-private copy of the audio file. */
    val localPath: String,
    val durationMs: Long,
    val importedAt: Long,
    /**
     * Original SAF document URI (string form), kept ONLY so its persisted
     * read permission can be released when the clip is deleted. Playback
     * always uses [localPath].
     */
    val sourceUri: String? = null,
    /** Container-reported sample rate (metadata probe, no decoding). */
    val sampleRateHz: Int? = null,
    /** Container-reported channel count (metadata probe, no decoding). */
    val channelCount: Int? = null
)

@Entity(
    tableName = "segments",
    foreignKeys = [ForeignKey(
        entity = AudioSourceEntity::class,
        parentColumns = ["id"],
        childColumns = ["audioSourceId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("audioSourceId")]
)
data class SegmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val audioSourceId: Long,
    val startMs: Long,
    val endMs: Long,
    /** User-supplied transcript for this phrase (local-only, may be empty). */
    val transcript: String = "",
    val createdAt: Long
)

@Entity(
    tableName = "takes",
    foreignKeys = [ForeignKey(
        entity = SegmentEntity::class,
        parentColumns = ["id"],
        childColumns = ["segmentId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("segmentId"), Index("createdAt")]
)
data class TakeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val segmentId: Long,
    val createdAt: Long,
    val overallScore: Float,
    val pitchScore: Float,
    val timingScore: Float,
    val intensityScore: Float,
    /** Native segment duration in ms. */
    val nativeDurationMs: Long,
    /** User take duration in ms. */
    val userDurationMs: Long,
    /** App-private WAV path of the recorded take (playback/export candidate). */
    val recordingPath: String,
    /**
     * App-private WAV path of the untrimmed original recording, when automatic
     * silence trimming produced a trimmed copy. Null when the stored take is
     * the original recording itself.
     */
    val originalRecordingPath: String? = null,
    /** Local calendar date assigned when this take was saved; keeps streak history stable across timezone changes. */
    @ColumnInfo(defaultValue = "''") val practiceDate: String = "",
    /** True when [recordingPath] points at a silence-trimmed copy. */
    val trimmed: Boolean = false,
    val verdict: String
)

/** One row per calendar day, holding accumulated practice seconds. */
@Entity(tableName = "practice_days")
data class PracticeDayEntity(
    @PrimaryKey val date: String, // yyyy-MM-dd (local)
    val practiceSeconds: Int
)
