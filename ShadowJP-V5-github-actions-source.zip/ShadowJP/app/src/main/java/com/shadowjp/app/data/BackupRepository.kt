package com.shadowjp.app.data

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.shadowjp.app.data.db.AppDatabase
import com.shadowjp.app.data.db.AudioSourceEntity
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.SegmentEntity
import com.shadowjp.app.data.db.TakeEntity
import com.shadowjp.app.prefs.PitchRange
import com.shadowjp.app.prefs.SettingsRepository
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** A self-contained offline backup for database rows, recordings, imported media and SRT captions. */
class BackupRepository(
    private val context: Context,
    private val database: AppDatabase,
    private val settingsRepository: SettingsRepository
) {
    companion object {
        private const val FORMAT = "ShadowJPBackup"
        private const val SCHEMA_VERSION = 1
        private const val MANIFEST = "manifest.json"
        private const val MAX_MANIFEST_BYTES = 32L * 1024L * 1024L
    }

    data class Preview(
        val schemaVersion: Int,
        val createdAt: Long,
        val sourceCount: Int,
        val segmentCount: Int,
        val takeCount: Int,
        val practiceDayCount: Int,
        val subtitleCount: Int,
        val includedMediaBytes: Long
    )

    enum class RestoreMode { MERGE, REPLACE }

    data class RestoreReport(
        val sourcesAdded: Int,
        val segmentsAdded: Int,
        val takesAdded: Int,
        val practiceDaysRestored: Int,
        val subtitlesRestored: Int,
        val duplicatesSkipped: Int,
        val missingMedia: List<String>
    ) {
        fun message(mode: RestoreMode): String = buildString {
            append(if (mode == RestoreMode.REPLACE) "Backup restored" else "Backup merged")
            append(": $sourcesAdded media item(s), $segmentsAdded phrase(s), $takesAdded take(s), ")
            append("$practiceDaysRestored practice day(s), $subtitlesRestored subtitle track(s).")
            if (duplicatesSkipped > 0) append(" Skipped $duplicatesSkipped duplicate record(s).")
            if (missingMedia.isNotEmpty()) append(" ${missingMedia.size} media file(s) could not be restored.")
        }
    }

    suspend fun export(uri: Uri): Preview {
        val dao = database.dao()
        val sources = dao.allAudioSourcesList()
        val segments = dao.allSegmentsList()
        val takes = dao.allTakesList()
        val days = dao.practiceDays().first()
        val settings = settingsRepository.settings.first()
        val destination = context.contentResolver.openOutputStream(uri, "w")
            ?: throw IllegalStateException("Android could not open the selected backup location for writing.")

        var mediaBytes = 0L
        ZipOutputStream(destination.buffered()).use { zip ->
            val entryByPath = HashMap<String, String>()
            var nextMediaId = 1
            fun addFile(rawPath: String?): String? {
                if (rawPath.isNullOrBlank()) return null
                val file = File(rawPath)
                if (!file.isFile) return null
                val key = runCatching { file.canonicalPath }.getOrDefault(file.absolutePath)
                entryByPath[key]?.let { return it }
                val ext = file.extension.takeIf { it.matches(Regex("[A-Za-z0-9]{1,8}")) }
                    ?.let { ".$it" }.orEmpty()
                val entryName = "assets/media_${nextMediaId++}$ext"
                zip.putNextEntry(ZipEntry(entryName))
                file.inputStream().buffered().use { input -> mediaBytes += input.copyTo(zip) }
                zip.closeEntry()
                entryByPath[key] = entryName
                return entryName
            }

            val manifest = JSONObject()
                .put("format", FORMAT)
                .put("schemaVersion", SCHEMA_VERSION)
                .put("createdAt", System.currentTimeMillis())

            val sourceArray = JSONArray()
            for (source in sources) {
                val file = File(source.localPath)
                sourceArray.put(JSONObject()
                    .put("id", source.id)
                    .put("displayName", source.displayName)
                    .put("durationMs", source.durationMs)
                    .put("importedAt", source.importedAt)
                    .put("sampleRateHz", source.sampleRateHz ?: JSONObject.NULL)
                    .put("channelCount", source.channelCount ?: JSONObject.NULL)
                    .put("mediaEntry", addFile(source.localPath) ?: JSONObject.NULL)
                    .put("mediaSha256", if (file.isFile) sha256(file) else ""))
            }
            manifest.put("audioSources", sourceArray)

            val segmentArray = JSONArray()
            for (segment in segments) {
                segmentArray.put(JSONObject()
                    .put("id", segment.id)
                    .put("audioSourceId", segment.audioSourceId)
                    .put("startMs", segment.startMs)
                    .put("endMs", segment.endMs)
                    .put("transcript", segment.transcript)
                    .put("createdAt", segment.createdAt))
            }
            manifest.put("segments", segmentArray)

            val takeArray = JSONArray()
            for (take in takes) {
                takeArray.put(JSONObject()
                    .put("id", take.id)
                    .put("segmentId", take.segmentId)
                    .put("createdAt", take.createdAt)
                    .put("overallScore", take.overallScore.toDouble())
                    .put("pitchScore", take.pitchScore.toDouble())
                    .put("timingScore", take.timingScore.toDouble())
                    .put("intensityScore", take.intensityScore.toDouble())
                    .put("nativeDurationMs", take.nativeDurationMs)
                    .put("userDurationMs", take.userDurationMs)
                    .put("recordingEntry", addFile(take.recordingPath) ?: JSONObject.NULL)
                    .put("originalRecordingEntry", addFile(take.originalRecordingPath) ?: JSONObject.NULL)
                    .put("practiceDate", take.practiceDate.ifBlank {
                        Instant.ofEpochMilli(take.createdAt).atZone(ZoneId.systemDefault()).toLocalDate().toString()
                    })
                    .put("trimmed", take.trimmed)
                    .put("verdict", take.verdict))
            }
            manifest.put("takes", takeArray)
            manifest.put("practiceDays", JSONArray().also { array ->
                days.sortedBy { it.date }.forEach { day ->
                    array.put(JSONObject().put("date", day.date).put("practiceSeconds", day.practiceSeconds))
                }
            })
            manifest.put("settings", JSONObject()
                .put("dailyGoalMinutes", settings.dailyGoalMinutes)
                .put("dailyTakeGoal", settings.dailyTakeGoal)
                .put("pitchRange", settings.pitchRange.name)
                .put("defaultReplayCount", settings.defaultReplayCount)
                .put("silenceThresholdDb", settings.silenceThresholdDb.toDouble()))

            val subtitleArray = JSONArray()
            for (source in sources) {
                val subtitles = File(context.filesDir, "subtitles/source_${source.id}.srt")
                if (!subtitles.isFile) continue
                val nameFile = File(context.filesDir, "subtitles/source_${source.id}.name")
                subtitleArray.put(JSONObject()
                    .put("audioSourceId", source.id)
                    .put("subtitleEntry", addFile(subtitles.absolutePath) ?: JSONObject.NULL)
                    .put("nameEntry", addFile(nameFile.absolutePath) ?: JSONObject.NULL)
                    .put("displayName", if (nameFile.isFile) runCatching { nameFile.readText(Charsets.UTF_8) }.getOrDefault("captions.srt") else "captions.srt"))
            }
            manifest.put("subtitles", subtitleArray)

            zip.putNextEntry(ZipEntry(MANIFEST))
            zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        return Preview(
            schemaVersion = SCHEMA_VERSION,
            createdAt = System.currentTimeMillis(),
            sourceCount = sources.size,
            segmentCount = segments.size,
            takeCount = takes.size,
            practiceDayCount = days.size,
            subtitleCount = File(context.filesDir, "subtitles").listFiles()
                ?.count { it.isFile && it.name.matches(Regex("source_\\d+\\.srt")) } ?: 0,
            includedMediaBytes = mediaBytes
        )
    }

    suspend fun preview(uri: Uri): Preview = withTemporaryZip(uri) { zip ->
        val manifest = readManifest(zip)
        var bytes = 0L
        val assets = zip.entries().asSequence().filter { !it.isDirectory && it.name.startsWith("assets/") }
        for (entry in assets) if (entry.size > 0) bytes += entry.size
        Preview(
            schemaVersion = manifest.getInt("schemaVersion"),
            createdAt = manifest.optLong("createdAt", 0L),
            sourceCount = manifest.getJSONArray("audioSources").length(),
            segmentCount = manifest.getJSONArray("segments").length(),
            takeCount = manifest.getJSONArray("takes").length(),
            practiceDayCount = manifest.getJSONArray("practiceDays").length(),
            subtitleCount = manifest.optJSONArray("subtitles")?.length() ?: 0,
            includedMediaBytes = bytes
        )
    }

    suspend fun restore(uri: Uri, mode: RestoreMode): RestoreReport = withTemporaryZip(uri) { zip ->
        val manifest = readManifest(zip)
        val token = UUID.randomUUID().toString().take(8)
        val staging = File(context.cacheDir, "shadowjp_restore_$token").apply { mkdirs() }
        val missing = mutableListOf<String>()
        var databaseCommitted = false
        try {
            val sourcesJson = manifest.getJSONArray("audioSources")
            val segmentsJson = manifest.getJSONArray("segments")
            val takesJson = manifest.getJSONArray("takes")
            val daysJson = manifest.getJSONArray("practiceDays")
            val subtitlesJson = manifest.optJSONArray("subtitles") ?: JSONArray()

            // Extract only manifest-referenced payloads to generated names. Archive paths are
            // validated and never used directly as filesystem paths.
            val referencedEntries = linkedSetOf<String>()
            for (i in 0 until sourcesJson.length()) addEntryRef(sourcesJson.getJSONObject(i), "mediaEntry", referencedEntries)
            for (i in 0 until takesJson.length()) {
                val obj = takesJson.getJSONObject(i)
                addEntryRef(obj, "recordingEntry", referencedEntries)
                addEntryRef(obj, "originalRecordingEntry", referencedEntries)
            }
            for (i in 0 until subtitlesJson.length()) {
                val obj = subtitlesJson.getJSONObject(i)
                addEntryRef(obj, "subtitleEntry", referencedEntries)
                addEntryRef(obj, "nameEntry", referencedEntries)
            }
            val stagedByEntry = LinkedHashMap<String, File>()
            for ((index, entryName) in referencedEntries.withIndex()) {
                val zipEntry = zip.getEntry(entryName)
                if (zipEntry == null || zipEntry.isDirectory) {
                    missing += entryName
                    continue
                }
                val stagedFile = File(staging, "payload_${index.toString().padStart(5, '0')}")
                zip.getInputStream(zipEntry).buffered().use { input ->
                    stagedFile.outputStream().buffered().use { output -> input.copyTo(output) }
                }
                stagedByEntry[entryName] = stagedFile
            }

            val dao = database.dao()
            val currentSources = dao.allAudioSourcesList()
            val currentSegments = dao.allSegmentsList()
            val currentTakes = dao.allTakesList()
            val currentDays = dao.practiceDays().first()
            val sourceMap = LinkedHashMap<Long, Long>()
            val segmentMap = LinkedHashMap<Long, Long>()
            val insertedSources = mutableListOf<AudioSourceEntity>()
            val insertedSegments = mutableListOf<SegmentEntity>()
            val insertedTakes = mutableListOf<TakeEntity>()
            var duplicates = 0
            val usedSourceIds = currentSources.mapTo(mutableSetOf()) { it.id }
            val usedSegmentIds = currentSegments.mapTo(mutableSetOf()) { it.id }
            val usedTakeIds = currentTakes.mapTo(mutableSetOf()) { it.id }
            val sourceHashMatches = mutableMapOf<String, Long>()
            if (mode == RestoreMode.MERGE) {
                for (existing in currentSources) {
                    val file = File(existing.localPath)
                    if (file.isFile) runCatching { sha256(file) }.getOrNull()?.let { sourceHashMatches[it] = existing.id }
                }
            }

            val sourceDestinations = LinkedHashMap<Long, String>()
            for (i in 0 until sourcesJson.length()) {
                val item = sourcesJson.getJSONObject(i)
                val oldId = item.getLong("id")
                val entry = nullableString(item, "mediaEntry")
                val backupHash = item.optString("mediaSha256", "")
                val matchedId = if (mode == RestoreMode.MERGE && backupHash.isNotBlank()) sourceHashMatches[backupHash] else null
                if (matchedId != null) {
                    sourceMap[oldId] = matchedId
                    sourceDestinations[oldId] = currentSources.first { it.id == matchedId }.localPath
                    duplicates++
                } else {
                    val destDir = File(context.filesDir, "imports/restore_$token")
                    val destFile = File(destDir, "source_${oldId}${extensionFor(entry)}")
                    val staged = entry?.let { stagedByEntry[it] }
                    if (staged != null) copyFile(staged, destFile) else {
                        missing += "Imported audio: ${item.optString("displayName", "source $oldId")}"
                    }
                    sourceDestinations[oldId] = destFile.absolutePath
                }
            }

            // For takes, choose stable, unique paths under a per-restore directory. Missing audio
            // is represented explicitly by a non-existing path and reported to the user.
            val takePaths = HashMap<Long, Pair<String, String?>>()
            for (i in 0 until takesJson.length()) {
                val item = takesJson.getJSONObject(i)
                val takeId = item.getLong("id")
                val recordingEntry = nullableString(item, "recordingEntry")
                val originalEntry = nullableString(item, "originalRecordingEntry")
                val recordFile = File(context.filesDir, "recordings/restore_$token/take_${takeId}${extensionFor(recordingEntry).ifBlank { ".wav" }}")
                recordingEntry?.let { stagedByEntry[it] }?.let { copyFile(it, recordFile) }
                    ?: run { missing += "Take recording $takeId" }
                val originalFile = if (originalEntry != null) {
                    File(context.filesDir, "recordings/restore_$token/original_${takeId}${extensionFor(originalEntry).ifBlank { ".wav" }}")
                        .also { dst -> stagedByEntry[originalEntry]?.let { copyFile(it, dst) } ?: run { missing += "Original recording for take $takeId" } }
                } else null
                takePaths[takeId] = recordFile.absolutePath to originalFile?.absolutePath
            }

            // Create source ID map before the segment/take import. REPLACE keeps stable IDs;
            // MERGE maps media by SHA-256 where possible and allocates collision-free IDs.
            database.withTransaction {
                if (mode == RestoreMode.REPLACE) {
                    dao.clearTakes(); dao.clearSegments(); dao.clearAudioSources(); dao.clearPracticeDays()
                    for (i in 0 until sourcesJson.length()) {
                        val item = sourcesJson.getJSONObject(i)
                        val oldId = item.getLong("id")
                        val entity = AudioSourceEntity(
                            id = oldId,
                            displayName = item.optString("displayName", "Imported media"),
                            localPath = sourceDestinations.getValue(oldId),
                            durationMs = item.optLong("durationMs", 0L),
                            importedAt = item.optLong("importedAt", System.currentTimeMillis()),
                            sourceUri = null,
                            sampleRateHz = nullableInt(item, "sampleRateHz"),
                            channelCount = nullableInt(item, "channelCount")
                        )
                        insertedSources += entity
                        sourceMap[oldId] = oldId
                    }
                    if (insertedSources.isNotEmpty()) dao.insertAudioSources(insertedSources)
                    for (i in 0 until segmentsJson.length()) {
                        val item = segmentsJson.getJSONObject(i)
                        insertedSegments += SegmentEntity(
                            id = item.getLong("id"), audioSourceId = item.getLong("audioSourceId"),
                            startMs = item.optLong("startMs"), endMs = item.optLong("endMs"),
                            transcript = item.optString("transcript", ""),
                            createdAt = item.optLong("createdAt", System.currentTimeMillis())
                        )
                    }
                    if (insertedSegments.isNotEmpty()) dao.insertSegments(insertedSegments)
                    for (i in 0 until takesJson.length()) {
                        val item = takesJson.getJSONObject(i)
                        val oldId = item.getLong("id")
                        val paths = takePaths.getValue(oldId)
                        insertedTakes += takeEntity(item, item.getLong("segmentId"), oldId, paths.first, paths.second)
                    }
                    if (insertedTakes.isNotEmpty()) dao.insertTakes(insertedTakes)
                    val importedDays = (0 until daysJson.length()).map { i ->
                        val obj = daysJson.getJSONObject(i)
                        PracticeDayEntity(obj.getString("date"), obj.optInt("practiceSeconds", 0).coerceAtLeast(0))
                    }
                    if (importedDays.isNotEmpty()) dao.upsertPracticeDays(importedDays)
                    for (i in 0 until segmentsJson.length()) {
                        val item = segmentsJson.getJSONObject(i)
                        segmentMap[item.getLong("id")] = item.getLong("id")
                    }
                } else {
                    // Add sources not already present. Keep source ID if free; otherwise let Room
                    // allocate a new ID. A content-hash match points to existing media instead.
                    for (i in 0 until sourcesJson.length()) {
                        val item = sourcesJson.getJSONObject(i)
                        val oldId = item.getLong("id")
                        if (sourceMap.containsKey(oldId)) continue
                        val candidateId = if (oldId !in usedSourceIds) oldId else 0L
                        val entity = AudioSourceEntity(
                            id = candidateId,
                            displayName = item.optString("displayName", "Imported media"),
                            localPath = sourceDestinations.getValue(oldId),
                            durationMs = item.optLong("durationMs", 0L),
                            importedAt = item.optLong("importedAt", System.currentTimeMillis()),
                            sourceUri = null,
                            sampleRateHz = nullableInt(item, "sampleRateHz"),
                            channelCount = nullableInt(item, "channelCount")
                        )
                        val newId = dao.insertAudioSource(entity)
                        sourceMap[oldId] = newId
                        usedSourceIds += newId
                        insertedSources += entity.copy(id = newId)
                    }

                    val allSegments = currentSegments.toMutableList()
                    for (i in 0 until segmentsJson.length()) {
                        val item = segmentsJson.getJSONObject(i)
                        val oldId = item.getLong("id")
                        val newSourceId = sourceMap[item.getLong("audioSourceId")] ?: continue
                        val same = allSegments.firstOrNull {
                            it.audioSourceId == newSourceId && it.startMs == item.optLong("startMs") &&
                                it.endMs == item.optLong("endMs")
                        }
                        if (same != null) {
                            segmentMap[oldId] = same.id
                            if (same.transcript.isBlank() && item.optString("transcript").isNotBlank()) {
                                dao.updateSegmentTranscript(same.id, item.optString("transcript"))
                            }
                            duplicates++
                        } else {
                            val requestedId = if (oldId !in usedSegmentIds) oldId else 0L
                            val segment = SegmentEntity(
                                id = requestedId, audioSourceId = newSourceId,
                                startMs = item.optLong("startMs"), endMs = item.optLong("endMs"),
                                transcript = item.optString("transcript", ""),
                                createdAt = item.optLong("createdAt", System.currentTimeMillis())
                            )
                            val newId = dao.insertSegment(segment)
                            segmentMap[oldId] = newId
                            usedSegmentIds += newId
                            allSegments += segment.copy(id = newId)
                            insertedSegments += segment.copy(id = newId)
                        }
                    }
                    val allTakes = currentTakes.toMutableList()
                    for (i in 0 until takesJson.length()) {
                        val item = takesJson.getJSONObject(i)
                        val oldId = item.getLong("id")
                        val mappedSegment = segmentMap[item.getLong("segmentId")] ?: continue
                        val isDuplicate = allTakes.any { existing ->
                            existing.segmentId == mappedSegment && existing.createdAt == item.optLong("createdAt") &&
                                kotlin.math.abs(existing.overallScore - item.optDouble("overallScore").toFloat()) < 0.01f &&
                                existing.userDurationMs == item.optLong("userDurationMs")
                        }
                        if (isDuplicate) {
                            duplicates++
                            continue
                        }
                        val paths = takePaths.getValue(oldId)
                        val requestedId = if (oldId !in usedTakeIds) oldId else 0L
                        val take = takeEntity(item, mappedSegment, requestedId, paths.first, paths.second)
                        val newId = dao.insertTake(take)
                        usedTakeIds += newId
                        allTakes += take.copy(id = newId)
                        insertedTakes += take.copy(id = newId)
                    }
                    val existingDays = currentDays.associateBy { it.date }.toMutableMap()
                    for (i in 0 until daysJson.length()) {
                        val item = daysJson.getJSONObject(i)
                        val date = item.getString("date")
                        val seconds = item.optInt("practiceSeconds", 0).coerceAtLeast(0)
                        // Max avoids inflating a day when the same backup is merged repeatedly.
                        val value = maxOf(seconds, existingDays[date]?.practiceSeconds ?: 0)
                        dao.upsertPracticeDay(PracticeDayEntity(date, value))
                        existingDays[date] = PracticeDayEntity(date, value)
                    }
                }
            }
            databaseCommitted = true

            // Full replacement must not leave stale subtitle associations from the old store.
            if (mode == RestoreMode.REPLACE) {
                File(context.filesDir, "subtitles").deleteRecursively()
                // The restored files live in uniquely named subdirectories. Remove old loose
                // imports/recordings while preserving the payload for this restore transaction.
                deleteChildrenExcept(File(context.filesDir, "imports"), "restore_$token")
                deleteChildrenExcept(File(context.filesDir, "recordings"), "restore_$token")
            }

            // Restore captions only after source ID remapping is known. In merge mode existing
            // subtitle files are kept; a missing caption track is filled from the backup.
            var restoredSubtitleCount = 0
            for (i in 0 until subtitlesJson.length()) {
                val item = subtitlesJson.getJSONObject(i)
                val sourceId = sourceMap[item.optLong("audioSourceId")] ?: continue
                val subtitleEntry = nullableString(item, "subtitleEntry") ?: continue
                val subtitlePayload = stagedByEntry[subtitleEntry] ?: continue
                val target = File(context.filesDir, "subtitles/source_$sourceId.srt")
                if (mode == RestoreMode.MERGE && target.isFile) continue
                try {
                    copyFile(subtitlePayload, target)
                    val nameEntry = nullableString(item, "nameEntry")
                    val namePayload = nameEntry?.let { stagedByEntry[it] }
                    val nameFile = File(context.filesDir, "subtitles/source_$sourceId.name")
                    if (namePayload != null) copyFile(namePayload, nameFile)
                    else nameFile.writeText(item.optString("displayName", "captions.srt"), Charsets.UTF_8)
                    restoredSubtitleCount++
                } catch (_: Exception) {
                    missing += "SRT subtitle track for media $sourceId"
                }
            }

            if (mode == RestoreMode.MERGE) {
                // Drop per-restore WAV copies for takes skipped as duplicates. Retain exactly the
                // files now referenced by newly inserted rows, avoiding silent storage growth on
                // repeated imports of the same archive.
                val retainedPaths = insertedTakes.flatMap { listOfNotNull(it.recordingPath, it.originalRecordingPath) }.toSet()
                for ((_, paths) in takePaths) {
                    if (paths.first !in retainedPaths) File(paths.first).delete()
                    paths.second?.let { if (it !in retainedPaths) File(it).delete() }
                }
            }

            if (mode == RestoreMode.REPLACE) {
                val settings = manifest.getJSONObject("settings")
                settingsRepository.setDailyGoalMinutes(settings.optInt("dailyGoalMinutes", 15))
                settingsRepository.setDailyTakeGoal(settings.optInt("dailyTakeGoal", 5))
                settingsRepository.setPitchRange(runCatching {
                    PitchRange.valueOf(settings.optString("pitchRange", PitchRange.STANDARD.name))
                }.getOrDefault(PitchRange.STANDARD))
                settingsRepository.setDefaultReplayCount(settings.optInt("defaultReplayCount", 1))
                settingsRepository.setSilenceThresholdDb(settings.optDouble("silenceThresholdDb", -45.0).toFloat())
            }

            RestoreReport(
                sourcesAdded = insertedSources.size,
                segmentsAdded = insertedSegments.size,
                takesAdded = insertedTakes.size,
                practiceDaysRestored = daysJson.length(),
                subtitlesRestored = restoredSubtitleCount,
                duplicatesSkipped = duplicates,
                missingMedia = missing.distinct()
            )
        } catch (e: Exception) {
            // Before commit, remove any media files copied out of the archive so a failed
            // restore cannot leave confusing stale files alongside unchanged live data.
            if (!databaseCommitted) {
                File(context.filesDir, "imports/restore_$token").deleteRecursively()
                File(context.filesDir, "recordings/restore_$token").deleteRecursively()
            }
            throw e
        } finally {
            staging.deleteRecursively()
        }
    }

    private fun takeEntity(item: JSONObject, segmentId: Long, id: Long, recordingPath: String, originalPath: String?): TakeEntity =
        TakeEntity(
            id = id,
            segmentId = segmentId,
            createdAt = item.optLong("createdAt", System.currentTimeMillis()),
            overallScore = item.optDouble("overallScore", 0.0).toFloat(),
            pitchScore = item.optDouble("pitchScore", 0.0).toFloat(),
            timingScore = item.optDouble("timingScore", 0.0).toFloat(),
            intensityScore = item.optDouble("intensityScore", 0.0).toFloat(),
            nativeDurationMs = item.optLong("nativeDurationMs", 0L),
            userDurationMs = item.optLong("userDurationMs", 0L),
            recordingPath = recordingPath,
            originalRecordingPath = originalPath,
            practiceDate = item.optString("practiceDate", "").ifBlank {
                Instant.ofEpochMilli(item.optLong("createdAt", System.currentTimeMillis()))
                    .atZone(ZoneId.systemDefault()).toLocalDate().toString()
            },
            trimmed = item.optBoolean("trimmed", false),
            verdict = item.optString("verdict", "")
        )

    private suspend fun <T> withTemporaryZip(uri: Uri, block: suspend (ZipFile) -> T): T {
        val temp = File(context.cacheDir, "shadowjp_backup_${UUID.randomUUID()}.zip")
        try {
            context.contentResolver.openInputStream(uri)?.buffered()?.use { input ->
                temp.outputStream().buffered().use { output -> input.copyTo(output) }
            } ?: throw IllegalArgumentException("Android could not open the selected backup file.")
            return ZipFile(temp).use { zip -> block(zip) }
        } catch (e: java.util.zip.ZipException) {
            throw IllegalArgumentException("This file is not a valid ShadowJP backup archive.", e)
        } finally {
            temp.delete()
        }
    }

    private fun readManifest(zip: ZipFile): JSONObject {
        val entry = zip.getEntry(MANIFEST)
            ?: throw IllegalArgumentException("This archive does not contain a ShadowJP backup manifest.")
        if (entry.size > MAX_MANIFEST_BYTES) throw IllegalArgumentException("The backup manifest is unexpectedly large.")
        val manifest = zip.getInputStream(entry).buffered().use { input ->
            val bytes = input.readBytes()
            if (bytes.size.toLong() > MAX_MANIFEST_BYTES) throw IllegalArgumentException("The backup manifest is unexpectedly large.")
            runCatching { JSONObject(String(bytes, Charsets.UTF_8)) }
                .getOrElse { throw IllegalArgumentException("The backup manifest is corrupted or unreadable.", it) }
        }
        if (manifest.optString("format") != FORMAT) {
            throw IllegalArgumentException("This file is not a ShadowJP backup.")
        }
        val version = manifest.optInt("schemaVersion", -1)
        if (version != SCHEMA_VERSION) {
            throw IllegalArgumentException("Backup format version $version is not supported by this app.")
        }
        for (key in listOf("audioSources", "segments", "takes", "practiceDays", "settings")) {
            if (!manifest.has(key) || manifest.isNull(key)) throw IllegalArgumentException("The backup is incomplete: missing $key.")
        }
        validateManifestData(manifest)
        return manifest
    }

    /** Validate IDs, relationships, dates, settings and payload names before touching live data. */
    private fun validateManifestData(manifest: JSONObject) {
        try {
            val sources = manifest.getJSONArray("audioSources")
            val segments = manifest.getJSONArray("segments")
            val takes = manifest.getJSONArray("takes")
            val days = manifest.getJSONArray("practiceDays")
            val settings = manifest.getJSONObject("settings")
            val sourceIds = mutableSetOf<Long>()
            val segmentIds = mutableSetOf<Long>()
            val takeIds = mutableSetOf<Long>()

            for (i in 0 until sources.length()) {
                val item = sources.getJSONObject(i)
                val id = item.getLong("id")
                require(id > 0L && sourceIds.add(id)) { "duplicate or invalid media ID" }
                require(item.optLong("durationMs", -1L) >= 0L) { "invalid media duration" }
                validateAssetReference(item, "mediaEntry")
            }
            for (i in 0 until segments.length()) {
                val item = segments.getJSONObject(i)
                val id = item.getLong("id")
                require(id > 0L && segmentIds.add(id)) { "duplicate or invalid phrase ID" }
                require(item.getLong("audioSourceId") in sourceIds) { "phrase refers to missing media" }
                require(item.optLong("startMs", -1L) >= 0L &&
                    item.optLong("endMs", -1L) > item.optLong("startMs", -1L)) {
                    "invalid phrase time range"
                }
            }
            for (i in 0 until takes.length()) {
                val item = takes.getJSONObject(i)
                val id = item.getLong("id")
                require(id > 0L && takeIds.add(id)) { "duplicate or invalid take ID" }
                require(item.getLong("segmentId") in segmentIds) { "take refers to a missing phrase" }
                require(item.optLong("nativeDurationMs", -1L) >= 0L &&
                    item.optLong("userDurationMs", -1L) >= 0L) { "invalid take duration" }
                for (score in listOf("overallScore", "pitchScore", "timingScore", "intensityScore")) {
                    require(item.getDouble(score).isFinite()) { "invalid analysis score" }
                }
                val practiceDate = item.optString("practiceDate", "")
                if (practiceDate.isNotBlank()) LocalDate.parse(practiceDate)
                validateAssetReference(item, "recordingEntry")
                validateAssetReference(item, "originalRecordingEntry")
            }
            val dateKeys = mutableSetOf<String>()
            for (i in 0 until days.length()) {
                val item = days.getJSONObject(i)
                val date = item.getString("date")
                LocalDate.parse(date)
                require(dateKeys.add(date)) { "duplicate practice date" }
                require(item.getInt("practiceSeconds") >= 0) { "invalid practice duration" }
            }
            val timeGoal = settings.getInt("dailyGoalMinutes")
            val takesGoal = settings.getInt("dailyTakeGoal")
            val replayCount = settings.getInt("defaultReplayCount")
            val silenceDb = settings.getDouble("silenceThresholdDb")
            require(timeGoal in 0..180 && takesGoal in 0..60) { "invalid daily goal settings" }
            require(replayCount in 1..10 && silenceDb.isFinite() && silenceDb in -60.0..-25.0) {
                "invalid application settings"
            }
            val subtitles = manifest.optJSONArray("subtitles") ?: JSONArray()
            for (i in 0 until subtitles.length()) {
                val item = subtitles.getJSONObject(i)
                require(item.getLong("audioSourceId") in sourceIds) { "subtitle refers to missing media" }
                validateAssetReference(item, "subtitleEntry")
                validateAssetReference(item, "nameEntry")
            }
        } catch (e: Exception) {
            if (e is IllegalArgumentException && e.message?.startsWith("The backup data is invalid") == true) throw e
            throw IllegalArgumentException("The backup data is invalid or incomplete: ${e.message ?: "unexpected field value"}.", e)
        }
    }

    private fun validateAssetReference(obj: JSONObject, key: String) {
        val name = nullableString(obj, key) ?: return
        if (!name.startsWith("assets/") || name.contains("..") || name.startsWith("/")) {
            throw IllegalArgumentException("unsafe payload reference for $key")
        }
    }

    private fun addEntryRef(obj: JSONObject, key: String, destination: MutableSet<String>) {
        val name = nullableString(obj, key) ?: return
        if (!name.startsWith("assets/") || name.contains("..") || name.startsWith("/")) {
            throw IllegalArgumentException("The backup contains an unsafe media reference.")
        }
        destination += name
    }

    private fun nullableString(obj: JSONObject, key: String): String? =
        if (!obj.has(key) || obj.isNull(key)) null else obj.optString(key).takeIf { it.isNotBlank() }

    private fun nullableInt(obj: JSONObject, key: String): Int? =
        if (!obj.has(key) || obj.isNull(key)) null else obj.optInt(key)

    private fun extensionFor(entry: String?): String {
        val ext = entry?.substringAfterLast('.', "")?.takeIf { it.matches(Regex("[A-Za-z0-9]{1,8}")) }
        return ext?.let { ".$it" }.orEmpty()
    }

    private fun deleteChildrenExcept(directory: File, keepName: String) {
        directory.listFiles()?.filterNot { it.name == keepName }?.forEach { child ->
            if (child.isDirectory) child.deleteRecursively() else child.delete()
        }
    }

    private fun copyFile(source: File, destination: File) {
        destination.parentFile?.mkdirs()
        source.inputStream().buffered().use { input ->
            destination.outputStream().buffered().use { output -> input.copyTo(output) }
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }
}
