package com.shadowjp.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.shadowjp.app.audio.AudioDecoder
import com.shadowjp.app.audio.WaveformCache
import com.shadowjp.app.data.db.AudioSourceEntity
import com.shadowjp.app.data.db.ShadowDao
import com.shadowjp.app.data.db.SegmentEntity
import com.shadowjp.app.data.db.SegmentWithSource
import com.shadowjp.app.data.db.TakeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Owns imported audio files and reusable A-B segments.
 *
 * Imported files are ALWAYS copied into app-private storage
 * (files/imports/<uuid>.<ext>) so they remain playable after restart
 * regardless of whether the SAF provider grants persistable permissions.
 * Import is metadata-only (duration / sample rate / channels via a header
 * probe) - the audio is NOT decoded at import time.
 */
class AudioLibraryRepository(
    private val context: Context,
    private val dao: ShadowDao,
    private val waveformCache: WaveformCache
) {
    sealed class ImportResult {
        data class Ok(val source: AudioSourceEntity) : ImportResult()
        data class Error(val message: String) : ImportResult()
    }

    sealed class RenameResult {
        data object Ok : RenameResult()
        data class Error(val message: String) : RenameResult()
    }

    val audioSources: Flow<List<AudioSourceEntity>> = dao.audioSources()
    val segments: Flow<List<SegmentWithSource>> = dao.segmentsWithSource()

    suspend fun import(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            // Ask for persistable permission when the provider offers it; we
            // copy the file anyway, so this is just belt and braces. The URI
            // is stored so the grant can be released when the clip is deleted.
            var permissionTaken = false
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                permissionTaken = true
            } catch (_: Exception) { /* provider does not offer persistable grants */ }

            val displayName = queryDisplayName(uri) ?: "audio"
            val ext = displayName.substringAfterLast('.', "bin")
                .lowercase()
                .take(5)
                .ifEmpty { "bin" }
            val dir = File(context.filesDir, "imports").apply { mkdirs() }
            val dest = File(dir, "${UUID.randomUUID()}.$ext")

            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            } ?: return@withContext ImportResult.Error("Could not read the selected file.")

            if (dest.length() == 0L) {
                dest.delete()
                return@withContext ImportResult.Error("The selected file is empty.")
            }

            // Metadata probe only - no PCM decoding. Fails fast on
            // non-audio/corrupt files; long files import just as quickly.
            val meta = AudioDecoder.probe(context, dest)
                ?: run {
                    dest.delete()
                    return@withContext ImportResult.Error(
                        "No supported audio track was found. Choose an audio file or a video (such as MP4) that contains audio."
                    )
                }

            val entity = AudioSourceEntity(
                displayName = displayName,
                localPath = dest.absolutePath,
                durationMs = meta.durationMs,
                importedAt = System.currentTimeMillis(),
                sourceUri = if (permissionTaken) uri.toString() else null,
                sampleRateHz = meta.sampleRateHz,
                channelCount = meta.channelCount
            )
            val id = dao.insertAudioSource(entity)
            ImportResult.Ok(entity.copy(id = id))
        } catch (e: Exception) {
            ImportResult.Error("Import failed: ${e.message ?: "unknown error"}")
        }
    }

    /** Rename the user-visible file name without changing or moving its stored media. */
    suspend fun renameClip(sourceId: Long, displayName: String): RenameResult =
        withContext(Dispatchers.IO) {
            val normalized = displayName.trim()
            if (normalized.isEmpty()) {
                return@withContext RenameResult.Error("A file name cannot be empty.")
            }
            if (normalized.length > 120) {
                return@withContext RenameResult.Error("Use a file name with 120 characters or fewer.")
            }
            if (dao.audioSource(sourceId) == null) {
                return@withContext RenameResult.Error("This audio file is no longer available.")
            }
            try {
                dao.updateAudioSourceDisplayName(sourceId, normalized)
                RenameResult.Ok
            } catch (e: Exception) {
                RenameResult.Error("Could not rename the file: ${e.message ?: "database error"}")
            }
        }

    private fun queryDisplayName(uri: Uri): String? =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    /** Save (or reuse) an A-B selection as a reusable segment. */
    suspend fun saveSegment(
        audioSourceId: Long,
        startMs: Long,
        endMs: Long,
        transcript: String = ""
    ): Long {
        if (endMs - startMs < 200) return -1 // reject degenerate ranges
        if (dao.segmentExists(audioSourceId, startMs, endMs)) return -2
        return dao.insertSegment(
            SegmentEntity(
                audioSourceId = audioSourceId,
                startMs = startMs,
                endMs = endMs,
                transcript = transcript,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateSegmentTranscript(segmentId: Long, transcript: String) =
        dao.updateSegmentTranscript(segmentId, transcript)

    /**
     * Delete one segment plus its takes (FK cascade) and the take recording
     * files that no remaining take references.
     */
    suspend fun deleteSegment(id: Long) = withContext(Dispatchers.IO) {
        val takes = dao.takesForSegmentList(id)
        dao.deleteSegment(id) // cascades to takes
        for (t in takes) {
            deleteRecordingFileIfUnreferenced(t.recordingPath, t.id)
            t.originalRecordingPath?.let { deleteRecordingFileIfUnreferenced(it, t.id) }
        }
    }

    suspend fun segment(id: Long): SegmentWithSource? = dao.segmentWithSource(id)

    fun takesForSegment(segmentId: Long): Flow<List<TakeEntity>> =
        dao.takesForSegment(segmentId)

    suspend fun insertTake(take: TakeEntity): Long = dao.insertTake(take)

    // ---------------- individual clip deletion (v3) ----------------

    /** Dependent-record counts shown in the deletion confirmation dialog. */
    data class ClipDeletionInfo(
        val sourceId: Long,
        val displayName: String,
        val durationMs: Long,
        val segmentCount: Int,
        val takeCount: Int
    )

    suspend fun clipDeletionInfo(sourceId: Long): ClipDeletionInfo? =
        withContext(Dispatchers.IO) {
            val src = dao.audioSource(sourceId) ?: return@withContext null
            ClipDeletionInfo(
                sourceId = src.id,
                displayName = src.displayName,
                durationMs = src.durationMs,
                segmentCount = dao.segmentCountForSource(sourceId),
                takeCount = dao.takeCountForSource(sourceId)
            )
        }

    sealed class DeleteClipResult {
        data class Ok(val segmentsRemoved: Int, val takesRemoved: Int) : DeleteClipResult()
        data class Error(val message: String) : DeleteClipResult()
    }

    /**
     * Delete one imported clip and everything it owns:
     *
     *  1. Collect dependent segments/takes (for file cleanup and reporting).
     *  2. Single Room transaction removes takes -> segments -> source, so the
     *     DB can never hold segments pointing at a missing source.
     *  3. Filesystem cleanup AFTER the transaction: take recordings that no
     *     remaining take references, the app-managed import copy (only when
     *     no other source row references the same path), session trim copies,
     *     and cached waveforms for those paths. File deletion failure is
     *     reported but does NOT roll back the DB: orphaned files in
     *     app-private storage are inert and are swept on the next Clear All
     *     Data or reinstall - a recoverable, never-inconsistent end state.
     *  4. Release the persisted SAF read permission for the original URI.
     *
     * The user's ORIGINAL document outside app storage is never touched.
     */
    suspend fun deleteClip(sourceId: Long): DeleteClipResult = withContext(Dispatchers.IO) {
        val src = dao.audioSource(sourceId)
            ?: return@withContext DeleteClipResult.Error("Clip not found.")
        val takes = dao.takesForSource(sourceId)
        val segmentCount = dao.segmentCountForSource(sourceId)

        try {
            dao.deleteClipCascade(sourceId)
        } catch (e: Exception) {
            return@withContext DeleteClipResult.Error(
                "Could not delete the clip: ${e.message ?: "database error"}"
            )
        }

        val failures = ArrayList<String>()

        // Take recordings (both playback/export copies and kept originals).
        for (t in takes) {
            if (!deleteRecordingFileIfUnreferenced(t.recordingPath, t.id))
                failures += File(t.recordingPath).name
            t.originalRecordingPath?.let {
                if (!deleteRecordingFileIfUnreferenced(it, t.id)) failures += File(it).name
            }
        }

        // Session-local silence-trimmed copies of this source.
        val importsDir = File(context.filesDir, "imports")
        importsDir.listFiles()?.forEach { f ->
            if (f.name.startsWith("trimmed_${sourceId}_") && !f.delete()) failures += f.name
        }

        // The app-managed import copy - only when no other source references it.
        if (dao.otherSourcesWithPath(src.localPath, sourceId) == 0) {
            val f = File(src.localPath)
            if (f.exists() && !f.delete()) failures += f.name
        }
        waveformCache.deleteFor(src.localPath)

        // Release the persisted URI permission we took at import time.
        src.sourceUri?.let { uriString ->
            try {
                context.contentResolver.releasePersistableUriPermission(
                    Uri.parse(uriString),
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { /* grant may not exist; harmless */ }
        }

        if (failures.isEmpty()) DeleteClipResult.Ok(segmentCount, takes.size)
        else DeleteClipResult.Error(
            "Clip deleted, but ${failures.size} file(s) could not be removed " +
                "(${failures.take(3).joinToString()}). They are unused leftovers " +
                "and will be removed by Clear all data."
        )
    }

    /**
     * Delete a recording file unless another (surviving) take still points at
     * it. Returns false when the file exists but could not be deleted.
     */
    private suspend fun deleteRecordingFileIfUnreferenced(
        path: String,
        excludeTakeId: Long
    ): Boolean {
        val f = File(path)
        if (!f.exists()) return true
        if (dao.otherTakesWithRecordingPath(path, excludeTakeId) > 0) return true
        return f.delete()
    }

    // ---------------- export ----------------

    sealed class ExportResult {
        data class Ok(val bytes: Long) : ExportResult()
        data class Error(val message: String) : ExportResult()
    }

    /**
     * Export a PCM buffer as a 16-bit mono WAV through the system save picker
     * target [uri]. Entirely local - no network involved.
     */
    suspend fun exportWav(uri: Uri, pcm: com.shadowjp.app.audio.PcmData): ExportResult =
        withContext(Dispatchers.IO) {
            try {
                val tmp = File(context.cacheDir, "export_tmp.wav")
                com.shadowjp.app.audio.WavFile.write(tmp, pcm)
                context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    tmp.inputStream().use { it.copyTo(out) }
                } ?: return@withContext ExportResult.Error("Could not open the destination.")
                val bytes = tmp.length()
                tmp.delete()
                if (bytes <= 44) ExportResult.Error("Export produced an empty file.")
                else ExportResult.Ok(bytes)
            } catch (e: Exception) {
                ExportResult.Error("Export failed: ${e.message ?: "unknown error"}")
            }
        }

    /** Copy an already-stored take WAV to the save-picker target [uri]. */
    suspend fun exportTakeFile(uri: Uri, path: String): ExportResult =
        withContext(Dispatchers.IO) {
            try {
                val src = File(path)
                if (!src.exists()) return@withContext ExportResult.Error(
                    "The take file is no longer available."
                )
                context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                } ?: return@withContext ExportResult.Error("Could not open the destination.")
                ExportResult.Ok(src.length())
            } catch (e: Exception) {
                ExportResult.Error("Export failed: ${e.message ?: "unknown error"}")
            }
        }
}
