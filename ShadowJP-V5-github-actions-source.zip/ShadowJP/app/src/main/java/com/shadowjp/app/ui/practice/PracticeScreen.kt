package com.shadowjp.app.ui.practice

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shadowjp.app.AnalysisResultStore
import com.shadowjp.app.audio.NativePlayer
import com.shadowjp.app.ui.components.ABWaveformSelector
import com.shadowjp.app.ui.components.TimeRangeFields
import com.shadowjp.app.ui.components.formatTimeMs
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite

private fun fmtMs(ms: Long): String = formatTimeMs(ms)

@Composable
fun PracticeScreen(
    vm: PracticeViewModel,
    analysisStore: AnalysisResultStore,
    onBack: () -> Unit,
    onAnalyzed: () -> Unit
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var selectionToolsExpanded by remember { mutableStateOf(false) }
    var preciseExpanded by remember { mutableStateOf(false) }
    var displaySettingsExpanded by remember { mutableStateOf(false) }
    var utilitiesExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.analysisStore = analysisStore
        vm.onAnalyzed = onAnalyzed
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> vm.onMicPermissionResult(granted) }

    val subtitlePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(vm::importSrt) }

    LaunchedEffect(state.micPermissionNeeded) {
        if (state.micPermissionNeeded) {
            val granted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) vm.onMicPermissionResult(true)
            else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    if (state.phase == PracticeViewModel.Phase.RECORDING || state.preparingToRecord) {
        LivePracticeScreen(
            state = state,
            onStop = vm::finishRecordingAndAnalyze,
            onCancel = {
                if (state.phase == PracticeViewModel.Phase.RECORDING) vm.cancelRecording()
                else vm.cancelPendingRepeat()
            }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 176.dp, top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
                }
                Column(Modifier.weight(1f)) {
                    Text(state.title, style = MaterialTheme.typography.titleMedium,
                        color = SoftWhite, maxLines = 1)
                    Text("Select a phrase · listen · record", color = MutedGray,
                        style = MaterialTheme.typography.labelSmall)
                }
            }

            when (state.phase) {
                PracticeViewModel.Phase.LOADING -> {
                    Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Cyan)
                    }
                }
                PracticeViewModel.Phase.ERROR -> {
                    Text(state.error ?: "Something went wrong.", color = Bad)
                    OutlinedButton(onClick = onBack) { Text("Go back") }
                }
                PracticeViewModel.Phase.ANALYZING -> {
                    Column(
                        Modifier.fillMaxWidth().height(220.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = Cyan)
                        Spacer(Modifier.height(14.dp))
                        Text("Analyzing your take…", color = SoftWhite,
                            style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("Your phrase selection is held steady while the result is prepared.",
                            color = MutedGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
                else -> {
                    ABWaveformSelector(
                        waveform = state.waveform,
                        detailWaveform = state.detailWaveform,
                        durationMs = state.durationMs,
                        aMs = state.aMs,
                        bMs = state.bMs,
                        positionMs = state.positionMs,
                        viewportStartMs = state.viewportStartMs,
                        viewportEndMs = state.viewportEndMs,
                        onAChanged = vm::setA,
                        onBChanged = vm::setB,
                        onSeek = vm::seekTo,
                        onOverviewSeek = vm::seekFromOverview,
                        subtitles = state.subtitleCues,
                        captionsVisible = state.captionsVisible,
                        captionFontSp = state.captionFontSp,
                        captionLaneHeightDp = state.captionLaneHeightDp,
                        waveformVisible = state.waveformVisible,
                        waveformHeightDp = state.waveformHeightDp,
                        onSubtitleClick = vm::selectSubtitleCue
                    )
                    if (state.waveformPending || state.detailWaveformPending) {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth(),
                            color = Cyan
                        )
                        Text(
                            if (state.detailWaveformPending) "Loading detail for this time range…"
                            else "Building full-recording overview…",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/srt", "text/plain", "application/octet-stream")) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.subtitleCues.isEmpty()) "Import SRT captions" else "Replace SRT captions")
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (state.subtitleCues.isEmpty()) "Timed captions" else "${state.subtitleCues.size} caption cues",
                                color = if (state.subtitleCues.isEmpty()) MutedGray else Cyan,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1
                            )
                            if (state.subtitleFileName != null) {
                                Text(state.subtitleFileName, color = MutedGray,
                                    style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            } else {
                                Text(".srt subtitle files", color = MutedGray,
                                    style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = state.captionsVisible,
                            onClick = { vm.setCaptionsVisible(!state.captionsVisible) },
                            label = { Text("Captions") }
                        )
                        FilterChip(
                            selected = state.waveformVisible,
                            onClick = { vm.setWaveformVisible(!state.waveformVisible) },
                            label = { Text("Waveform") }
                        )
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { displaySettingsExpanded = !displaySettingsExpanded }) {
                            Text(if (displaySettingsExpanded) "Hide display settings" else "Display settings")
                        }
                    }
                    AnimatedVisibility(displaySettingsExpanded) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (state.subtitleCues.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Caption size", color = MutedGray, style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.width(100.dp))
                                    Slider(
                                        value = state.captionFontSp,
                                        onValueChange = vm::setCaptionFontSp,
                                        valueRange = 10f..22f,
                                        steps = 11,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${state.captionFontSp.toInt()}sp", color = SoftWhite,
                                        style = MaterialTheme.typography.labelSmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Caption track", color = MutedGray, style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.width(100.dp))
                                    Slider(
                                        value = state.captionLaneHeightDp,
                                        onValueChange = vm::setCaptionLaneHeightDp,
                                        valueRange = 38f..110f,
                                        steps = 6,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${state.captionLaneHeightDp.toInt()}dp", color = SoftWhite,
                                        style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (state.waveformVisible) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Waveform height", color = MutedGray, style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.width(100.dp))
                                    Slider(
                                        value = state.waveformHeightDp,
                                        onValueChange = vm::setWaveformHeightDp,
                                        valueRange = 88f..240f,
                                        steps = 7,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text("${state.waveformHeightDp.toInt()}dp", color = SoftWhite,
                                        style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Text("Tap a caption block to select its timestamp range. Captions stay aligned when you zoom or pan.",
                                color = MutedGray, style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    TextButton(onClick = { selectionToolsExpanded = !selectionToolsExpanded }) {
                        Icon(Icons.Default.Tune, null, tint = MutedGray, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (selectionToolsExpanded) "Hide selection tools" else "Selection tools", color = MutedGray)
                    }
                    AnimatedVisibility(selectionToolsExpanded) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedButton(onClick = { vm.panDetail(-1) }, modifier = Modifier.weight(1f),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { Text("←") }
                                OutlinedButton(onClick = { vm.zoomDetail(false) }, modifier = Modifier.weight(1f),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { Text("− Zoom") }
                                OutlinedButton(onClick = vm::centerDetailOnSelection, modifier = Modifier.weight(1.4f),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { Text("Center A–B") }
                                OutlinedButton(onClick = { vm.zoomDetail(true) }, modifier = Modifier.weight(1f),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { Text("+ Zoom") }
                                OutlinedButton(onClick = { vm.panDetail(1) }, modifier = Modifier.weight(1f),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)) { Text("→") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Boundary", color = MutedGray, style = MaterialTheme.typography.labelMedium)
                                TextButton(onClick = vm::setAAtPlayhead) { Text("Set A at playhead") }
                                TextButton(onClick = vm::setBAtPlayhead) { Text("Set B at playhead") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Fine adjust", color = MutedGray, style = MaterialTheme.typography.labelMedium)
                                TextButton(onClick = { vm.nudgeA(-50) }) { Text("A −50ms") }
                                TextButton(onClick = { vm.nudgeA(50) }) { Text("A +50ms") }
                                TextButton(onClick = { vm.nudgeB(-50) }) { Text("B −50ms") }
                                TextButton(onClick = { vm.nudgeB(50) }) { Text("B +50ms") }
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = vm::togglePlay) {
                            Icon(
                                if (state.playing && !state.loopingAB) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play or pause", tint = SoftWhite, modifier = Modifier.size(30.dp)
                            )
                        }
                        OutlinedButton(
                            onClick = { if (state.loopingAB) vm.stopLoop() else vm.playSelection() },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(if (state.loopingAB) Icons.Default.Stop else Icons.Default.Repeat,
                                null, tint = Cyan, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (state.loopingAB) "Stop loop" else "Loop A–B ×${state.replayCount}")
                        }
                        Spacer(Modifier.weight(1f))
                        Text("${fmtMs(state.bMs - state.aMs)}", color = Cyan,
                            style = MaterialTheme.typography.labelLarge)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Speed", color = MutedGray, style = MaterialTheme.typography.labelMedium)
                        NativePlayer.Speed.entries.forEach { speed ->
                            FilterChip(selected = state.speed == speed, onClick = { vm.setSpeed(speed) },
                                label = { Text(speed.label) })
                        }
                    }
                    AnimatedVisibility(state.practiceMode == PracticeViewModel.PracticeMode.REPEAT_AFTER) {
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Native replays before recording", color = SoftWhite,
                                    style = MaterialTheme.typography.labelMedium)
                                Text("Listen to the phrase this many times, then your mic starts.",
                                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
                            }
                            listOf(1, 2, 3, 5).forEach { n ->
                                FilterChip(selected = state.replayCount == n, onClick = { vm.setReplayCount(n) },
                                    label = { Text("$n") })
                            }
                        }
                    }

                    TextButton(onClick = { preciseExpanded = !preciseExpanded }) {
                        Text(if (preciseExpanded) "Hide precise timestamps" else "Precise timestamps")
                    }
                    AnimatedVisibility(preciseExpanded) {
                        TimeRangeFields(
                            aMs = state.aMs,
                            bMs = state.bMs,
                            durationMs = state.durationMs,
                            onRange = vm::setRangeExact
                        )
                    }

                    TextButton(onClick = { utilitiesExpanded = !utilitiesExpanded }) {
                        Icon(Icons.Default.ContentCut, null, tint = MutedGray, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (utilitiesExpanded) "Hide utilities" else "Utilities", color = MutedGray)
                    }
                    AnimatedVisibility(utilitiesExpanded) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (!state.sourceTrimmed) {
                                TextButton(onClick = vm::trimSourceSilence, enabled = !state.trimming) {
                                    if (state.trimming) CircularProgressIndicator(
                                        color = MutedGray, modifier = Modifier.size(16.dp), strokeWidth = 2.dp
                                    ) else Icon(Icons.Default.ContentCut, null, tint = MutedGray,
                                        modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (state.trimming) "Scanning source…" else "Trim source silence (non-destructive)", color = MutedGray)
                                }
                            } else {
                                Text("Silence-trimmed session copy in use; original import is untouched.",
                                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }

        if (state.phase == PracticeViewModel.Phase.READY && !state.preparingToRecord) {
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding().imePadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = state.practiceMode == PracticeViewModel.PracticeMode.REPEAT_AFTER,
                        onClick = { vm.setPracticeMode(PracticeViewModel.PracticeMode.REPEAT_AFTER) },
                        label = { Text("Repeat-after") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = state.practiceMode == PracticeViewModel.PracticeMode.CHORUS,
                        onClick = { vm.setPracticeMode(PracticeViewModel.PracticeMode.CHORUS) },
                        label = { Text("Chorus") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Button(
                    onClick = {
                        if (state.practiceMode == PracticeViewModel.PracticeMode.CHORUS) vm.startChorusFlow()
                        else vm.startRepeatAfterFlow()
                    },
                    enabled = !state.trimming && !state.micPermissionNeeded && !state.preparingToRecord,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Mic, null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        when {
                            state.trimming -> "Preparing source…"
                            state.practiceMode == PracticeViewModel.PracticeMode.CHORUS -> "Listen once, then chorus"
                            else -> "Listen ×${state.replayCount}, then record"
                        }
                    )
                }
                Text(
                    if (state.practiceMode == PracticeViewModel.PracticeMode.CHORUS)
                        "First pass: listen. Second pass: speak in sync with the audio. Headphones recommended."
                    else "No live pitch or waveform feedback during recording.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }

        state.statusHint?.takeIf { state.phase != PracticeViewModel.Phase.ANALYZING }?.let { hint ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 96.dp, start = 16.dp, end = 16.dp),
                action = { TextButton(onClick = vm::clearHint) { Text("OK") } }
            ) { Text(hint) }
        }
    }
}
