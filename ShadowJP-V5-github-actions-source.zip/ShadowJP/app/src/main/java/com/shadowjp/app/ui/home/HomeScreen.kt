package com.shadowjp.app.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.shadowjp.app.ui.theme.Bad
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.NativeGhost
import com.shadowjp.app.ui.theme.SoftWhite

private fun fmtSecs(totalSecs: Int): String {
    val h = totalSecs / 3600
    val m = (totalSecs % 3600) / 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}

private fun fmtMs(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onPracticeSegment: (Long) -> Unit,
    onPracticeSource: (Long) -> Unit,
    onOpenSegments: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by vm.state.collectAsState()
    var renameCandidate by remember { mutableStateOf<com.shadowjp.app.data.db.AudioSourceEntity?>(null) }
    var renameText by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { vm.importAudio(it) } }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "ShadowJP",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = SoftWhite
                        )
                        Text(
                            "Japanese shadowing practice",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedGray
                        )
                    }
                    IconButton(onClick = onOpenStats) {
                        Icon(Icons.Default.BarChart, "Statistics", tint = MutedGray)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, "Settings", tint = MutedGray)
                    }
                }
            }

            // Daily overview inspired by the reference: one progress ring and a compact metric grid.
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Today", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.SemiBold, color = SoftWhite)
                                Text("Your shadowing practice at a glance",
                                    style = MaterialTheme.typography.bodySmall, color = MutedGray)
                            }
                            TextButton(onClick = onOpenSettings) {
                                Icon(Icons.Default.Settings, contentDescription = null,
                                    modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(5.dp))
                                Text("Goal settings")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GoalRing(
                                progress = if (state.goalConfigured) state.goalProgress else 0f,
                                modifier = Modifier.size(112.dp)
                            ) {
                                Text(
                                    if (state.goalConfigured) "${(state.goalProgress * 100).toInt()}%" else "—",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = SoftWhite
                                )
                                Text("daily goal", style = MaterialTheme.typography.labelSmall,
                                    color = MutedGray)
                            }
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = if (state.streak > 0) Cyan else MutedGray,
                                        modifier = Modifier.size(21.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text("${state.streak} day streak", color = SoftWhite,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold)
                                }
                                Text(
                                    when {
                                        state.goalMetToday -> "Daily goal complete"
                                        state.goalConfigured -> "Complete either target to finish today"
                                        else -> "Set a daily goal to track your streak"
                                    },
                                    color = if (state.goalMetToday) Cyan else MutedGray,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                if (state.goalConfigured && !state.goalMetToday) {
                                    Text("${(state.goalProgress * 100).toInt()}% toward your closest target",
                                        color = MutedGray, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        if (state.goalMinutes > 0) {
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Practice time", color = MutedGray,
                                        style = MaterialTheme.typography.bodySmall)
                                    Text("${fmtSecs(state.todaySeconds)} / ${state.goalMinutes} min",
                                        color = SoftWhite, style = MaterialTheme.typography.bodySmall)
                                }
                                LinearProgressIndicator(
                                    progress = { state.timeProgress.coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth(), color = Cyan,
                                    trackColor = NativeGhost.copy(alpha = 0.25f)
                                )
                            }
                        }
                        if (state.takeGoal > 0) {
                            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Completed takes", color = MutedGray,
                                        style = MaterialTheme.typography.bodySmall)
                                    Text("${state.todayTakes} / ${state.takeGoal}",
                                        color = SoftWhite, style = MaterialTheme.typography.bodySmall)
                                }
                                LinearProgressIndicator(
                                    progress = { state.takeProgress.coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth(), color = Cyan,
                                    trackColor = NativeGhost.copy(alpha = 0.25f)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            MetricCard(
                                title = "Practice time",
                                value = fmtSecs(state.todaySeconds),
                                detail = "today",
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Completed takes",
                                value = state.todayTakes.toString(),
                                detail = if (state.takeGoal > 0) "of ${state.takeGoal} goal" else "goal disabled",
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            MetricCard(
                                title = "Characters shadowed",
                                value = state.charactersToday.toString(),
                                detail = "from saved transcripts",
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "All-time practice",
                                value = fmtSecs(state.totalSeconds),
                                detail = "focused audio + recording",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Import CTA
            item {
                Button(
                    onClick = { picker.launch(arrayOf("audio/*", "video/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.importing
                ) {
                    if (state.importing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Importing...")
                    } else {
                        Icon(Icons.Default.AudioFile, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Import audio or video")
                    }
                }
                Text(
                    "Video files with audio (including MP4) work too. ShadowJP uses the audio track for practice and analysis.",
                    color = MutedGray,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            // Imported sources
            if (state.sources.isNotEmpty()) {
                item {
                    Text(
                        "Imported media",
                        style = MaterialTheme.typography.titleSmall,
                        color = MutedGray
                    )
                }
                items(state.sources.size) { i ->
                    val s = state.sources[i]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPracticeSource(s.id) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AudioFile, null, tint = Cyan, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.displayName, color = SoftWhite, maxLines = 1,
                                style = MaterialTheme.typography.bodyMedium)
                            Text(
                                fmtMs(s.durationMs) + (
                                    s.sampleRateHz?.let { " · ${it / 1000f}kHz" } ?: ""
                                    ) + (
                                    s.channelCount?.let {
                                        " · " + if (it == 1) "mono" else if (it == 2) "stereo" else "${it}ch"
                                    } ?: ""
                                    ),
                                color = MutedGray,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        IconButton(onClick = {
                            renameCandidate = s
                            renameText = s.displayName
                        }) {
                            Icon(Icons.Default.Edit, "Rename file", tint = MutedGray,
                                modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { vm.requestDeleteClip(s.id) }) {
                            Icon(Icons.Default.Delete, "Delete clip", tint = MutedGray,
                                modifier = Modifier.size(20.dp))
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                    }
                }
            }

            // Recent segments
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenSegments() }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LibraryMusic, null, tint = Cyan, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Segments (${state.segments.size})",
                        style = MaterialTheme.typography.titleSmall,
                        color = SoftWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                }
            }
            items(minOf(state.segments.size, 3)) { i ->
                val seg = state.segments[i]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPracticeSegment(seg.id) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(seg.displayName, color = SoftWhite, maxLines = 1,
                            style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${fmtMs(seg.startMs)} - ${fmtMs(seg.endMs)}",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MutedGray)
                }
            }
        }

        state.importError?.let { err ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                action = {
                    TextButton(onClick = { vm.clearImportError() }) { Text("OK") }
                }
            ) { Text(err) }
        }

        state.deleteMessage?.let { msg ->
            Snackbar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                action = {
                    TextButton(onClick = { vm.clearDeleteMessage() }) { Text("OK") }
                }
            ) { Text(msg) }
        }

        renameCandidate?.let { source ->
            AlertDialog(
                onDismissRequest = { renameCandidate = null },
                title = { Text("Rename file") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "This name is shown in your library. The stored media and practice history stay unchanged.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedGray
                        )
                        OutlinedTextField(
                            value = renameText,
                            onValueChange = { renameText = it.take(120) },
                            label = { Text("File name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        enabled = renameText.trim().isNotEmpty(),
                        onClick = {
                            vm.renameClip(source.id, renameText)
                            renameCandidate = null
                        }
                    ) { Text("Save name") }
                },
                dismissButton = {
                    TextButton(onClick = { renameCandidate = null }) { Text("Cancel") }
                }
            )
        }

        // Deletion confirmation with the ACTUAL dependent-record counts.
        state.deleteCandidate?.let { info ->
            val dependents = when {
                info.segmentCount == 0 -> "It has no saved segments or practice history."
                else -> "This will also remove ${info.segmentCount} associated " +
                    "segment(s) and ${info.takeCount} stored take(s) with their " +
                    "practice history."
            }
            AlertDialog(
                onDismissRequest = { if (!state.deleting) vm.cancelDeleteClip() },
                title = { Text("Remove this clip?") },
                text = {
                    Text(
                        "\"${info.displayName}\" (${fmtMs(info.durationMs)}) will be " +
                            "removed from ShadowJP. $dependents The original file " +
                            "outside the app is not touched. This cannot be undone."
                    )
                },
                confirmButton = {
                    TextButton(
                        enabled = !state.deleting,
                        onClick = { vm.confirmDeleteClip() }
                    ) { Text(if (state.deleting) "Removing..." else "Remove", color = Bad) }
                },
                dismissButton = {
                    TextButton(
                        enabled = !state.deleting,
                        onClick = { vm.cancelDeleteClip() }
                    ) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(title, color = MutedGray, style = MaterialTheme.typography.labelMedium)
            Text(value, color = SoftWhite, style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(detail, color = MutedGray, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun GoalRing(progress: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val inset = stroke / 2
            drawArc(
                color = NativeGhost.copy(alpha = 0.25f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = Cyan,
                startAngle = -90f,
                sweepAngle = 360f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = Size(size.width - stroke, size.height - stroke),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { content() }
    }
}
