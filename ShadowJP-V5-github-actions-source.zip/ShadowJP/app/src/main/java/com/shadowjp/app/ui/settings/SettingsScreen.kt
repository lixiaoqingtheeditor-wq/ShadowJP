package com.shadowjp.app.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.shadowjp.app.prefs.PitchRange
import com.shadowjp.app.data.BackupRepository
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val message by vm.message.collectAsState()
    val backupPreview by vm.backupPreview.collectAsState()
    val context = LocalContext.current
    var showClearConfirm by remember { mutableStateOf(false) }
    var showReplaceConfirm by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri -> if (uri != null) vm.exportCsv(context, uri) }
    val backupCreateLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri -> if (uri != null) vm.createBackup(uri) }
    val backupOpenLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) vm.previewBackup(uri) }

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
                }
                Text("Settings", style = MaterialTheme.typography.titleLarge, color = SoftWhite)
            }

            // Daily goals: any enabled target completes the day.
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Daily goals", color = SoftWhite, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Complete either goal to reach your daily target. A saved, successfully analyzed take counts toward the takes goal.",
                    color = MutedGray, style = MaterialTheme.typography.bodySmall
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Practice-time goal", color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            if (settings.dailyGoalMinutes > 0) "${settings.dailyGoalMinutes} minutes per day" else "Disabled",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Switch(
                        checked = settings.dailyGoalMinutes > 0,
                        onCheckedChange = { enabled -> vm.setGoal(if (enabled) 15 else 0) }
                    )
                }
                if (settings.dailyGoalMinutes > 0) {
                    Slider(
                        value = settings.dailyGoalMinutes.toFloat(),
                        onValueChange = { vm.setGoal(it.roundToInt()) },
                        valueRange = 5f..60f,
                        steps = 10
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Completed-takes goal", color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            if (settings.dailyTakeGoal > 0) "${settings.dailyTakeGoal} qualifying takes per day" else "Disabled",
                            color = MutedGray, style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Switch(
                        checked = settings.dailyTakeGoal > 0,
                        onCheckedChange = { enabled -> vm.setTakeGoal(if (enabled) 5 else 0) }
                    )
                }
                if (settings.dailyTakeGoal > 0) {
                    Slider(
                        value = settings.dailyTakeGoal.toFloat(),
                        onValueChange = { vm.setTakeGoal(it.roundToInt()) },
                        valueRange = 1f..30f,
                        steps = 28
                    )
                }
                if (settings.dailyGoalMinutes == 0 && settings.dailyTakeGoal == 0) {
                    Text("Both goals are disabled. No daily goal or streak day will be recorded until at least one is enabled.",
                        color = MutedGray, style = MaterialTheme.typography.labelSmall)
                }
            }

            // Pitch range
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Pitch range", color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PitchRange.entries.forEach { r ->
                        FilterChip(
                            selected = settings.pitchRange == r,
                            onClick = { vm.setPitchRange(r) },
                            label = { Text(r.label.substringBefore(" (")) }
                        )
                    }
                }
                Text("Match this to the speaker's voice, not yours - scoring is range-normalized.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
            }

            // Replay count
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Default A-B replay count", color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3, 5).forEach { n ->
                        FilterChip(
                            selected = settings.defaultReplayCount == n,
                            onClick = { vm.setReplayCount(n) },
                            label = { Text("$n") }
                        )
                    }
                }
            }

            // Silence-trim sensitivity (windowed RMS threshold, dBFS).
            Column {
                Text(
                    "Silence trim threshold: ${"%.0f".format(settings.silenceThresholdDb)} dBFS",
                    color = SoftWhite,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "Higher trims more aggressively; only leading/trailing silence is ever removed.",
                    color = MutedGray,
                    style = MaterialTheme.typography.labelSmall
                )
                Slider(
                    value = settings.silenceThresholdDb,
                    onValueChange = { vm.setSilenceThreshold(it) },
                    valueRange = -60f..-25f
                )
            }

            // Complete offline backup / restore. Backups contain media files as well as rows.
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backup & restore", color = SoftWhite, style = MaterialTheme.typography.titleMedium)
                Text(
                    "A complete backup includes practice history, phrase transcripts, take scores and recordings, imported audio/video, SRT captions, goals, and preferences. The file can be saved to local storage or a cloud-backed document provider.",
                    color = MutedGray, style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { backupCreateLauncher.launch(vm.suggestedBackupName()) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Create complete backup") }
                OutlinedButton(
                    onClick = { backupOpenLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Restore from backup") }
                Text(
                    "Merge keeps current preferences and existing items, adds missing records, and skips likely duplicates. Full restore replaces the current database and app preferences with the backup. Neither option uploads data to ShadowJP.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall
                )
            }

            // Export
            OutlinedButton(
                onClick = { exportLauncher.launch(vm.suggestedFileName()) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export scores as CSV") }

            Spacer(Modifier.height(8.dp))

            // Clear all data
            Button(
                onClick = { showClearConfirm = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Bad)
            ) { Text("Clear all data") }
        }

        message?.let {
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = { TextButton(onClick = { vm.clearMessage() }) { Text("OK") } }
            ) { Text(it) }
        }

        if (showClearConfirm) {
            AlertDialog(
                onDismissRequest = { showClearConfirm = false },
                title = { Text("Delete everything?") },
                text = {
                    Text(
                        "This permanently deletes all imported audio, segments, " +
                            "take history, recordings, and practice statistics. " +
                            "This cannot be undone."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showClearConfirm = false
                        vm.clearAllData()
                    }) { Text("Delete all", color = Bad) }
                },
                dismissButton = {
                    TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
                }
            )
        }

        backupPreview?.let { preview ->
            if (!showReplaceConfirm) {
                AlertDialog(
                    onDismissRequest = { vm.clearBackupPreview() },
                    title = { Text("Backup contents") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Format version: ${preview.schemaVersion}")
                            Text("Imported media: ${preview.sourceCount}")
                            Text("Saved phrases: ${preview.segmentCount}")
                            Text("Analyzed takes: ${preview.takeCount}")
                            Text("Practice days: ${preview.practiceDayCount}")
                            Text("SRT subtitle tracks: ${preview.subtitleCount}")
                            Text("Included media: ${"%.1f".format(preview.includedMediaBytes / (1024.0 * 1024.0))} MB")
                            Spacer(Modifier.height(4.dp))
                            Text("Merge adds records and skips likely duplicates. Full restore replaces current history and settings.",
                                color = MutedGray, style = MaterialTheme.typography.bodySmall)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            showReplaceConfirm = true
                        }) { Text("Full restore…", color = Bad) }
                    },
                    dismissButton = {
                        Row {
                            TextButton(onClick = {
                                vm.restoreBackup(BackupRepository.RestoreMode.MERGE)
                            }) { Text("Merge") }
                            TextButton(onClick = { vm.clearBackupPreview() }) { Text("Cancel") }
                        }
                    }
                )
            }
        }

        if (showReplaceConfirm && backupPreview != null) {
            AlertDialog(
                onDismissRequest = { showReplaceConfirm = false },
                title = { Text("Replace current data?") },
                text = {
                    Text(
                        "Full restore will replace ShadowJP's current practice history, saved phrases, imported media references, recordings, daily statistics, goals, and app preferences with the selected backup. Save a separate backup first if you may need the current data. This cannot be undone."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        showReplaceConfirm = false
                        vm.restoreBackup(BackupRepository.RestoreMode.REPLACE)
                    }) { Text("Replace current data", color = Bad) }
                },
                dismissButton = {
                    TextButton(onClick = { showReplaceConfirm = false }) { Text("Cancel") }
                }
            )
        }

    }
}
