package com.shadowjp.app.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.shadowjp.app.data.StreakRules
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.NativeGhost
import com.shadowjp.app.ui.theme.SoftWhite
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private fun fmtSecs(totalSecs: Int): String {
    val h = totalSecs / 3600
    val m = (totalSecs % 3600) / 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}

@Composable
fun StatsScreen(vm: StatsViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = SoftWhite)
            }
            Text("Statistics", style = MaterialTheme.typography.titleLarge, color = SoftWhite)
        }

        // Daily overview follows the visual hierarchy of the reference screenshot.
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Today", style = MaterialTheme.typography.titleLarge,
                            color = SoftWhite, fontWeight = FontWeight.SemiBold)
                        Text("Your daily shadowing progress", style = MaterialTheme.typography.bodySmall,
                            color = MutedGray)
                    }
                    Text(if (state.goalMetToday) "Goal complete" else if (state.goalConfigured) "In progress" else "No goal",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (state.goalMetToday) Cyan else MutedGray)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    StatsGoalRing(
                        progress = if (state.goalConfigured) state.goalProgress else 0f,
                        modifier = Modifier.size(108.dp)
                    ) {
                        Text(if (state.goalConfigured) "${(state.goalProgress * 100).toInt()}%" else "—",
                            style = MaterialTheme.typography.titleLarge, color = SoftWhite,
                            fontWeight = FontWeight.Bold)
                        Text("daily goal", style = MaterialTheme.typography.labelSmall, color = MutedGray)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("${state.streak} day streak", style = MaterialTheme.typography.titleMedium,
                            color = SoftWhite, fontWeight = FontWeight.SemiBold)
                        Text(when {
                            state.goalMetToday -> "You reached a daily target. Nice work."
                            state.goalConfigured -> "Meet either enabled target to complete the day."
                            else -> "Enable a daily target in Settings to track progress."
                        }, style = MaterialTheme.typography.bodySmall, color = MutedGray)
                        if (state.goalMinutes > 0) Text("Time: ${fmtSecs(state.todaySeconds)} / ${state.goalMinutes} min",
                            style = MaterialTheme.typography.labelSmall, color = SoftWhite)
                        if (state.takeGoal > 0) Text("Takes: ${state.todayTakes} / ${state.takeGoal}",
                            style = MaterialTheme.typography.labelSmall, color = SoftWhite)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatsMetricCard("Practice time", fmtSecs(state.todaySeconds), "today", Modifier.weight(1f))
                    StatsMetricCard("Completed takes", state.todayTakes.toString(),
                        if (state.takeGoal > 0) "of ${state.takeGoal} goal" else "goal disabled", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatsMetricCard("Characters shadowed", state.charactersToday.toString(),
                        "from saved transcripts", Modifier.weight(1f))
                    StatsMetricCard("All-time practice", fmtSecs(state.totalSeconds),
                        "focused audio + recording", Modifier.weight(1f))
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Performance summary", color = SoftWhite,
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                StatRow("Takes recorded", "${state.takes.size}")
                StatRow("Avg pitch score", "%.0f".format(state.avgPitch))
                StatRow("Avg timing score", "%.0f".format(state.avgTiming))
                StatRow("Avg intensity score", "%.0f".format(state.avgIntensity))
            }
        }

        // Daily takes vs. take target: last 14 days.
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    if (state.takeGoal > 0) "Takes per day (target: ${state.takeGoal})" else "Takes per day (takes target disabled)",
                    style = MaterialTheme.typography.titleSmall, color = SoftWhite
                )
                Spacer(Modifier.height(10.dp))
                TakesBarChart(counts = state.takesByDate, takeGoal = state.takeGoal)
                Spacer(Modifier.height(6.dp))
                Text("The take target is one way to complete a day; meeting the enabled practice-time target also completes it.",
                    color = MutedGray, style = MaterialTheme.typography.labelSmall)
            }
        }

        // Practice heatmap: last 15 weeks, 7 rows (Mon-Sun), GitHub-style.
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Practice heatmap", style = MaterialTheme.typography.titleSmall, color = SoftWhite)
                Spacer(Modifier.height(10.dp))
                PracticeHeatmap(
                    days = state.days.associate { it.date to it.practiceSeconds },
                    goalMinutes = state.goalMinutes,
                    takesByDate = state.takesByDate,
                    takeGoal = state.takeGoal
                )
            }
        }

        // Score trend (overall score per take, chronological)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Score trend", style = MaterialTheme.typography.titleSmall, color = SoftWhite)
                Spacer(Modifier.height(10.dp))
                if (state.takes.size < 2) {
                    Text("Record a few takes to see a trend.", color = MutedGray,
                        style = MaterialTheme.typography.bodySmall)
                } else {
                    ScoreTrend(scores = state.takes.map { it.overallScore })
                }
            }
        }
    }
}

@Composable
private fun StatsGoalRing(progress: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val inset = stroke / 2
            drawArc(NativeGhost.copy(alpha = 0.25f), -90f, 360f, false,
                Offset(inset, inset), Size(size.width - stroke, size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Cyan, -90f, 360f * progress.coerceIn(0f, 1f), false,
                Offset(inset, inset), Size(size.width - stroke, size.height - stroke),
                style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { content() }
    }
}

@Composable
private fun StatsMetricCard(title: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = MutedGray, style = MaterialTheme.typography.labelMedium)
            Text(value, color = SoftWhite, style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(detail, color = MutedGray, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MutedGray, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PracticeHeatmap(
    days: Map<String, Int>,
    goalMinutes: Int,
    takesByDate: Map<String, Int>,
    takeGoal: Int
) {
    val weeks = 15
    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val cal = Calendar.getInstance()
    cal.firstDayOfWeek = Calendar.MONDAY
    val today = Calendar.getInstance()
    // Move to Monday of this week.
    val dow = (today.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon=0
    cal.time = today.time
    cal.add(Calendar.DAY_OF_YEAR, -dow)
    cal.add(Calendar.WEEK_OF_YEAR, -(weeks - 1))

    val cells = ArrayList<Triple<String, Int, Int>>() // date, weekIdx, weekday
    for (w in 0 until weeks) {
        for (d in 0 until 7) {
            cells.add(Triple(fmt.format(cal.time), w, d))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
    }

    val goalSec = goalMinutes * 60
    val maxObservedSeconds = days.values.maxOrNull()?.coerceAtLeast(1) ?: 1
    Canvas(
        modifier = Modifier.fillMaxWidth().height(96.dp)
    ) {
        val gap = 2.dp.toPx()
        val cellW = (size.width - gap * (weeks - 1)) / weeks
        val cellH = (size.height - gap * 6) / 7
        for ((date, w, d) in cells) {
            val secs = days[date] ?: 0
            val goalMet = StreakRules.dayQualifies(
                StreakRules.DayActivity(secs, takesByDate[date] ?: 0), goalMinutes, takeGoal
            )
            val intensity = when {
                secs <= 0 -> 0f
                goalSec > 0 -> (secs.toFloat() / goalSec).coerceIn(0f, 1f)
                else -> (secs.toFloat() / maxObservedSeconds).coerceIn(0f, 1f)
            }
            val color = when {
                goalMet -> Cyan
                intensity <= 0f -> NativeGhost.copy(alpha = 0.18f)
                else -> Cyan.copy(alpha = 0.25f + 0.65f * intensity)
            }
            drawRect(
                color = color,
                topLeft = Offset(w * (cellW + gap), d * (cellH + gap)),
                size = Size(cellW, cellH)
            )
        }
    }
}

@Composable
private fun TakesBarChart(counts: Map<String, Int>, takeGoal: Int) {
    val days = 14
    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -(days - 1))
    val keys = (0 until days).map {
        val k = fmt.format(cal.time)
        cal.add(Calendar.DAY_OF_YEAR, 1)
        k
    }
    val maxCount = maxOf(takeGoal, keys.maxOf { counts[it] ?: 0 }, 1)

    Canvas(modifier = Modifier.fillMaxWidth().height(90.dp)) {
        val w = size.width
        val h = size.height
        val gap = 4.dp.toPx()
        val barW = (w - gap * (days - 1)) / days
        // Goal line, only when this target is enabled.
        if (takeGoal > 0) {
            val goalY = h - (takeGoal.toFloat() / maxCount).coerceAtMost(1f) * h
            drawLine(
                NativeGhost.copy(alpha = 0.5f),
                Offset(0f, goalY), Offset(w, goalY),
                strokeWidth = 1.dp.toPx()
            )
        }
        keys.forEachIndexed { i, key ->
            val c = counts[key] ?: 0
            if (c <= 0) return@forEachIndexed
            val barH = (c.toFloat() / maxCount).coerceAtMost(1f) * h
            drawRect(
                color = if (takeGoal > 0 && c >= takeGoal) Cyan else Cyan.copy(alpha = 0.35f),
                topLeft = Offset(i * (barW + gap), h - barH),
                size = Size(barW, barH)
            )
        }
    }
}

@Composable
private fun ScoreTrend(scores: List<Float>) {
    Canvas(modifier = Modifier.fillMaxWidth().height(110.dp)) {
        if (scores.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val maxPoints = 40
        val pts = scores.takeLast(maxPoints)
        val stepX = if (pts.size > 1) w / (pts.size - 1) else w

        // guide lines at 25/50/75
        for (g in listOf(25f, 50f, 75f)) {
            val y = h - g / 100f * h
            drawLine(NativeGhost.copy(alpha = 0.25f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        val path = Path()
        pts.forEachIndexed { i, s ->
            val x = i * stepX
            val y = h - (s.coerceIn(0f, 100f) / 100f) * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            drawCircle(Cyan, radius = 3.dp.toPx(), center = Offset(x, y))
        }
        drawPath(path, color = Cyan, style = Stroke(width = 2.dp.toPx()))
    }
}
