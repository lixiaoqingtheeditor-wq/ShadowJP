package com.shadowjp.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shadowjp.app.data.SubtitleCue
import com.shadowjp.app.ui.theme.Border
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.NativeGhost
import com.shadowjp.app.ui.theme.SoftWhite
import com.shadowjp.app.ui.theme.SurfaceCard
import kotlin.math.abs

/**
 * Full-source overview plus a range-decoded detail editor. The overview gives
 * context; only the detail pane edits A/B, and its coordinates always map to
 * source time through the explicit viewport.
 */
@Composable
fun ABWaveformSelector(
    waveform: FloatArray,
    durationMs: Long,
    aMs: Long,
    bMs: Long,
    positionMs: Long,
    onAChanged: (Long) -> Unit,
    onBChanged: (Long) -> Unit,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    detailWaveform: FloatArray = waveform,
    viewportStartMs: Long = 0L,
    viewportEndMs: Long = durationMs,
    onOverviewSeek: (Long) -> Unit = onSeek,
    subtitles: List<SubtitleCue> = emptyList(),
    captionsVisible: Boolean = true,
    captionFontSp: Float = 13f,
    captionLaneHeightDp: Float = 58f,
    waveformVisible: Boolean = true,
    waveformHeightDp: Float = 158f,
    onSubtitleClick: (SubtitleCue) -> Unit = {}
) {
    var dragging by remember { mutableStateOf<Char?>(null) }
    val latestAMs by rememberUpdatedState(aMs)
    val latestBMs by rememberUpdatedState(bMs)
    val safeDuration = durationMs.coerceAtLeast(1L)
    val view = SelectionMath.Viewport(
        viewportStartMs.coerceIn(0L, safeDuration),
        viewportEndMs.coerceIn(0L, safeDuration)
    ).let { if (it.endMs <= it.startMs) SelectionMath.Viewport(0, safeDuration) else it }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("FULL RECORDING", color = MutedGray, style = MaterialTheme.typography.labelSmall)
            Text("${shortTime(view.startMs)}–${shortTime(view.endMs)} in detail", color = MutedGray,
                style = MaterialTheme.typography.labelSmall)
        }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (waveformVisible) 44.dp else 22.dp)
                .pointerInput(durationMs) {
                    detectTapGestures { offset ->
                        if (durationMs > 0L) {
                            val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                            onOverviewSeek((fraction * durationMs).toLong())
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val mid = h / 2f
            if (waveformVisible && waveform.isNotEmpty()) {
                val count = waveform.size / 2
                val barW = w / count.coerceAtLeast(1)
                for (i in 0 until count) {
                    val x = (i + 0.5f) * barW
                    val t = x / w * durationMs
                    val selected = t in aMs.toFloat()..bMs.toFloat()
                    drawLine(
                        color = if (selected) Cyan.copy(alpha = 0.9f) else NativeGhost.copy(alpha = 0.5f),
                        start = Offset(x, mid - waveform[i * 2 + 1] * mid * 0.9f),
                        end = Offset(x, mid - waveform[i * 2] * mid * 0.9f),
                        strokeWidth = barW.coerceAtLeast(1f)
                    )
                }
            } else {
                drawLine(NativeGhost.copy(alpha = 0.45f), Offset(0f, mid), Offset(w, mid), 1.dp.toPx())
            }
            val aX = (aMs.toFloat() / safeDuration * w).coerceIn(0f, w)
            val bX = (bMs.toFloat() / safeDuration * w).coerceIn(0f, w)
            drawRect(Cyan.copy(alpha = 0.12f), Offset(aX, 0f), Size((bX - aX).coerceAtLeast(0f), h))
            val vx1 = (view.startMs.toFloat() / safeDuration * w).coerceIn(0f, w)
            val vx2 = (view.endMs.toFloat() / safeDuration * w).coerceIn(0f, w)
            drawRect(Cyan.copy(alpha = 0.12f), Offset(vx1, 0f), Size((vx2 - vx1).coerceAtLeast(0f), h), style = Stroke(1.dp.toPx()))
            val px = positionMs.toFloat() / safeDuration * w
            if (positionMs in 0..durationMs) drawLine(SoftWhite, Offset(px, 0f), Offset(px, h), 1.dp.toPx())
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${shortTime(aMs)}  A", color = Cyan, style = MaterialTheme.typography.labelMedium)
            Text("${shortTime(bMs)}  B · ${shortTime(bMs - aMs)}", color = Cyan,
                style = MaterialTheme.typography.labelMedium)
        }
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (waveformVisible) waveformHeightDp.dp else 52.dp)
                .pointerInput(viewportStartMs, viewportEndMs, durationMs) {
                    detectTapGestures { offset ->
                        onSeek(SelectionMath.fractionToTime(offset.x / size.width, view))
                    }
                }
                .pointerInput(viewportStartMs, viewportEndMs, durationMs) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val aX = SelectionMath.timeToFraction(latestAMs, view) * size.width
                            val bX = SelectionMath.timeToFraction(latestBMs, view) * size.width
                            val radius = 32.dp.toPx()
                            dragging = when {
                                abs(offset.x - aX) <= radius && abs(offset.x - aX) <= abs(offset.x - bX) -> 'A'
                                abs(offset.x - bX) <= radius -> 'B'
                                else -> null
                            }
                            if (dragging == null) {
                                onSeek(SelectionMath.fractionToTime(offset.x / size.width, view))
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val ms = SelectionMath.fractionToTime(change.position.x / size.width, view)
                            when (dragging) {
                                'A' -> onAChanged(ms)
                                'B' -> onBChanged(ms)
                                else -> Unit
                            }
                        },
                        onDragEnd = { dragging = null },
                        onDragCancel = { dragging = null }
                    )
                }
        ) {
            val w = size.width
            val h = size.height
            val mid = h / 2f
            if (waveformVisible && detailWaveform.isNotEmpty()) {
                val count = detailWaveform.size / 2
                val barW = w / count.coerceAtLeast(1)
                for (i in 0 until count) {
                    val x = (i + 0.5f) * barW
                    val ms = view.startMs + (x / w * view.spanMs).toLong()
                    val selected = ms in aMs..bMs
                    drawLine(
                        color = if (selected) Cyan else NativeGhost.copy(alpha = 0.65f),
                        start = Offset(x, mid - detailWaveform[i * 2 + 1] * mid * 0.94f),
                        end = Offset(x, mid - detailWaveform[i * 2] * mid * 0.94f),
                        strokeWidth = barW.coerceAtLeast(1.25f)
                    )
                }
            } else {
                drawLine(NativeGhost.copy(alpha = 0.45f), Offset(0f, mid), Offset(w, mid), 1.dp.toPx())
            }
            val aX = SelectionMath.timeToFraction(aMs, view) * w
            val bX = SelectionMath.timeToFraction(bMs, view) * w
            val visibleStart = maxOf(aMs, view.startMs)
            val visibleEnd = minOf(bMs, view.endMs)
            if (visibleEnd > visibleStart) {
                val x1 = SelectionMath.timeToFraction(visibleStart, view) * w
                val x2 = SelectionMath.timeToFraction(visibleEnd, view) * w
                drawRect(Cyan.copy(alpha = 0.10f), Offset(x1, 0f), Size(x2 - x1, h))
            }
            if (positionMs in view.startMs..view.endMs) {
                val px = SelectionMath.timeToFraction(positionMs, view) * w
                drawLine(SoftWhite, Offset(px, 0f), Offset(px, h), 1.5.dp.toPx())
            }
            drawBoundary(aX, h, 'A')
            drawBoundary(bX, h, 'B')
        }
        if (captionsVisible && subtitles.isNotEmpty()) {
            SubtitleTimelineTrack(
                subtitles = subtitles,
                viewStartMs = view.startMs,
                viewEndMs = view.endMs,
                playheadMs = positionMs,
                selectionStartMs = aMs,
                fontSp = captionFontSp,
                heightDp = captionLaneHeightDp,
                onSubtitleClick = onSubtitleClick
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(shortTime(view.startMs), color = MutedGray, style = MaterialTheme.typography.labelSmall)
            Text("Tap to seek · drag A/B to adjust", color = MutedGray, style = MaterialTheme.typography.labelSmall)
            Text(shortTime(view.endMs), color = MutedGray, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SubtitleTimelineTrack(
    subtitles: List<SubtitleCue>,
    viewStartMs: Long,
    viewEndMs: Long,
    playheadMs: Long,
    selectionStartMs: Long,
    fontSp: Float,
    heightDp: Float,
    onSubtitleClick: (SubtitleCue) -> Unit
) {
    val spanMs = (viewEndMs - viewStartMs).coerceAtLeast(1L)
    val visibleCues = remember(subtitles, viewStartMs, viewEndMs) {
        subtitles.filter { it.endMs > viewStartMs && it.startMs < viewEndMs }
    }
    val activeCue = remember(subtitles, visibleCues, viewStartMs, viewEndMs, playheadMs, selectionStartMs) {
        subtitleAtTime(subtitles, playheadMs)?.takeIf { it.endMs > viewStartMs && it.startMs < viewEndMs }
            ?: subtitleAtTime(subtitles, selectionStartMs)?.takeIf { it.endMs > viewStartMs && it.startMs < viewEndMs }
            ?: visibleCues.firstOrNull { it.startMs >= selectionStartMs }
    }
    // When zoomed far out, many short captions can occupy only a few pixels.
    // Keep the track lightweight and readable; the active caption preview above
    // always retains the exact cue text, and zooming in reveals individual cues.
    val displayCues = remember(visibleCues, activeCue) {
        if (visibleCues.size <= 120) visibleCues else {
            val stride = (visibleCues.size + 119) / 120
            (visibleCues.filterIndexed { index, _ -> index % stride == 0 } + listOfNotNull(activeCue))
                .distinct()
                .sortedBy { it.startMs }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (activeCue != null) {
            Text(
                activeCue.text,
                color = SoftWhite,
                fontSize = fontSp.sp,
                lineHeight = (fontSp * 1.24f).sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCard, RoundedCornerShape(8.dp))
                    .border(1.dp, Cyan.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(heightDp.dp)
                .clipToBounds()
                .background(SurfaceCard, RoundedCornerShape(9.dp))
                .border(1.dp, Border, RoundedCornerShape(9.dp))
        ) {
            val trackWidth = maxWidth
            displayCues.forEach { cue ->
                val start = maxOf(cue.startMs, viewStartMs)
                val end = minOf(cue.endMs, viewEndMs)
                if (end > start) {
                    val left = trackWidth * ((start - viewStartMs).toFloat() / spanMs.toFloat())
                    val width = trackWidth * ((end - start).toFloat() / spanMs.toFloat())
                    val active = cue == activeCue
                    Box(
                        modifier = Modifier
                            .offset(x = left, y = 0.dp)
                            .width(width.coerceAtLeast(1.dp))
                            .clickable { onSubtitleClick(cue) }
                            .height(heightDp.dp)
                            .padding(horizontal = 1.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (active) Cyan.copy(alpha = 0.22f) else Cyan.copy(alpha = 0.07f))
                            .border(1.dp, if (active) Cyan else Border, RoundedCornerShape(5.dp))
                            .padding(horizontal = 3.dp, vertical = 2.dp)
                    ) {
                        Text(
                            cue.text.replace('\n', ' '),
                            color = if (active) SoftWhite else SoftWhite.copy(alpha = 0.74f),
                            fontSize = fontSp.sp,
                            lineHeight = (fontSp * 1.18f).sp,
                            maxLines = if (heightDp >= 78f) 4 else 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

private fun subtitleAtTime(subtitles: List<SubtitleCue>, timeMs: Long): SubtitleCue? {
    var low = 0
    var high = subtitles.lastIndex
    var candidate = -1
    while (low <= high) {
        val mid = (low + high) ushr 1
        if (subtitles[mid].startMs <= timeMs) {
            candidate = mid
            low = mid + 1
        } else {
            high = mid - 1
        }
    }
    return subtitles.getOrNull(candidate)?.takeIf { timeMs < it.endMs }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBoundary(x: Float, height: Float, label: Char) {
    drawLine(Cyan, Offset(x, 0f), Offset(x, height), strokeWidth = 2.5.dp.toPx())
    val nub = 14.dp.toPx()
    val y = if (label == 'A') 0f else height - nub
    drawRect(Cyan, Offset(x - nub / 2f, y), Size(nub, nub))
}

private fun shortTime(ms: Long): String {
    val value = ms.coerceAtLeast(0L)
    val minutes = value / 60_000L
    val seconds = value % 60_000L / 1000L
    val tenths = value % 1000L / 100L
    return "%d:%02d.%d".format(minutes, seconds, tenths)
}
