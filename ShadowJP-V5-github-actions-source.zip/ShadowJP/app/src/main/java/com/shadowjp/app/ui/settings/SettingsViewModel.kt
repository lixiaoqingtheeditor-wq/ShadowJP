package com.shadowjp.app.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.BackupRepository
import com.shadowjp.app.prefs.PitchRange
import com.shadowjp.app.prefs.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsViewModel(private val app: ShadowApp) : ViewModel() {

    val settings: StateFlow<Settings> = app.settings.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Settings())

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _backupPreview = MutableStateFlow<BackupRepository.Preview?>(null)
    val backupPreview: StateFlow<BackupRepository.Preview?> = _backupPreview
    private var pendingBackupUri: Uri? = null

    fun setGoal(minutes: Int) = viewModelScope.launch {
        app.settings.setDailyGoalMinutes(minutes)
    }

    fun setTakeGoal(takes: Int) = viewModelScope.launch {
        app.settings.setDailyTakeGoal(takes)
    }

    fun setPitchRange(range: PitchRange) = viewModelScope.launch {
        app.settings.setPitchRange(range)
    }

    fun setReplayCount(count: Int) = viewModelScope.launch {
        app.settings.setDefaultReplayCount(count)
    }

    fun setSilenceThreshold(db: Float) = viewModelScope.launch {
        app.settings.setSilenceThresholdDb(db)
    }

    fun clearMessage() { _message.value = null }

    fun suggestedBackupName(): String =
        "shadowjp_backup_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".zip"

    fun createBackup(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val summary = BackupRepository(app, app.database, app.settings).export(uri)
            val mb = summary.includedMediaBytes / (1024.0 * 1024.0)
            _message.value = "Complete backup created. Included ${summary.sourceCount} media item(s), " +
                "${summary.segmentCount} phrase(s), ${summary.takeCount} take(s), and ${"%.1f".format(mb)} MB of files."
        } catch (e: Exception) {
            _message.value = "Backup export failed: ${e.message ?: "the selected location could not be written"}"
        }
    }

    fun previewBackup(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val preview = BackupRepository(app, app.database, app.settings).preview(uri)
            pendingBackupUri = uri
            _backupPreview.value = preview
            _message.value = null
        } catch (e: Exception) {
            pendingBackupUri = null
            _backupPreview.value = null
            _message.value = "Backup could not be opened: ${e.message ?: "unknown format or file error"}"
        }
    }

    fun clearBackupPreview() {
        pendingBackupUri = null
        _backupPreview.value = null
    }

    fun restoreBackup(mode: BackupRepository.RestoreMode) = viewModelScope.launch(Dispatchers.IO) {
        val uri = pendingBackupUri ?: return@launch
        try {
            val report = BackupRepository(app, app.database, app.settings).restore(uri, mode)
            _message.value = report.message(mode) + if (report.missingMedia.isNotEmpty()) {
                " Missing: " + report.missingMedia.take(4).joinToString(", ") +
                    if (report.missingMedia.size > 4) " and ${report.missingMedia.size - 4} more." else "."
            } else ""
        } catch (e: Exception) {
            _message.value = "Restore failed safely: ${e.message ?: "the backup could not be restored"}. Existing database changes were rolled back where possible."
        } finally {
            pendingBackupUri = null
            _backupPreview.value = null
        }
    }

    /** Full destructive wipe: DB rows + imported audio + recordings + caches. */
    fun clearAllData() = viewModelScope.launch(Dispatchers.IO) {
        val dao = app.database.dao()
        dao.clearTakes()
        dao.clearSegments()
        dao.clearAudioSources()
        dao.clearPracticeDays()
        File(app.filesDir, "imports").deleteRecursively()
        File(app.filesDir, "recordings").deleteRecursively()
        File(app.filesDir, "subtitles").deleteRecursively()
        app.waveformCache.clear()
        com.shadowjp.app.audio.PhraseCache.clear()
        _message.value = "All data deleted."
    }

    /** Build the CSV and write it to the user-picked URI. */
    fun exportCsv(context: Context, uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val takes = app.practice.exportCsvRows()
            if (takes.isEmpty()) {
                _message.value = "No takes to export yet."
                return@launch
            }
            val csv = buildString {
                appendLine(
                    "take_id,segment_id,timestamp,overall_score,pitch_score," +
                        "timing_score,intensity_score,native_duration_ms,user_duration_ms"
                )
                for (t in takes) {
                    appendLine(
                        listOf(
                            t.id, t.segmentId, t.createdAt,
                            t.overallScore, t.pitchScore, t.timingScore,
                            t.intensityScore, t.nativeDurationMs, t.userDurationMs
                        ).joinToString(",")
                    )
                }
            }
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(csv.toByteArray(Charsets.UTF_8))
            } ?: run {
                _message.value = "Could not write to the selected location."
                return@launch
            }
            _message.value = "Exported ${takes.size} takes to CSV."
        } catch (e: Exception) {
            _message.value = "Export failed: ${e.message ?: "unknown error"}"
        }
    }

    fun suggestedFileName(): String =
        "shadowjp_scores_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv"
}
