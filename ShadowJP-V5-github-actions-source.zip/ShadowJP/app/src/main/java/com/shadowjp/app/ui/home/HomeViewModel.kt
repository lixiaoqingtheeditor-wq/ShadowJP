package com.shadowjp.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.AudioLibraryRepository
import com.shadowjp.app.data.StreakRules
import com.shadowjp.app.data.db.AudioSourceEntity
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.SegmentWithSource
import com.shadowjp.app.data.db.TakeEntity
import com.shadowjp.app.prefs.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val todaySeconds: Int = 0,
    val goalMinutes: Int = 15,
    val todayTakes: Int = 0,
    val takeGoal: Int = 5,
    val streak: Int = 0,
    val totalSeconds: Int = 0,
    val takeCount: Int = 0,
    val charactersToday: Int = 0,
    val sources: List<AudioSourceEntity> = emptyList(),
    val segments: List<SegmentWithSource> = emptyList(),
    val importing: Boolean = false,
    val importError: String? = null,
    /** Clip pending deletion confirmation (with real dependent counts). */
    val deleteCandidate: AudioLibraryRepository.ClipDeletionInfo? = null,
    val deleting: Boolean = false,
    val deleteMessage: String? = null
) {
    val goalSeconds: Int get() = goalMinutes * 60
    val goalConfigured: Boolean get() = goalMinutes > 0 || takeGoal > 0

    /** A configured target is complete when either enabled goal is reached. */
    val goalMetToday: Boolean get() = StreakRules.dayQualifies(
        StreakRules.DayActivity(todaySeconds, todayTakes), goalMinutes, takeGoal
    )

    /** Ring progress follows the faster of the enabled targets (OR semantics). */
    val goalProgress: Float get() {
        val progress = buildList {
            if (goalMinutes > 0) add(todaySeconds.toFloat() / goalSeconds.coerceAtLeast(1))
            if (takeGoal > 0) add(todayTakes.toFloat() / takeGoal)
        }
        return progress.maxOrNull() ?: 0f
    }
    val timeProgress: Float get() =
        if (goalSeconds <= 0) 0f else todaySeconds.toFloat() / goalSeconds
    val takeProgress: Float get() =
        if (takeGoal <= 0) 0f else todayTakes.toFloat() / takeGoal
}

class HomeViewModel(private val app: ShadowApp) : ViewModel() {

    private val importing = MutableStateFlow(false)
    private val importError = MutableStateFlow<String?>(null)
    private val streak = MutableStateFlow(0)
    private val deleteCandidate =
        MutableStateFlow<AudioLibraryRepository.ClipDeletionInfo?>(null)
    private val deleting = MutableStateFlow(false)
    private val deleteMessage = MutableStateFlow<String?>(null)

    /** Re-emits so "today" counts roll over at midnight while the screen is open. */
    private val dayTicker = flow {
        while (true) {
            emit(Unit)
            delay(30_000)
        }
    }

    val state: StateFlow<HomeUiState> = combine(
        app.practice.practiceDays,
        app.practice.totalPracticeSeconds,
        app.settings.settings,
        app.audioLibrary.audioSources,
        app.audioLibrary.segments,
        combine(importing, importError, deleteCandidate, deleting, deleteMessage) { it },
        combine(app.practice.allTakes, dayTicker) { takes, _ -> takes },
        streak
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val days = arr[0] as List<PracticeDayEntity>
        val total = arr[1] as Int
        val settings = arr[2] as Settings
        val sources = arr[3] as List<AudioSourceEntity>
        val segments = arr[4] as List<SegmentWithSource>
        val misc = arr[5] as Array<*>
        val takes = arr[6] as List<TakeEntity>
        val todayKey = app.practice.today()
        val todayTakes = takes.filter { app.practice.takeDateKey(it) == todayKey }
        val transcriptBySegment = segments.associate { it.id to it.transcript }
        // Characters are counted from saved segment transcripts for each
        // successfully analyzed/persisted take (code points, not UTF-16 units).
        val charactersToday = todayTakes.sumOf { take ->
            val transcript = transcriptBySegment[take.segmentId].orEmpty()
            transcript.codePointCount(0, transcript.length)
        }
        HomeUiState(
            todaySeconds = days.firstOrNull { it.date == todayKey }?.practiceSeconds ?: 0,
            goalMinutes = settings.dailyGoalMinutes,
            todayTakes = todayTakes.size,
            takeGoal = settings.dailyTakeGoal,
            streak = arr[7] as Int,
            totalSeconds = total,
            takeCount = takes.size,
            charactersToday = charactersToday,
            sources = sources,
            segments = segments,
            importing = misc[0] as Boolean,
            importError = misc[1] as String?,
            deleteCandidate = misc[2] as AudioLibraryRepository.ClipDeletionInfo?,
            deleting = misc[3] as Boolean,
            deleteMessage = misc[4] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())

    init {
        // Streak depends on the OR-goal rule and on the underlying activity;
        // recompute when settings, takes or practice days change.
        viewModelScope.launch {
            combine(
                app.settings.settings,
                app.practice.allTakes,
                app.practice.practiceDays,
                dayTicker
            ) { s, _, _, _ -> s }.collect { s ->
                streak.value =
                    app.practice.streak(s.dailyGoalMinutes, s.dailyTakeGoal).currentStreak
            }
        }
    }

    fun importAudio(uri: android.net.Uri) {
        viewModelScope.launch {
            importing.value = true
            importError.value = null
            when (val r = app.audioLibrary.import(uri)) {
                is AudioLibraryRepository.ImportResult.Ok -> Unit
                is AudioLibraryRepository.ImportResult.Error -> importError.value = r.message
            }
            importing.value = false
        }
    }

    fun clearImportError() {
        importError.value = null
    }

    fun renameClip(sourceId: Long, displayName: String) {
        viewModelScope.launch {
            when (val result = app.audioLibrary.renameClip(sourceId, displayName)) {
                is AudioLibraryRepository.RenameResult.Ok -> importError.value = null
                is AudioLibraryRepository.RenameResult.Error -> importError.value = result.message
            }
        }
    }

    // ---------------- individual clip deletion ----------------

    /** Load real dependent counts and show the confirmation dialog. */
    fun requestDeleteClip(sourceId: Long) {
        viewModelScope.launch {
            deleteCandidate.value = app.audioLibrary.clipDeletionInfo(sourceId)
        }
    }

    /** Cancel leaves everything untouched. */
    fun cancelDeleteClip() {
        deleteCandidate.value = null
    }

    fun confirmDeleteClip() {
        val info = deleteCandidate.value ?: return
        viewModelScope.launch {
            deleting.value = true
            when (val r = app.audioLibrary.deleteClip(info.sourceId)) {
                is AudioLibraryRepository.DeleteClipResult.Ok ->
                    deleteMessage.value =
                        "Removed \"${info.displayName}\" with ${r.segmentsRemoved} segment(s) " +
                            "and ${r.takesRemoved} take(s)."
                is AudioLibraryRepository.DeleteClipResult.Error ->
                    deleteMessage.value = r.message
            }
            deleting.value = false
            deleteCandidate.value = null
        }
    }

    fun clearDeleteMessage() {
        deleteMessage.value = null
    }
}
