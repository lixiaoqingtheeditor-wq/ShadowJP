package com.shadowjp.app.ui.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shadowjp.app.ShadowApp
import com.shadowjp.app.data.StreakRules
import com.shadowjp.app.data.db.PracticeDayEntity
import com.shadowjp.app.data.db.SegmentWithSource
import com.shadowjp.app.data.db.TakeEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.LocalDate
import java.time.ZoneId

data class StatsUiState(
    val days: List<PracticeDayEntity> = emptyList(),
    val takes: List<TakeEntity> = emptyList(),
    val streak: Int = 0,
    val totalSeconds: Int = 0,
    val goalMinutes: Int = 15,
    val takeGoal: Int = 5,
    val todayTakes: Int = 0,
    val segments: List<SegmentWithSource> = emptyList()
) {
    val todayKey: String get() = LocalDate.now(ZoneId.systemDefault()).toString()
    val todaySeconds: Int get() = days.firstOrNull { it.date == todayKey }?.practiceSeconds ?: 0
    val goalConfigured: Boolean get() = goalMinutes > 0 || takeGoal > 0
    val goalMetToday: Boolean get() = StreakRules.dayQualifies(
        StreakRules.DayActivity(todaySeconds, todayTakes), goalMinutes, takeGoal
    )
    val goalProgress: Float get() = buildList {
        if (goalMinutes > 0) add(todaySeconds.toFloat() / (goalMinutes * 60).coerceAtLeast(1))
        if (takeGoal > 0) add(todayTakes.toFloat() / takeGoal)
    }.maxOrNull() ?: 0f
    val charactersToday: Int get() {
        val transcriptBySegment = segments.associate { it.id to it.transcript }
        return takes.asSequence().filter { (it.practiceDate.ifBlank {
            java.time.Instant.ofEpochMilli(it.createdAt).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        }) == todayKey }.sumOf { take ->
            val transcript = transcriptBySegment[take.segmentId].orEmpty()
            transcript.codePointCount(0, transcript.length)
        }
    }

    val avgPitch: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.pitchScore }.average().toFloat()
    val avgTiming: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.timingScore }.average().toFloat()
    val avgIntensity: Float get() =
        if (takes.isEmpty()) 0f else takes.map { it.intensityScore }.average().toFloat()

    /** Completed takes per local calendar day ("yyyy-MM-dd" -> count). */
    val takesByDate: Map<String, Int>
        get() {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val map = HashMap<String, Int>()
            for (t in takes) {
                val key = t.practiceDate.ifBlank { fmt.format(Date(t.createdAt)) }
                map[key] = (map[key] ?: 0) + 1
            }
            return map
        }
}

class StatsViewModel(private val app: ShadowApp) : ViewModel() {

    private val streak = MutableStateFlow(0)

    /** Recalculate date-scoped values when the local calendar day rolls over. */
    private val dayTicker = flow {
        while (true) {
            emit(Unit)
            delay(30_000)
        }
    }

    private val summaryState = combine(
        app.practice.practiceDays,
        combine(app.practice.allTakes, dayTicker) { takes, _ -> takes },
        app.practice.totalPracticeSeconds,
        app.settings.settings,
        app.audioLibrary.segments
    ) { days, takes, total, settings, segments ->
        StatsUiState(
            days = days,
            takes = takes,
            totalSeconds = total,
            goalMinutes = settings.dailyGoalMinutes,
            takeGoal = settings.dailyTakeGoal,
            todayTakes = takes.count { app.practice.takeDateKey(it) == app.practice.today() },
            segments = segments
        )
    }

    val state: StateFlow<StatsUiState> = combine(summaryState, streak) { summary, currentStreak ->
        summary.copy(streak = currentStreak)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatsUiState())

    init {
        viewModelScope.launch {
            combine(
                app.settings.settings,
                app.practice.allTakes,
                app.practice.practiceDays,
                dayTicker
            ) { s, _, _, _ -> s }.collect { s ->
                streak.value =
                    app.practice.streak(s.dailyGoalMinutes, s.dailyTakeGoal).currentStreak
            }
        }
    }
}
