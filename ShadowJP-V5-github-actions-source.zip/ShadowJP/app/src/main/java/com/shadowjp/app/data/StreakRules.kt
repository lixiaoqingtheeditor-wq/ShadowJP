package com.shadowjp.app.data

import java.util.Calendar

/**
 * Daily-goal and streak rules. A day qualifies when ANY enabled target is met:
 * practice time OR completed takes. A target value of zero means that target
 * is disabled. If both targets are disabled, there is no daily goal and no day
 * qualifies. Dates are local calendar days (yyyy-MM-dd).
 *
 * Past goal settings are not versioned per day, so history is evaluated against
 * the current settings. This preserves the existing data model's semantics.
 */
object StreakRules {

    data class DayActivity(
        val practiceSeconds: Int,
        val takes: Int
    )

    fun dayQualifies(activity: DayActivity?, goalMinutes: Int, takeGoal: Int): Boolean {
        if (activity == null) return false
        val timeEnabled = goalMinutes > 0
        val takesEnabled = takeGoal > 0
        if (!timeEnabled && !takesEnabled) return false
        return (timeEnabled && activity.practiceSeconds >= goalMinutes * 60) ||
            (takesEnabled && activity.takes >= takeGoal)
    }

    /**
     * Consecutive qualifying days ending today; when today has not qualified
     * yet, count backward from yesterday so an in-progress day cannot break a
     * streak prematurely.
     */
    fun currentStreak(
        days: Map<String, DayActivity>,
        goalMinutes: Int,
        takeGoal: Int,
        today: Calendar
    ): Int {
        if (goalMinutes <= 0 && takeGoal <= 0) return 0
        val cal = today.clone() as Calendar
        var streak = 0
        if (!dayQualifies(days[key(cal)], goalMinutes, takeGoal)) {
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        while (dayQualifies(days[key(cal)], goalMinutes, takeGoal)) {
            streak++
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return streak
    }

    fun key(cal: Calendar): String = "%04d-%02d-%02d".format(
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH) + 1,
        cal.get(Calendar.DAY_OF_MONTH)
    )
}
