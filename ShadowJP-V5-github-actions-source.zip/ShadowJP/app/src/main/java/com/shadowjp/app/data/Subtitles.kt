package com.shadowjp.app.data

/** A single timed cue parsed from an SRT subtitle file. Times are source-audio milliseconds. */
data class SubtitleCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

/** Small dependency-free SubRip parser so imported captions can be tested on the JVM. */
object SrtParser {
    private val timestamp = Regex("""(\d{1,}):(\d{2}):(\d{2})[,.](\d{1,3})""")

    fun parse(source: String): List<SubtitleCue> {
        if (source.isBlank()) return emptyList()
        val lines = source.removePrefix("\uFEFF")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
        val cues = mutableListOf<SubtitleCue>()
        var i = 0

        while (i < lines.size) {
            val timingIndex = lines.indexOfFirstFrom(i) { it.contains("-->") }
            if (timingIndex < 0) break
            val parts = lines[timingIndex].split("-->", limit = 2)
            if (parts.size != 2) {
                i = timingIndex + 1
                continue
            }
            val start = parseTime(parts[0].trim())
            // Ignore optional SRT positioning settings after the end timestamp.
            val end = parseTime(parts[1].trim())
            if (start == null || end == null || end <= start) {
                i = timingIndex + 1
                continue
            }

            i = timingIndex + 1
            val textLines = mutableListOf<String>()
            while (i < lines.size && lines[i].isNotBlank() && !lines[i].contains("-->")) {
                textLines += lines[i]
                i++
            }
            val text = cleanText(textLines.joinToString("\n").trim())
            if (text.isNotBlank()) cues += SubtitleCue(start, end, text)
            while (i < lines.size && lines[i].isBlank()) i++
        }
        return cues.sortedWith(compareBy<SubtitleCue> { it.startMs }.thenBy { it.endMs })
    }

    private fun parseTime(raw: String): Long? {
        val match = timestamp.find(raw) ?: return null
        val hours = match.groupValues[1].toLongOrNull() ?: return null
        val minutes = match.groupValues[2].toLongOrNull() ?: return null
        val seconds = match.groupValues[3].toLongOrNull() ?: return null
        val fraction = match.groupValues[4].padEnd(3, '0').take(3).toLongOrNull() ?: return null
        if (minutes > 59 || seconds > 59) return null
        return hours * 3_600_000L + minutes * 60_000L + seconds * 1_000L + fraction
    }

    private fun cleanText(value: String): String = value
        .replace(Regex("<[^>]*>"), "")
        .replace("&nbsp;", " ", ignoreCase = true)
        .replace("&amp;", "&", ignoreCase = true)
        .replace("&lt;", "<", ignoreCase = true)
        .replace("&gt;", ">", ignoreCase = true)
        .replace("&quot;", "\"", ignoreCase = true)
        .replace("&#39;", "'", ignoreCase = true)

    private inline fun <T> List<T>.indexOfFirstFrom(startIndex: Int, predicate: (T) -> Boolean): Int {
        for (index in startIndex.coerceAtLeast(0) until size) if (predicate(this[index])) return index
        return -1
    }
}
