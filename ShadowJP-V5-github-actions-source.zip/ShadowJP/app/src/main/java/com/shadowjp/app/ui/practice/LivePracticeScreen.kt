package com.shadowjp.app.ui.practice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shadowjp.app.ui.components.formatTimeMs
import com.shadowjp.app.ui.theme.Bad
import com.shadowjp.app.ui.theme.Black
import com.shadowjp.app.ui.theme.Border
import com.shadowjp.app.ui.theme.Cyan
import com.shadowjp.app.ui.theme.CyanDim
import com.shadowjp.app.ui.theme.MutedGray
import com.shadowjp.app.ui.theme.SoftWhite
import com.shadowjp.app.ui.theme.SurfaceCard

/** Focused recording state with a clear timer and just the controls needed for a take. */
@Composable
fun LivePracticeScreen(
    state: PracticeViewModel.UiState,
    onStop: () -> Unit,
    onCancel: () -> Unit
) {
    val isRecording = state.phase == PracticeViewModel.Phase.RECORDING
    val progress = if (state.recordingLimitMs > 0L) {
        (state.recordingElapsedMs.toFloat() / state.recordingLimitMs).coerceIn(0f, 1f)
    } else 0f
    val title = when {
        isRecording && state.practiceMode == PracticeViewModel.PracticeMode.CHORUS -> "Speak along — chorus pass"
        isRecording -> "Recording your attempt"
        state.statusHint?.contains("Get ready", ignoreCase = true) == true -> "Get ready to record"
        state.statusHint?.contains("Listen", ignoreCase = true) == true -> "Listen to the native phrase"
        else -> "Preparing your take"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "SHADOWJP  /  PRACTICE",
            color = Cyan,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(10.dp))
        Text(
            title,
            color = SoftWhite,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(6.dp))
        Text(
            state.title,
            color = MutedGray,
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(24.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceCard)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier
                        .background(
                            color = if (isRecording) Bad.copy(alpha = 0.13f) else Cyan.copy(alpha = 0.10f),
                            shape = RoundedCornerShape(50)
                        )
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .background(if (isRecording) Bad else Cyan, CircleShape)
                    )
                    Text(
                        when {
                            isRecording && state.practiceMode == PracticeViewModel.PracticeMode.CHORUS -> "CHORUS · AUDIO + MICROPHONE"
                            isRecording -> "REC  ·  MICROPHONE ACTIVE"
                            state.practiceMode == PracticeViewModel.PracticeMode.CHORUS -> "CHORUS · LISTEN FIRST"
                            else -> "NATIVE PHRASE PREPARATION"
                        },
                        color = if (isRecording) Bad else Cyan,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(22.dp))

                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(132.dp)) {
                    CircularProgressIndicator(
                        progress = { if (isRecording) progress else 0f },
                        modifier = Modifier.fillMaxSize(),
                        color = Cyan,
                        trackColor = Border,
                        strokeWidth = 5.dp
                    )
                    Box(
                        modifier = Modifier
                            .size(96.dp)
                            .background(CyanDim.copy(alpha = 0.78f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Mic else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(42.dp),
                            tint = Cyan
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))

                Text(
                    if (isRecording) formatElapsed(state.recordingElapsedMs) else "READY",
                    color = SoftWhite,
                    style = MaterialTheme.typography.displaySmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    fontSize = if (isRecording) 44.sp else 36.sp
                )
                Text(
                    when {
                        isRecording && state.practiceMode == PracticeViewModel.PracticeMode.CHORUS -> "SPEAK IN SYNC · AUDIO IS PLAYING"
                        isRecording -> "TIME RECORDED"
                        else -> state.statusHint ?: "The native phrase will play first."
                    },
                    color = MutedGray,
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(22.dp))

                if (isRecording) {
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = Cyan,
                        trackColor = Border
                    )
                    Spacer(Modifier.height(18.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Metric(
                        label = "PHRASE LENGTH",
                        value = formatCompactTime(state.bMs - state.aMs),
                        modifier = Modifier.weight(1f)
                    )
                    Metric(
                        label = if (isRecording) "AUTO-STOP LIMIT" else "NATIVE REPLAYS",
                        value = if (isRecording) formatCompactTime(state.recordingLimitMs)
                            else "×${state.replayCount}",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        if (isRecording) {
            Button(
                onClick = onStop,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Bad,
                    contentColor = SoftWhite
                )
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(9.dp))
                Text("Stop and analyze", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("Cancel take")
            }
        } else {
            Text(
                state.statusHint ?: if (state.practiceMode == PracticeViewModel.PracticeMode.CHORUS)
                    "Listen once, then speak along with the second play."
                else "Keep the phrase in mind. Recording starts automatically after playback.",
                color = MutedGray,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("Cancel listening sequence")
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Black.copy(alpha = 0.48f), RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 13.dp)
    ) {
        Text(label, color = MutedGray, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            color = SoftWhite,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun formatElapsed(ms: Long): String {
    val value = ms.coerceAtLeast(0L)
    val seconds = value / 1000L
    val minutes = seconds / 60L
    val remainder = seconds % 60L
    val tenths = (value % 1000L) / 100L
    return "%02d:%02d.%d".format(minutes, remainder, tenths)
}

private fun formatCompactTime(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val seconds = safe / 1000L
    return "%d:%02d".format(seconds / 60L, seconds % 60L)
}
