package com.shadowjp.app.ui.components

import kotlin.math.roundToLong

/** Pure time/selection math shared by the waveform editor and JVM tests. */
object SelectionMath {
    const val MIN_VIEWPORT_MS = 500L
    const val DEFAULT_VIEWPORT_MS = 12_000L
    /** Keep detail decoding bounded; the overview is the navigator for longer recordings. */
    const val MAX_DETAIL_VIEWPORT_MS = 90_000L
    const val MIN_PHRASE_MS = 300L
    const val MAX_PHRASE_MS = 60_000L

    data class Viewport(val startMs: Long, val endMs: Long) {
        val spanMs: Long get() = (endMs - startMs).coerceAtLeast(0L)
    }

    data class Range(val aMs: Long, val bMs: Long) {
        val spanMs: Long get() = (bMs - aMs).coerceAtLeast(0L)
    }

    fun initialViewport(durationMs: Long, aMs: Long, bMs: Long): Viewport {
        if (durationMs <= 0L) return Viewport(0L, 0L)
        val phrase = (bMs - aMs).coerceAtLeast(MIN_PHRASE_MS)
        val window = maxOf(DEFAULT_VIEWPORT_MS, phrase + phrase / 2L).coerceAtMost(durationMs)
        return centeredViewport(durationMs, (aMs + bMs) / 2L, window)
    }

    fun centeredViewport(durationMs: Long, centerMs: Long, windowMs: Long): Viewport {
        if (durationMs <= 0L) return Viewport(0L, 0L)
        val width = windowMs.coerceIn(minOf(MIN_VIEWPORT_MS, durationMs), durationMs)
        val start = (centerMs - width / 2L).coerceIn(0L, durationMs - width)
        return Viewport(start, start + width)
    }

    fun zoom(viewport: Viewport, durationMs: Long, factor: Float): Viewport {
        if (durationMs <= 0L || viewport.spanMs <= 0L) return Viewport(0L, 0L)
        val maximum = minOf(durationMs, MAX_DETAIL_VIEWPORT_MS)
        val width = (viewport.spanMs * factor.coerceAtLeast(0.01f)).roundToLong()
            .coerceIn(minOf(MIN_VIEWPORT_MS, durationMs), maximum)
        // Keep the edge under the user's finger when zooming from a viewport
        // that is already against one end of the recording. When viewing the
        // entire source, however, use the center as the natural zoom anchor.
        val touchesLeft = viewport.startMs <= 0L
        val touchesRight = viewport.endMs >= durationMs
        return when {
            touchesLeft && touchesRight ->
                centeredViewport(durationMs, viewport.startMs + viewport.spanMs / 2L, width)
            touchesLeft -> Viewport(0L, width)
            touchesRight -> Viewport(durationMs - width, durationMs)
            else -> centeredViewport(durationMs, viewport.startMs + viewport.spanMs / 2L, width)
        }
    }

    /** Pan by a fraction of the current window; positive moves later in the source. */
    fun pan(viewport: Viewport, durationMs: Long, fraction: Float): Viewport {
        if (durationMs <= 0L || viewport.spanMs <= 0L) return Viewport(0L, 0L)
        val delta = (viewport.spanMs * fraction).roundToLong()
        val start = (viewport.startMs + delta).coerceIn(0L, durationMs - viewport.spanMs)
        return Viewport(start, start + viewport.spanMs)
    }

    fun timeToFraction(timeMs: Long, viewport: Viewport): Float {
        if (viewport.spanMs <= 0L) return 0f
        return ((timeMs - viewport.startMs).toDouble() / viewport.spanMs)
            .toFloat().coerceIn(0f, 1f)
    }

    fun fractionToTime(fraction: Float, viewport: Viewport): Long {
        if (viewport.spanMs <= 0L) return viewport.startMs
        return (viewport.startMs + viewport.spanMs * fraction.coerceIn(0f, 1f))
            .roundToLong().coerceIn(viewport.startMs, viewport.endMs)
    }

    /** Move the phrase start to the playhead while keeping its current length where possible. */
    fun rangeStartingAt(positionMs: Long, durationMs: Long, requestedSpanMs: Long): Range {
        if (durationMs <= 0L) return Range(0L, 0L)
        val minSpan = minOf(MIN_PHRASE_MS, durationMs)
        val maxSpan = minOf(MAX_PHRASE_MS, durationMs)
        val span = requestedSpanMs.coerceIn(minSpan, maxSpan)
        val a = positionMs.coerceIn(0L, durationMs - span)
        return Range(a, a + span)
    }

    /** Move the phrase end to the playhead while keeping its current length where possible. */
    fun rangeEndingAt(positionMs: Long, durationMs: Long, requestedSpanMs: Long): Range {
        if (durationMs <= 0L) return Range(0L, 0L)
        val minSpan = minOf(MIN_PHRASE_MS, durationMs)
        val maxSpan = minOf(MAX_PHRASE_MS, durationMs)
        val desiredSpan = requestedSpanMs.coerceIn(minSpan, maxSpan)
        val b = positionMs.coerceIn(minSpan, durationMs)
        val span = minOf(desiredSpan, b).coerceAtLeast(minSpan)
        return Range(b - span, b)
    }

    fun setStart(requestedMs: Long, bMs: Long, durationMs: Long): Long {
        val minStart = (bMs - MAX_PHRASE_MS).coerceAtLeast(0L)
        val maxStart = (bMs - MIN_PHRASE_MS).coerceAtLeast(minStart)
        return requestedMs.coerceIn(minStart, maxStart).coerceAtMost(durationMs)
    }

    fun setEnd(requestedMs: Long, aMs: Long, durationMs: Long): Long {
        val minEnd = aMs + MIN_PHRASE_MS
        val maxEnd = minOf(durationMs, aMs + MAX_PHRASE_MS)
        return requestedMs.coerceIn(minEnd, maxOf(minEnd, maxEnd))
    }

    fun isValidRange(aMs: Long, bMs: Long, durationMs: Long): Boolean =
        aMs >= 0L && bMs > aMs && bMs <= durationMs &&
            bMs - aMs in MIN_PHRASE_MS..MAX_PHRASE_MS
}
