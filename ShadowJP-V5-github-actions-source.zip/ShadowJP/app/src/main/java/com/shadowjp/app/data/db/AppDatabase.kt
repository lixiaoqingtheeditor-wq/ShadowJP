package com.shadowjp.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        AudioSourceEntity::class,
        SegmentEntity::class,
        TakeEntity::class,
        PracticeDayEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ShadowDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        /** v1 -> v2: segment transcripts + silence-trim take metadata. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE segments ADD COLUMN transcript TEXT NOT NULL DEFAULT ''"
                )
                db.execSQL(
                    "ALTER TABLE takes ADD COLUMN originalRecordingPath TEXT"
                )
                db.execSQL(
                    "ALTER TABLE takes ADD COLUMN trimmed INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        /** v2 -> v3: import metadata (original SAF uri, sample rate, channels). */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE audio_sources ADD COLUMN sourceUri TEXT")
                db.execSQL("ALTER TABLE audio_sources ADD COLUMN sampleRateHz INTEGER")
                db.execSQL("ALTER TABLE audio_sources ADD COLUMN channelCount INTEGER")
            }
        }

        /** v3 -> v4: persist the local calendar date of each saved take. */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE takes ADD COLUMN practiceDate TEXT NOT NULL DEFAULT ''")
            }
        }

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shadowjp.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build().also { instance = it }
            }
    }
}
