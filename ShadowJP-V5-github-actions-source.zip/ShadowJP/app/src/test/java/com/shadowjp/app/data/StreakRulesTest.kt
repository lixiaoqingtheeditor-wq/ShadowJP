package com.shadowjp.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

/** OR-goal semantics and local-calendar streak boundaries. */
class StreakRulesTest {

    private fun cal(y: Int, m: Int, d: Int): Calendar =
        Calendar.getInstance().apply {
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

    private fun day(y: Int, m: Int, d: Int, seconds: Int, takes: Int) =
        StreakRules.key(cal(y, m, d)) to StreakRules.DayActivity(seconds, takes)

    private val goalMin = 40
    private val takeGoal = 10

    @Test
    fun `either goal independently qualifies the day`() {
        assertTrue(StreakRules.dayQualifies(StreakRules.DayActivity(15 * 60, 10), goalMin, takeGoal))
        assertTrue(StreakRules.dayQualifies(StreakRules.DayActivity(40 * 60, 4), goalMin, takeGoal))
        assertTrue(StreakRules.dayQualifies(StreakRules.DayActivity(40 * 60, 10), goalMin, takeGoal))
    }

    @Test
    fun `neither target met does not qualify`() {
        assertFalse(StreakRules.dayQualifies(StreakRules.DayActivity(39 * 60, 9), goalMin, takeGoal))
        assertFalse(StreakRules.dayQualifies(null, goalMin, takeGoal))
    }

    @Test
    fun `only time target enabled`() {
        assertTrue(StreakRules.dayQualifies(StreakRules.DayActivity(900, 0), 15, 0))
        assertFalse(StreakRules.dayQualifies(StreakRules.DayActivity(899, 50), 15, 0))
    }

    @Test
    fun `only takes target enabled`() {
        assertTrue(StreakRules.dayQualifies(StreakRules.DayActivity(0, 5), 0, 5))
        assertFalse(StreakRules.dayQualifies(StreakRules.DayActivity(10_000, 4), 0, 5))
    }

    @Test
    fun `both targets disabled never qualify`() {
        assertFalse(StreakRules.dayQualifies(StreakRules.DayActivity(99_999, 99), 0, 0))
        assertFalse(StreakRules.dayQualifies(null, 0, 0))
        assertEquals(0, StreakRules.currentStreak(mapOf(day(2026, 10, 8, 99999, 99)), 0, 0, cal(2026, 10, 8)))
    }

    @Test
    fun `consecutive qualifying days ending today`() {
        val days = mapOf(
            day(2026, 10, 6, 0, 10),
            day(2026, 10, 7, 2400, 0),
            day(2026, 10, 8, 900, 10)
        )
        assertEquals(3, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `today not yet qualified keeps streak alive from yesterday`() {
        val days = mapOf(day(2026, 10, 6, 0, 10), day(2026, 10, 7, 2400, 0))
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `missed day breaks the streak`() {
        val days = mapOf(day(2026, 10, 5, 0, 10), day(2026, 10, 7, 2400, 0))
        assertEquals(1, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 7)))
    }

    @Test
    fun `incomplete day does not extend today but keeps yesterday streak`() {
        val days = mapOf(day(2026, 10, 6, 0, 10), day(2026, 10, 7, 10, 0))
        assertEquals(1, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 7)))
        assertEquals(0, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 8)))
    }

    @Test
    fun `month and midnight boundary use local dates`() {
        val days = mapOf(day(2026, 9, 30, 0, 10), day(2026, 10, 1, 2400, 0))
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 1)))
        assertEquals(2, StreakRules.currentStreak(days, goalMin, takeGoal, cal(2026, 10, 2)))
    }

    @Test
    fun `goal changes apply current goal to history`() {
        val days = mapOf(day(2026, 10, 7, 900, 10), day(2026, 10, 8, 900, 10))
        assertEquals(2, StreakRules.currentStreak(days, 15, 10, cal(2026, 10, 8)))
        assertEquals(0, StreakRules.currentStreak(days, 30, 0, cal(2026, 10, 8)))
    }
}
