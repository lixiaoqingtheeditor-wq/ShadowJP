package com.shadowjp.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SrtParserTest {
    @Test fun parsesNumberedMultiLineCuesAndFractionalMilliseconds() {
        val cues = SrtParser.parse("""
            1
            00:00:01,250 --> 00:00:02,750
            こんにちは
            <i>元気ですか？</i>

            2
            00:01:03.5 --> 00:01:05,000
            I'm fine &amp; thank you.
        """.trimIndent())

        assertEquals(2, cues.size)
        assertEquals(1_250L, cues[0].startMs)
        assertEquals(2_750L, cues[0].endMs)
        assertEquals("こんにちは\n元気ですか？", cues[0].text)
        assertEquals(63_500L, cues[1].startMs)
        assertEquals("I'm fine & thank you.", cues[1].text)
    }

    @Test fun ignoresMalformedOrEmptyCuesAndSortsByTime() {
        val cues = SrtParser.parse("""
            1
            bad --> timestamp
            not a cue

            2
            00:00:04,000 --> 00:00:05,000
            later

            3
            00:00:01,000 --> 00:00:02,000
            earlier
        """.trimIndent())

        assertEquals(listOf("earlier", "later"), cues.map { it.text })
        assertTrue(SrtParser.parse("not an srt file").isEmpty())
    }
}
