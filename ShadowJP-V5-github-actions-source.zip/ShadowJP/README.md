# ShadowJP V5.0 — Japanese Shadowing Practice (Android)

ShadowJP is a fully offline Android app for Japanese shadowing practice. The core loop:

**Import audio → select an A-B phrase → listen to the native → repeat aloud → record → analyze (pitch / timing / intensity) → score → retake.**

- **Package:** `com.shadowjp.app` · **minSdk 26** · **targetSdk 36**
- **Stack:** Kotlin · Jetpack Compose (Material 3) · MVVM · Room · DataStore · Media3/ExoPlayer
- **Offline-only:** no `INTERNET` permission anywhere. (Media3 contributes `ACCESS_NETWORK_STATE`; the app never opens a socket.)
- All DSP (pitch detection, normalization, alignment, scoring) is hand-written Kotlin — no TarsosDSP, no native DSP libraries, no cloud services.
- **V5 focus:** imported, source-timed SRT captions displayed on a zoom-aware caption track; adjustable caption size/track height and hideable waveform; Chorus practice (listen once, then record while the phrase plays again); plus the V4 waveform, library rename, media import, and focused recording-screen improvements.

> **V5.0 implementation / verification status:** this source revision includes OR-based daily goals and streaks, a daily home/statistics overview, persistent local practice dates, versioned self-contained ZIP backup/restore, and independently toggled pitch/timing/intensity graph overlays. The editing environment has JDK 21 but no Android SDK and no cached Gradle distribution. The Gradle wrapper was attempted but could not download Gradle 8.11.1 because `services.gradle.org` cannot resolve from this network-restricted environment. As a result, this revision has **not** been Gradle-compiled, packaged into an APK, or tested on an Android device here. The OR-goal rule was compiled and exercised in a separate pure-Kotlin smoke harness; that is not a substitute for the project unit-test suite or an Android build. Historical V2/V3 results lower in this document describe earlier source revisions only.

## Current V5 workflow

1. **Import and find the phrase:** import audio files or video containers with a supported audio track (including MP4). ShadowJP keeps the imported container and decodes/resamples its audio track to mono 16 kHz PCM when analysis needs it; video frames are ignored. The compact overview shows the whole recording; the larger editor uses 720 min/max peak buckets decoded only for its current time window.
2. **Adjust A/B:** the detailed waveform has generous boundary grab zones, playhead seeking, and selection duration labels. Zoom/pan, “set A/B at playhead,” and 50 ms fine nudges are grouped under a collapsed **Selection tools** toggle. Exact timestamp editing and source-silence utilities are also optional sections.
3. **Timed captions:** import an `.srt` file for a source. Each cue is mapped to the source-time caption lane under the detail waveform, with a readable current-cue preview. Tap a cue block to select its timestamp range; its text is then used for the saved phrase. Captions can be hidden, and font size and track height are adjustable. Caption timing is retained in app-private storage per source and follows waveform zoom/pan.
4. **Exact input when needed:** timestamp fields are secondary and retain draft text until the user presses Apply. Both endpoints are validated together, so a partial edit cannot move a boundary accidentally.
5. **Listen, then record:** choose **Repeat-after** to listen to the selected phrase the chosen number of times, then record after the short gap. Choose **Chorus** to listen once and immediately record while the phrase plays a second time; the mic take ends with that chorus pass. Headphones are recommended to reduce speaker bleed into the mic.
6. **Compare and repeat:** the existing post-take analysis, single-player native/user comparison, score contours, WAV export, saved phrase persistence, previous take history, and retake navigation were left in place. The pitch score remains contour similarity, not a validated lexical pitch-accent score. The playback-time accumulator also retains sub-second position increments rather than discarding each short polling interval, preserving daily practice-time accounting.

V4 previously passed 69 pure-Kotlin test methods in an offline harness. This V5 revision adds two pure-JVM SRT parser tests covering timestamps, multi-line cues, basic markup/entities, malformed blocks, and cue ordering. The parser was compiled and exercised directly with `kotlinc`; the official Gradle task could not start because the wrapper could not download Gradle in this network-restricted environment. Android/Compose integration and on-device codec behavior therefore remain unverified here.

---

## 1. Build instructions

Requirements: JDK 17, Android SDK with `platforms;android-36` and `build-tools;36.0.0`.

```bash
# with the Gradle wrapper (gradlew / gradle-wrapper.jar are included)
./gradlew :app:assembleDebug          # debug APK -> app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:testDebugUnitTest      # JVM unit tests (DSP + scoring)

# or with a local Gradle 8.11.1 install
gradle :app:assembleDebug :app:testDebugUnitTest
```

Create `local.properties` with `sdk.dir=/path/to/android-sdk` if `ANDROID_HOME` is not set.
Opening the project root in Android Studio (Ladybug+) also works directly.

The previous V3 README recorded a build environment using Temurin JDK 17.0.20, Gradle 8.11.1,
AGP 8.10.1, Kotlin 2.1.21, and KSP 2.1.21-2.0.1. This toolchain was not available for
verification of the V4 source in the current editing environment.

## 2. Architecture overview

Single-activity MVVM, manual DI (service locator in `ShadowApp`), Navigation-Compose.

```
app/src/main/java/com/shadowjp/app/
├── ShadowApp.kt                 Application + service locator (repos, DB, settings)
├── MainActivity.kt              NavHost + ViewModel factories
├── AnalysisResultStore.kt       Hands the latest Analysis to the analysis screen
├── audio/
│   ├── AudioDecoder.kt          probe (no decode) / decodeRange (A-B only) / full decode
│   ├── RangeCutter.kt           Pure timestamp->frame trim math (JVM-tested)
│   ├── WaveformBuilder.kt       Progressive peak generation (WAV fast path + codec path)
│   ├── WaveformCache.kt         On-disk peak cache, content-stat invalidation
│   ├── PeakAccumulator.kt       O(buckets) streaming min/max peaks (JVM-tested)
│   ├── PhraseCache.kt           2-entry LRU for decoded A-B phrases
│   ├── Pcm.kt                   PCM slicing, WAV read/write, linear resampler
│   ├── MicRecorder.kt           AudioRecord capture (16 kHz/16-bit/mono)
│   └── NativePlayer.kt          ExoPlayer with pitch-preserving speed + A-B loop
├── dsp/                         Pure Kotlin, no Android deps — JVM-unit-tested
│   ├── YinPitch.kt              YIN pitch extractor (from-scratch implementation)
│   ├── Contours.kt              Pitch/intensity contours + speaker normalization
│   ├── Intensity.kt             RMS -> dBFS intensity extractor
│   ├── Dtw.kt                   Banded DTW (Sakoe-Chiba) with backtrack
│   ├── Scorer.kt                All scoring formulas + verdict rules
│   └── AnalysisEngine.kt        Pipeline: PCM pair -> Analysis or explicit Failure
├── data/
│   ├── Subtitles.kt             SRT cue model and pure Kotlin SubRip parser
│   ├── db/                      Room: entities, DAOs, database (v3)
│   ├── StreakRules.kt           Dual-goal streak logic (pure, JVM-tested)
│   ├── AudioLibraryRepository.kt  SAF import (copies into app storage), segments, clip deletion
│   └── PracticeRepository.kt    Practice-time accounting + streak logic
├── prefs/SettingsRepository.kt  DataStore settings (time + takes goals, pitch range, replays)
└── ui/
    ├── theme/                   Dark theme: black background, #22D3EE cyan accent
    ├── home/                    Goal ring, streak, totals, import, source list
    ├── components/ABWaveformSelector.kt  Overview + range-decoded detail editor
    ├── components/SelectionMath.kt       Zoom/pan mapping and A/B constraints (pure Kotlin)
    ├── components/TimeFormatting.kt      Draft timestamp parse/format helpers (pure Kotlin)
    ├── practice/                Native playback controls + repeat-after recording
    ├── analysis/                Pitch/intensity contour graphs + sub-scores (Canvas)
    ├── segments/                Saved phrases + per-phrase take history
    ├── stats/                   15-week practice heatmap + score trend + averages
    └── settings/                OR-based goals, pitch range, replay count, complete ZIP backup/restore, CSV export, clear-all
```

**Data model (Room):** `AudioSourceEntity` 1—n `SegmentEntity` 1—n `TakeEntity`
(FK cascades), plus `PracticeDayEntity(date "yyyy-MM-dd", practiceSeconds)` for stats.
Takes store their scores plus paths to 16 kHz mono WAV recordings under `filesDir/recordings/`.
Imported audio is always copied into `filesDir/imports/` (persistable URI permission is
requested best-effort, but never relied on).

## 3. Major implementation decisions

| Decision | Rationale |
|---|---|
| YIN hand-written in Kotlin | Hard requirement; also keeps the whole DSP layer JVM-testable |
| 16 kHz mono analysis pipeline | Sufficient for F0 ≤ 500 Hz; halves compute vs. 44.1 kHz |
| Frame 1024 / hop 160 (10 ms) @16 kHz | 64 ms window spans ≥3 periods at 60 Hz; 10 ms resolution for graphs |
| Semitones vs. own median F0 | Speaker-independent comparison; never compares absolute Hz across voices |
| dB mean-shift normalization | Mic gain is an additive constant in dB — mean-shift cancels it exactly |
| Banded DTW (Sakoe-Chiba) | O(n·band) instead of O(n·m); shadowing takes are roughly synchronized |
| ExoPlayer `PlaybackParameters(speed, 1f)` | Sonic-based pitch-preserving slow playback (0.5/0.75/1.0x) |
| Repeat-after + Chorus | Repeat-after plays native audio before recording; Chorus listens once, then records one pass in sync with playback. Headphones are recommended for Chorus to limit speaker bleed. |
| Compose Canvas for all graphs | No charting libraries; full control over unvoiced-gap rendering |
| Practice time = native playback + recording seconds only | Spec: idle time on screens never counts |
| OR-based daily goal/streak | A day qualifies when either enabled time or completed-take target is met; both disabled means no qualifying days |
| Manual DI (no Hilt) | Keeps the build lean; the graph is tiny and explicit |

## 4. Signal processing approach

### 4.1 Pitch — YIN (de Cheveigné & Kawahara 2002, steps 1–5)

`dsp/YinPitch.kt` implements the five canonical steps directly:

1. **Difference function** `d(τ) = Σᵢ (xᵢ − xᵢ₊τ)²` over `τ ∈ [minTau, maxTau]`
   (`minF0`/`maxF0` configurable per pitch-range setting; default 60–400 Hz at 16 kHz).
2. **Cumulative mean normalized difference** `d′(τ) = d(τ) / ((1/τ)·Σⱼ₌₁..τ d(j))`, `d′(0)=1`.
3. **Absolute threshold 0.15:** first local minimum of `d′` below the threshold wins;
   if none exists, the frame is **unvoiced** (consonant / noise / silence).
4. **Parabolic interpolation** around the winning τ for sub-sample lag accuracy.
5. `f0 = sampleRate / τ`.

Guards: an RMS energy gate (`silenceRms = 0.008`) forces silence unvoiced before YIN runs;
estimates outside `[0.9·minF0, 1.1·maxF0]` are rejected. Per-frame confidence = `1 − d′(τ*)`.
`PitchContour.cleaned()` re-marks frames below confidence 0.6 as unvoiced, then applies a
3-frame median filter (only where both neighbors are voiced) to suppress single-frame
octave jumps.

### 4.2 Speaker normalization

Each contour is normalized **against its own median voiced F0**:

```
st(f0) = 12 · log2(f0 / medianVoicedF0)     // unvoiced frames -> NaN
```

An octave difference between speakers therefore cancels exactly, and a perfect imitation
in any voice range scores the same (covered by unit tests).

### 4.3 Intensity

Per-frame RMS → `dBFS = 20·log10(rms)`, clamped at −60 dBFS; frames below −50 dBFS are
flagged silent and become `NaN`. Contours are mean-normalized (active-frame mean shifted
to 0 dB), which cancels any constant microphone gain difference exactly.

### 4.4 Alignment — banded DTW

`dsp/Dtw.kt`: Sakoe-Chiba band `= max(0.25·max(n,m), |n−m|+2, 10)`; if the band makes the
target cell unreachable it retries with a full window. Local cost on normalized contours:

| native / user | voiced | unvoiced |
|---|---|---|
| **voiced**   | `min(|Δst|, 12)` | 6 (mismatch) |
| **unvoiced** | 6 (mismatch)     | 0 (free — silence aligns with silence) |

Full backtrack matrix; result is the `(nativeIdx, userIdx)` path plus mean cost.

## 5. Scoring formulas (exact)

All constants below are the named calibration constants in `dsp/Scorer.kt`.
Scores are clamped to **[0, 100]**.

Let the DTW path be `P = {(iₖ, jₖ)}`, `st_n`, `st_u` the semitone contours,
`db_n`, `db_u` the mean-normalized intensity contours.

### Pitch (weight 0.5)

- **Mean semitone error** over both-voiced path pairs: `E = mean |st_n(i) − st_u(j)|`
- **Direction agreement:** anchors = successive both-voiced path pairs (so a movement
  spanning an unvoiced gap still counts). Between consecutive anchors let `dA`, `dB` be the
  native/user semitone movements. The step is informative unless both are flat
  (`|d| ≤ 0.3` st, `DIRECTION_DEAD_ZONE_ST`). It agrees when
  `|dA − dB| ≤ 0.5` st (`DIRECTION_MATCH_TOLERANCE_ST`) or both sides move the same way.
  `A = agree/total` (if no informative step exists, `A = 1` — the error term alone governs).
- **Drop displacement:** find the strongest cumulative drop over ≤ 4 voiced steps
  (`DROP_WINDOW = 4`, ignoring drops < 1.5 st) in each contour; `D = |locNative − locUser|`
  as a fraction of phrase length; 0 if either contour has no qualifying drop.

```
pitchBase = 0.75 · 100 · e^(−E / 2.5)  +  0.25 · 100 · A
pitch     = pitchBase · (1 − min(0.25, D · 1.25))
```

### Timing (weight 0.3)

```
durRatio = min(Tn, Tu) / max(Tn, Tu)          // phrase durations in seconds
meanDev  = mean over path of |i/(n−1) − j/(m−1)|     // normalized warp deviation
timing   = 100 · (0.4 · durRatio + 0.6 · e^(−meanDev / 0.10))
```

### Intensity (weight 0.2)

Over path pairs: `Dₘ = mean |db_n(i) − db_u(j)|` over pairs where both frames are active
(falls back to 12 dB if none); `S =` fraction of path pairs where exactly one side is silent.

```
intensity = 100 · e^(−Dₘ / 6) · (1 − 0.5 · S)
```

### Overall

```
overall = 0.5 · pitch + 0.3 · timing + 0.2 · intensity        (clamped to 0..100)
```

### Verdict (deterministic, rule-based)

`overall ≥ 85` → "Excellent take…". Otherwise the verdict keys on the **weakest
sub-score** with a specific tip (pitch / timing / intensity). No score is ever fabricated:
when analysis is impossible the engine returns an explicit failure reason
(`RECORDING_TOO_SHORT`, `NO_USABLE_PITCH_NATIVE`, `NO_USABLE_PITCH_USER`,
`INSUFFICIENT_SIGNAL`, `EMPTY_INPUT`) and the UI shows guidance instead of numbers.

## 6. V5 verification status — current source

### Automated tests included in V5

`SelectionMathTest` covers source-time mapping at multiple zoom levels, zoom centering and edge clamps, panning, initial view sizing, and the 300 ms / 60 s phrase constraints. `TimeRangeFieldsTest` covers timestamp parsing, invalid/incomplete input, and millisecond round trips. The new `SrtParserTest` covers comma/dot timestamps, multi-line cues, basic markup/entities, malformed blocks, and cue ordering. Existing DSP, alignment, silence-trimming, range-cutting, peak-accumulation, and streak tests remain in the repository.

### Build/test attempts in the V5 editing environment

The following commands were attempted:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

The Gradle wrapper failed before launching Gradle because it could not resolve `services.gradle.org` while trying to download Gradle 8.11.1 (`java.net.UnknownHostException`). No Gradle distribution or Android SDK was present in the usual environment paths. As a fallback, the prior V4 source passed its 69 pure-Kotlin tests with a lightweight local JUnit-compatible harness. In this V5 environment, the pure-Kotlin SRT parser was compiled and exercised directly with `kotlinc`, and all parser checks passed. The combined Gradle test suite could not be rerun here, so the new SRT tests and the Android/Compose integration are not verified by the official test task. The two failures reported by the prior build log were traced to edge-anchored waveform zoom and floating-point truncation in millisecond timestamp parsing; both were corrected in V4.

No emulator or physical device was available. The SRT import picker, subtitle track rendering, chorus timing, real codec seeking, recording lifecycle, analysis handoff, comparison playback, take history, Room behavior, and WAV export were not runtime-tested for V5. Do not treat the historical V2/V3 build reports below as V5 verification.

## 7. Known limitations

- **Detail waveform depends on range decoding.** If Android's decoder cannot seek a source window, the detail pane falls back to an empty/flat preview with an explanatory hint; the overview, exact timestamps, and phrase analysis fallback remain available. V5 source behavior is not runtime-verified in this environment.
- **No live coaching during recording.** The recording screen shows elapsed time and progress but intentionally does not draw a live waveform or compute live pitch, intensity, or timing overlays.
- **Resampler is linear interpolation** (decode → 16 kHz). Adequate for speech F0 work;
  not audiophile-grade. It only affects imported audio not already at 16 kHz.
- **Phrase length capped at 60 s**; segments under 300 ms are rejected.
- **YIN range** 50–500 Hz depending on the pitch-range setting (Low 50–300 /
  Standard 60–400 / High 100–500). Very deep or very high voices outside the selected
  range produce unvoiced frames, and the engine reports `INSUFFICIENT_SIGNAL` rather
  than scoring garbage.
- **Graph axes** are fixed at ±12 st and ±20 dB; the X axis is length-normalized
  (native and user contours are drawn over their own durations, like the DTW sees them).
- **Direction agreement** uses 0.3 st dead zone / 0.5 st match tolerance — intentional
  smoothing of YIN frame jitter, at the cost of ignoring genuinely tiny pitch movements.
- **First-frame YIN estimates** at segment boundaries can be unstable; the silence gate
  and confidence cleaning mitigate but do not eliminate this.
- Takes are stored as uncompressed 16 kHz mono WAV (~1.9 MB per minute of recording).

## 8. Cut features (explicitly out of scope)

Formant analysis, vowel charts, real-time (live) pitch feedback, song/music detection,
cloud sync, accounts, social features, YouTube/streaming import, SRS/Anki scheduling,
flashcards, chorus mode (speaking simultaneously with the native), mora-level
segmentation, per-phoneme pronunciation assessment, and any online AI service.


---

# v2 feature update (this section documents the v2 changes)

## v2.1 Numerical A-B selection

The waveform handles are retained, and two numeric fields (`Start A` / `End B`) now sit
directly beneath the waveform. Format: `mm:ss.mmm` (e.g. `01:23.450`); plain `12.35`
(seconds) and bare seconds are also accepted. The two inputs are **two-way synchronized**:

- Typing a valid value applies it immediately → waveform highlight and handles move.
- Dragging a handle rewrites the text fields.
- Validation (rejected with an inline error, nothing applied): start < 0, end ≤ start,
  phrase < 300 ms, end beyond the decoded audio duration, phrase > 60 s (DTW cap).
- A-B loop playback and seek use exactly the numeric values (`setRangeExact` writes
  straight into `NativePlayer.aMs/bMs`).

## v2.2 Transcript overlay

- Optional multi-line transcript edited directly under the waveform on the practice
  screen; it is part of the phrase view, not a separate notes page. Japanese renders via
  the default Compose text pipeline (no custom font needed for CJK on Android).
- Persisted in Room (`segments.transcript`, migration 1→2). Reopening a saved segment
  restores its transcript; edits auto-save (400 ms debounce) for existing segments, and
  are written when a new segment is auto-saved after a take.
- Local-only: never leaves the device. Segments list shows a 2-line preview.

## v2.3 Historical implementation: full-screen live waveforms (removed in V4)

**This section documents a prior revision only. V4 does not show live waveforms while recording.** In the former implementation, the practice screen was replaced by a focused full-screen black view
(`LivePracticeScreen`):

- Before/at the start of recording the native phrase waveform is drawn as a muted gray
  ghost (the A-B region brighter than the rest of the file).
- Over the first 2 s of the take the native ghost fades to a floor alpha of 0.14 while
  the user's live cyan waveform (peak per 64 ms AudioRecord block) becomes dominant —
  a deliberate "native → you" hand-off, not two unrelated screens.
- Minimal chrome: overlay toggles on top, elapsed time and Stop/Cancel at the bottom.

## v2.4 Historical implementation: live analysis overlays (removed in V4)

**This section documents a prior revision only. V4 removes the live analysis loop, live pitch/intensity calculations, and visualization buffers.** The former implementation had three independently toggleable overlays, all derived from the real mic PCM
(`MicRecorder.onPcmBlock` feeds 1024-sample blocks into a `Dispatchers.Default` loop):

- **Pitch** — the same `YinPitchExtractor` as the scoring pipeline analyzes each block;
  voiced frames draw the F0 contour (amber, 50–400 Hz band), unvoiced/silent frames draw
  explicit baseline ticks, never invented values.
- **Intensity** — windowed RMS in dBFS (−60…0) rendered as a cyan area along the bottom,
  same RMS approach as the offline intensity extractor.
- **Timing** — a strip showing the expected native phrase duration (post-speed) with
  per-second ticks and a cyan marker at the current recording position.

Explicitly **not** implemented (by design): live scoring, live good/bad judgments,
correction prompts. The post-recording analysis remains the only evaluation. If the
analysis loop can't keep up it simply skips blocks — the recorder thread is independent,
so recording quality never degrades; block rate (~15 Hz) bounds the update cost.

## v2.5 Native vs. user playback on the analysis screen

A "Listen & compare" card offers **Play native** (the exact analyzed A-B phrase, playback
auto-stops at B) and **Play my recording** (the stored take). `ComparisonPlayer` holds a
single ExoPlayer, so starting one clip stops the other — simultaneous playback is
impossible. Buttons toggle to Stop while their clip plays.

## v2.6 Exportable audio

- **Export native segment** / **Export my take** on the analysis screen use the Android
  system save picker (`ActivityResultContracts.CreateDocument("audio/wav")`).
- Format: 16-bit PCM mono WAV (16 kHz), written from the app's own PCM — the native
  export decodes the source, slices exactly A..B, and encodes a fresh WAV; the take
  export streams the stored take WAV. Nothing is uploaded; no network anywhere.
- Filenames: `native_segment_yyyy-MM-dd_HHmm.wav`, `my_take_yyyy-MM-dd_HHmm.wav`.
- Failures (missing file, unwritable destination) surface as an inline message.

## v2.7 Automatic silence remover

`dsp/SilenceTrimmer` (pure Kotlin, unit-tested): windowed RMS (20 ms windows) against a
configurable dBFS threshold; only **leading and trailing** silent runs ≥ 250 ms are
trimmed, keeping 120 ms of padding so onsets/offsets survive. Internal pauses are never
touched. Threshold is adjustable in Settings (−60…−25 dBFS, default −45).

- **Recorded takes:** the untouched original WAV (`*_orig.wav`) is always kept. When
  trimming removes ≥ 150 ms, a trimmed copy (`*_trim.wav`) is written and becomes the
  take's `recordingPath` (playback/export candidate); `originalRecordingPath` points at
  the original and `trimmed = true`. Take history shows a "trimmed" marker.
- **Imported source:** "Trim source silence" on the practice screen writes a session copy
  under `files/imports/` and swaps playback/analysis to it; the original imported file is
  never modified and the DB row is untouched.
- Files with no detectable edge silence keep the original audio (trimmer returns null).

## v2.8 Persistence / schema changes

Room **v1 → v2 migration** (no data loss, no destructive fallback):

```sql
ALTER TABLE segments ADD COLUMN transcript TEXT NOT NULL DEFAULT '';
ALTER TABLE takes ADD COLUMN originalRecordingPath TEXT;
ALTER TABLE takes ADD COLUMN trimmed INTEGER NOT NULL DEFAULT 0;
```

Binary audio stays in app-private files referenced by path; Room holds only metadata.
Segment start/end were already persisted. New DataStore key: `silence_threshold_db`.

## v2.9 Test results (v2)

- **Unit-tested:** `SilenceTrimmerTest` (6 new) + all pre-existing DSP tests —
  **37 tests, 0 failures, 0 errors** via `:app:testDebugUnitTest`.
- **Build-verified:** `:app:assembleDebug` succeeds from clean source; the shipped APK is
  built from the exact source in the project ZIP.
- **Emulator/device-tested:** none — the build sandbox has no `/dev/kvm`, emulator, or
  system images, so UI/runtime behavior (numeric entry sync, transcript editing, live
  waveforms/overlays, playback comparison, SAF export, on-device trimming) is verified by
  compilation and code review only, and remains to be exercised on a device.

## v2.10 Known limitations / decisions (v2 additions)

- Live pitch is computed per 64 ms block (vs. 10 ms hop offline): coarser, but cheap and
  consistent with the same YIN implementation.
- Live overlay colors: amber = pitch, cyan = intensity/user waveform, white-gray = native.
- Source trimming is session-local by design (originals never destructively modified);
  reopening the source starts from the original import again.
- Analysis still runs on the original (untrimmed) take; the trimmed copy is only the
  playback/export candidate — scoring behavior is unchanged from v1.


---

# v3 feature update (audio performance, dual daily goals, clip management)

## v3.1 The performance bottleneck and its fix

**Bottleneck (v1/v2):** opening any clip ran `AudioDecoder.decode()` — a
full-file MediaExtractor + MediaCodec decode into an in-memory mono PCM array —
*BEFORE* the practice screen became usable. The same full decode ran again for
every analysis (the phrase was sliced out of the whole-file PCM), and the
waveform was computed synchronously from that same array. A long file (podcast,
audiobook chapter) therefore blocked clip opening for many seconds and held
tens/hundreds of MB of PCM in memory.

**Fix (v3):** import, playback, visualization and analysis are now four
separate pipelines with separate performance budgets:

| Operation | v3 implementation | Blocks opening? |
|---|---|---|
| Import / metadata | `AudioDecoder.probe()` — container header parse only (duration, sample rate, channel count, mime). No frame is ever decoded at import. | no |
| Playback / seeking | ExoPlayer streams directly from the on-disk file (unchanged from v2); zero PCM in memory. | no |
| Waveform | `WaveformBuilder` streams decode output through `PeakAccumulator` (O(240 buckets) memory), publishes partial snapshots progressively, result cached on disk by `WaveformCache`. Runs on `Dispatchers.Default`, cancellable. | no |
| Analysis / native export | `AudioDecoder.decodeRange()` decodes ONLY the selected A-B window (see v3.2). | no |

The practice screen reaches READY as soon as the Room row (duration from the
import-time probe) is read and ExoPlayer is prepared. Numerical A-B entry, the
A/B handles, playback, seek and the record flow are all live while the waveform
is still generating; a thin progress bar under the selector reports waveform
progress honestly, and the selector renders a flat baseline until the first
peaks arrive.

The ONLY remaining full-file decode is the explicit, user-triggered "Trim
source silence" scan — it runs on a background dispatcher, shows its own
busy state, and is cancelled when the screen is left.

## v3.2 Range-based decoding (analysis decodes only A..B)

`AudioDecoder.decodeRange(file, startMs, endMs)`:

1. `MediaExtractor.seekTo(startUs, SEEK_TO_PREVIOUS_SYNC)` — lands on the
   nearest sync point at or before A (format-dependent granularity: mp3 frame
   / AAC packet boundaries).
2. Decode forward; for every output buffer use its **presentation timestamp**
   (`BufferInfo.presentationTimeUs`) to compute exactly which frames overlap
   `[A, B)` — the timestamp math lives in the pure-Kotlin, JVM-unit-tested
   `RangeCutter` (boundary frames that partially overlap are kept, so the
   effective boundary error is < 1 sample frame, 62.5 µs at 16 kHz). Priming
   frames and everything before A are discarded.
3. Input feeding stops once the extractor passes B (+300 ms safety for codec
   reordering); output collection stops at the first buffer past B.
4. The bounded region (≤ 60 s by the existing phrase cap) is downmixed and
   resampled to 16 kHz exactly as before — **the scoring pipeline and all
   formulas are untouched**.

A 2-entry LRU (`PhraseCache`, keyed by path+length+mtime+A+B, ≤ ~8 MB) makes
retakes of an unchanged phrase skip decoding entirely without ever holding
whole files in memory. If a pathological format refuses to seek or yields no
in-range frames, the VM falls back **explicitly** to a one-off background
full decode + slice (never on the UI thread) and analysis still succeeds.

## v3.3 Waveform caching and invalidation

- Peaks are stored under `cacheDir/waveforms/` as a tiny binary
  (`SJPW` magic + version + bucket count + 240×2 float32, ≈ 3.8 KB).
- File name: `sha1(absPath)16_fileLength_lastModified.wf`. The length/mtime
  suffix IS the invalidation: a changed file on disk can never match a stale
  entry, and stale entries for the same path are swept on the next save.
- Reopening an unchanged clip renders the cached waveform instantly;
  `cacheDir` is OS-purgeable and the peaks regenerate on miss — the imported
  file remains the single source of truth.
- 16-bit PCM WAV takes a fast path (`WavScanner`): a bounded-chunk disk scan,
  no codec at all.
- Deleting a clip removes its cached waveforms via the path-hash prefix;
  Clear All Data wipes the whole cache.

## v3.4 Concurrency / cancellation

- All expensive work (waveform build, range decode, full decode for the
  silence scan, pitch/intensity/DTW, WAV export, cache I/O) runs on
  `Dispatchers.Default`/`IO`. Nothing decode-related touches the main thread.
- A monotonic `sessionToken` in `PracticeViewModel` invalidates in-flight
  results when the session changes (clip switch, trim-swap) and `onCleared`
  cancels the waveform job — cancelled generation never corrupts playback
  (separate ExoPlayer) or saved data (peaks are written only on completion).

## v3.5 Performance measurements — honest report

The build sandbox has **no emulator, no device and no Android runtime**, so
on-device timings (open latency, decode speed, memory curves) could NOT be
measured and are not claimed. What IS verified:

- **Unit-tested (JVM):** `RangeCutterTest` (8 tests: sync-point overshoot
  trimmed, boundary straddling, priming frames dropped, degenerate inputs),
  `PeakAccumulatorTest` (5: exact min/max vs. reference, partial progress
  honesty, chunk-boundary equivalence, O(buckets) memory shape),
  `StreakRulesTest` (9, see v3.7). **59 tests, 0 failures, 0 errors.**
- **Build-verified:** clean `:app:assembleDebug` + `:app:testDebugUnitTest`;
  APK inspected with `aapt2 dump badging` (minSdk 26, targetSdk 36, still no
  `INTERNET` permission).
- **By construction (code review):** memory no longer scales with source
  duration anywhere except the explicit silence-trim scan; analysis decodes
  ≤ the 60 s phrase cap regardless of file length; waveform generation holds
  only 480 floats plus one codec output buffer.

## v3.6 Daily takes goal

- New DataStore setting `daily_take_goal` (default **5**, range 1–60) beside
  the existing minutes goal; both editable in Settings and persisted
  independently. Changing a goal updates progress indicators immediately and
  never rewrites historical activity.
- **Completed take definition:** a take counts when it has been recorded,
  successfully analyzed AND persisted as a `TakeEntity` row (score saved).
  Retakes of an already-practiced phrase count individually. Abandoned
  recordings, failed recordings, failed analyses and unsaved recordings never
  reach the table and never count. The `takes` table is the sole source of
  truth for take counts; a double-tap cannot double-count because the recorder
  reference is nulled before analysis starts and exactly one row is inserted
  per recording.
- Home shows both goals: the time ring (percent may exceed 100%, the ring
  caps its fill) and a takes bar (`today / goal` + linear indicator).
- Statistics adds "Takes today", a 14-day takes-per-day bar chart with the
  take-goal line, and keeps the time heatmap — time and takes stay
  distinguishable everywhere.

## v3.7 Historical streak semantics (superseded in V5.0)

The V3.7 implementation required **both** the configured minute goal and
configured take goal. That behavior was intentionally replaced in V5.0: the
current pure-Kotlin `StreakRules` uses OR semantics, so any enabled target can
qualify a day. Current regression tests cover either goal independently,
neither target, both disabled, consecutive days, missed days, month boundaries,
and goal changes.

**Documented fallback:** historical goal VALUES are not stored, so past days
are evaluated against the CURRENT goal settings. Reconstructing "the goal as
it was on day X" is impossible from existing data and is not pretended.

## v3.8 Individual clip deletion

- Every clip row on Home has a delete action → confirmation dialog showing
  the REAL dependent counts: "Remove this clip? … This will also remove N
  associated segment(s) and M stored take(s) with their practice history."
  Cancel changes nothing.
- **Deletion policy (one consistent rule):** the clip row, its segments and
  their takes are deleted in a single Room transaction (takes → segments →
  source), so the DB can never point at a missing source. Afterwards, files
  exclusively owned by the deleted records are removed: take recordings
  (only when no surviving take references the same path), the app-managed
  import copy (only when no other source row references the same path),
  session trim copies (`trimmed_<sourceId>_*.wav`), and cached waveforms.
- If a file delete fails after the DB commit, the clip is still gone and the
  leftover is reported as inert residue (swept by Clear All Data) — a
  recoverable end state, never an inconsistent one.
- The original SAF document outside app storage is NEVER deleted or modified;
  the persisted read permission taken at import is released
  (`releasePersistableUriPermission`).
- Deleting one clip leaves other clips, their segments/takes, settings,
  practice stats and unrelated history untouched. Clear All Data remains a
  separate, explicitly destructive operation (and now also wipes the waveform
  and phrase caches).
- The original URI is stored (`audio_sources.sourceUri`, Room v2→v3
  migration, alongside `sampleRateHz`/`channelCount` metadata) purely to
  support permission release.
- Practice screens opened on a deleted clip/segment fail gracefully with the
  existing "no longer available" error state; no stale playback is possible
  because the file and DB rows are gone together.

## v3.9 Historical test results (V3 source only)

- **Unit-tested:** 59 tests total, 0 failures — the 37 pre-existing DSP tests
  unchanged (scoring formulas untouched), plus 22 new: `RangeCutterTest` (8),
  `PeakAccumulatorTest` (5), `StreakRulesTest` (9). Run via
  `:app:testDebugUnitTest`.
- **Build-verified:** `:app:assembleDebug` from clean source; the shipped APK
  is built from the exact source in the project ZIP; `aapt2 dump badging`
  confirms package/permissions unchanged.
- **Emulator/device-tested:** NONE — no emulator, device or Android runtime
  exists in this environment. Consequently unverified beyond compilation and
  code review: real MediaExtractor seek behavior across formats (mp3/AAC/ogg
  sync-point granularity), progressive waveform rendering on screen, clip
  deletion UI flow, dual-goal indicators, and every other runtime behavior.
  The P0 regression list in particular (long-file open latency, seek during
  waveform generation, cache reuse on reopen, cancellation safety) is
  implemented and compile-verified but MUST be exercised on a device before
  release.

## v3.10 Historical known limitations / decisions (V3 additions)

- A-B boundary accuracy after range decode is bounded by decoder seek
  granularity + timestamp trimming: exact to < 1 sample frame at 16 kHz when
  the decoder reports honest timestamps; a decoder that misreports
  presentation times could shift the phrase slightly (not observed anywhere
  in this environment — untestable here).
- The waveform progress bar advances per decoded bucket, not per wall-clock;
  for very long compressed files the coarse-to-fine fill is left-to-right.
- Formats without seek support fall back to a one-off background full decode
  for analysis (explicit, off the UI thread, still bounded afterwards).
- The 2-entry phrase cache is intentionally small; rapid alternation between
  three or more phrases re-decodes.
- `practice_days` stores only seconds; take counts per day are derived from
  `takes.createdAt` — deleting a clip (and its takes) therefore also removes
  that day's take count, while practiced SECONDS stay (they were real
  practice time). This is deliberate: stats reflect surviving history.


## Daily-goal semantics (updated)

A practice day qualifies for the current streak when **either enabled target** is reached: the daily active-practice-time target OR the successfully saved/analyzed take target. A target value of `0` means disabled; if both targets are disabled no day qualifies. A saved take is the source of truth for take counts, so cancelled/abandoned recordings and failed analyses do not count as takes. Practice time remains active playback/recording time rather than idle time.

Newly saved takes persist the local calendar date to make their streak/history grouping stable if the device time zone later changes. Older takes without a stored date use their timestamp and the current system time zone. Historical goal settings are not stored per day, so historical streaks use the current target settings.

## Complete backup format

Settings includes a self-contained offline ZIP backup. The versioned manifest stores Room records and app preferences; payload entries include referenced imported media, take WAV files (including originals where available), and per-source SRT subtitle tracks plus their displayed names. Files are handled through Android's Storage Access Framework. Restore offers merge and full replacement: merge matches imported media by SHA-256 where possible, reuses phrase selections, avoids likely duplicate takes, and merges each practice day using the larger total to avoid repeated-backup inflation. Full replacement is explicitly confirmed and updates the database transactionally before applying preferences. Backup payloads can contain large media files; the restore preview reports their approximate size.


## V5.0 implementation update and verification boundary

- Version metadata is now `versionCode 5` / `versionName 5.0`.
- The home dashboard and Statistics screen use a daily progress ring, a compact 2×2 metric grid, current streak, and explicit OR-goal messaging. Character counts are derived from the saved transcript for each successfully analyzed take; each Unicode code point counts once per saved take.
- Goal completion, progress, heatmap highlighting, and streak calculation share OR semantics. Saved takes store their local practice date; microphone duration is credited to the local day on which recording began.
- Backup files are versioned ZIP archives created with Android's Storage Access Framework and include database rows, settings, imported media, saved WAV takes/originals, and associated SRT/name files. Restore preview and Merge/Full restore choices are provided.
- Pitch, normalized timing alignment, and intensity graphs each have a separate hidden-by-default user-take overlay toggle.
- The provided container has no Android SDK and cannot download Gradle, so `assembleDebug` and `testDebugUnitTest` could not start. A pure-Kotlin smoke harness passed for the new OR-goal and streak date logic. No claim is made that this revision has passed Android compilation, official Gradle tests, or device testing.

## Build APK with GitHub Actions

This project includes `.github/workflows/android.yml`. **The repository root must contain `settings.gradle.kts`, `gradlew`, `app/`, and `.github/workflows/android.yml` directly.** When uploading to GitHub, upload the *contents* of the extracted `ShadowJP/` folder, rather than nesting that folder one level down.

The workflow uses current GitHub Actions for checkout/JDK/Android setup and artifact uploads, validates the Gradle wrapper, and then runs the JVM unit tests and debug APK build as separate jobs. They can run independently after wrapper validation: if tests fail but compilation/build succeeds, the APK artifact is still uploaded while the overall workflow correctly remains failed. It runs on pushes to `main`/`master`, pull requests, and manual runs.

### Publish the project to GitHub

1. Create a new, empty repository on GitHub. Leave it without an automatically generated README, license, or `.gitignore`.
2. Extract this ZIP and open a terminal in the inner `ShadowJP/` project folder (the one containing `settings.gradle.kts`).
3. Run the following commands, replacing the remote URL with your repository URL:

```bash
git init -b main
git add .
git commit -m "Add ShadowJP Android project and CI workflow"
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

### Download the APK from GitHub

1. Open your GitHub repository and choose **Actions**.
2. Open the latest **ShadowJP Android CI** workflow run.
3. Under **Artifacts**, download `ShadowJP-debug-apk`.
4. Extract that artifact ZIP; it contains `app-debug.apk`.

The separate `ShadowJP-test-reports` artifact contains the JVM test reports when available. Both artifacts are retained for 14 days. This is a debug APK for sideloading and testing, not a production-signed Play Store release. This environment could not run the Android Gradle build itself, so the first GitHub run is still required to verify compilation and tests.
